import { BookOpen, User, LogOut } from "lucide-react";

interface HeaderProps {
  userEmail: string | null;
  googleProfile: any | null;
  onSignOut: () => void;
  onSignIn: () => void;
  onGoHome: () => void;
}

export default function Header({ userEmail, googleProfile, onSignOut, onSignIn, onGoHome }: HeaderProps) {
  return (
    <header className="border-b border-cream-200 bg-cream-50/85 backdrop-blur-md sticky top-0 z-40 transition-all">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        {/* Brand Name */}
        <button 
          onClick={onGoHome}
          className="flex items-center space-x-3 group text-left focus:outline-none"
        >
          <div className="bg-ink-900 text-cream-50 p-1.5 rounded-sm transition-transform duration-500 group-hover:rotate-12">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-serif text-2xl font-semibold tracking-wide text-ink-900 leading-none">
              Memoir
            </h1>
            <p className="font-mono text-[9px] tracking-widest text-ink-500 uppercase mt-1">
              Memory Preservation
            </p>
          </div>
        </button>

        {/* User Account / Auth Section */}
        <div className="flex items-center space-x-4">
          {googleProfile ? (
            <div className="flex items-center space-x-3 bg-cream-100 border border-cream-200 px-3 py-1.5 rounded-full transition-all">
              {googleProfile.picture ? (
                <img 
                  src={googleProfile.picture} 
                  alt={googleProfile.name || "User Avatar"} 
                  referrerPolicy="no-referrer"
                  className="w-6 h-6 rounded-full object-cover border border-cream-300" 
                />
              ) : (
                <div className="w-6 h-6 rounded-full bg-sage text-cream-50 flex items-center justify-center font-serif text-xs font-semibold">
                  {(googleProfile.name || userEmail || "G").charAt(0).toUpperCase()}
                </div>
              )}
              <div className="flex flex-col text-left leading-none">
                <span className="font-sans text-[10px] font-semibold text-ink-900">
                  {googleProfile.name || "Google Photos Linked"}
                </span>
                <span className="font-mono text-[8px] text-zinc-500">
                  {googleProfile.email || userEmail}
                </span>
              </div>
              <button 
                onClick={onSignOut}
                title="Disconnect Google Photos"
                className="text-ink-500 hover:text-terracotta p-0.5 rounded transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : userEmail ? (
            <div className="flex items-center space-x-3 bg-cream-100 border border-cream-200 px-3 py-1.5 rounded-full transition-all">
              <div className="w-6 h-6 rounded-full bg-sage text-cream-50 flex items-center justify-center font-serif text-xs font-semibold">
                {userEmail.charAt(0).toUpperCase()}
              </div>
              <span className="font-sans text-xs font-medium text-ink-700 hidden sm:inline-block">
                {userEmail}
              </span>
              <button 
                onClick={onSignIn}
                title="Link Google Photos"
                className="text-terracotta hover:text-amber-800 font-mono text-[9px] uppercase tracking-wider font-semibold cursor-pointer ml-1"
              >
                Link Photos
              </button>
              <button 
                onClick={onSignOut}
                title="Sign Out"
                className="text-ink-500 hover:text-terracotta p-0.5 rounded transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={onSignIn}
              className="flex items-center space-x-2 text-xs font-medium bg-ink-900 text-cream-50 hover:bg-ink-700 px-4 py-2 rounded-sm transition-all shadow-sm active:scale-95 cursor-pointer"
            >
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                <path
                  fill="currentColor"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="currentColor"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="currentColor"
                  d="m5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22c-.08-.21-.14-.42-.14-.63z"
                />
                <path
                  fill="currentColor"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Connect Google Photos</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
