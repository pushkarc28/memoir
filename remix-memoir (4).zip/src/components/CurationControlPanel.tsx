import React, { useState, useEffect } from "react";
import { MemoirBook, Photo, BookSpread } from "../types";
import { 
  Database, 
  Sparkles, 
  Trash2, 
  Save, 
  Sliders, 
  BookOpen, 
  RefreshCw, 
  Clock, 
  MapPin, 
  Flame, 
  Check, 
  AlertCircle,
  ArrowUp,
  ArrowDown,
  PlusCircle,
  Type,
  Palette,
  Image as ImageIcon,
  Edit2,
  Calendar,
  X,
  ArrowLeftRight,
  Sparkle
} from "lucide-react";

interface CurationControlPanelProps {
  currentBook: MemoirBook | null;
  onLoadBook: (book: MemoirBook) => void;
  onUpdateBook: (book: MemoirBook) => void;
  literaryTone: string;
  onChangeTone: (tone: string) => void;
  fullPhotosPool?: Photo[];
}

export default function CurationControlPanel({
  currentBook,
  onLoadBook,
  onUpdateBook,
  literaryTone,
  onChangeTone,
  fullPhotosPool = []
}: CurationControlPanelProps) {
  const [savedBooks, setSavedBooks] = useState<MemoirBook[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'curator-studio' | 'drafts' | 'settings' | 'ai-logistics'>('curator-studio');
  const [addingPhotoSpreadId, setAddingPhotoSpreadId] = useState<string | null>(null);

  // Load saved drafts from our persistent backend api
  const fetchDrafts = async () => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/books");
      if (response.ok) {
        const data = await response.json();
        setSavedBooks(data);
      }
    } catch (err) {
      console.error("Error loading drafts from backend:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDrafts();
  }, [currentBook]);

  // Save current book state to backend
  const handleSaveToBackend = async () => {
    if (!currentBook) return;
    setIsSaving(true);
    setSaveSuccess(false);

    try {
      const response = await fetch("/api/books", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(currentBook)
      });

      if (response.ok) {
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
        fetchDrafts();
      }
    } catch (err) {
      console.error("Error saving book to backend database:", err);
      alert("Failed to synchronize curation draft to server.");
    } finally {
      setIsSaving(false);
    }
  };

  // Delete draft from backend database
  const handleDeleteDraft = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (!confirm("Are you sure you want to permanently delete this curation draft?")) return;

    try {
      const response = await fetch(`/api/books/${id}`, {
        method: "DELETE"
      });

      if (response.ok) {
        fetchDrafts();
      }
    } catch (err) {
      console.error("Error deleting book draft:", err);
    }
  };

  // Helper: Live Update of the memoir book properties directly triggering parent re-render
  const updateBookProp = (key: keyof MemoirBook, value: any) => {
    if (!currentBook) return;
    onUpdateBook({
      ...currentBook,
      [key]: value
    });
  };

  // Preset materials list for cover and pages
  const coverPresetColors = [
    { name: "Cream Cloth Linen 🍦", value: "#EDE5D8" },
    { name: "Terracotta Clay Velvet 🧱", value: "#B85E3B" },
    { name: "Kyoto Moss Sage 🌿", value: "#5D7A68" },
    { name: "Obsidian Charcoal Leather 🌑", value: "#1C1B19" },
    { name: "Warm Editorial Sand 🏜️", value: "#CCBAA4" },
    { name: "Royal Vintage Crimson 🍷", value: "#800020" }
  ];

  const pagePresetColors = [
    { name: "Warm Ivory Cream 🥛", value: "#FCFAF6" },
    { name: "Minimal Tokyo White 🍙", value: "#FFFFFF" },
    { name: "Soft Green Sage Mint 🍃", value: "#F1F5F2" },
    { name: "Warm Sepia Dust 🪵", value: "#FAF5EE" },
    { name: "Raw Newspaper Parchment 📜", value: "#F5EDDE" }
  ];

  const textPresetColors = [
    { name: "Classic Off-Black Ink ✒️", value: "#1C1B19" },
    { name: "Slate Off-Gray 🪵", value: "#3E3C38" },
    { name: "Warm Earthy Soil 🪨", value: "#564D4B" },
    { name: "Deep Navy Night 🌌", value: "#1A2535" }
  ];

  const presetFontPairings = [
    { name: "Playfair Display & Inter 📜", fontTitle: "serif", fontBody: "sans", desc: "Reflective and grand classic editorial feel" },
    { name: "JetBrains Mono & Inter 🎞️", fontTitle: "mono", fontBody: "sans", desc: "Contemporary visual poetry & artsy journal" },
    { name: "Sleek Modern Sans-Serif 🏙️", fontTitle: "sans", fontBody: "sans", desc: "Tokyo clean minimalist Swiss architecture" },
    { name: "Full Classical Script 🖋️", fontTitle: "serif", fontBody: "serif", desc: "Kinfolk archival bookmaking tradition" }
  ];

  // Preset designer motifs
  const presetMotifs = [
    { id: "none", name: "Clean Moleskine 📓", emoji: "📓", desc: "Pure high-contrast layout, sans decorations" },
    { id: "sakura", name: "Kyoto Sakura 🌸", emoji: "🌸", desc: "Warm foliage, Japanese architecture vibe" },
    { id: "mountain", name: "Alpine Exploration 🏔️", emoji: "🏔️", desc: "Adventure diary style with topographical stamp effects" },
    { id: "ocean", name: "Seaside Driftwood 🌊", emoji: "🌊", desc: "Coastal calmness with maritime stamps and waves" },
    { id: "cafe", name: "Tokyo Cafe Study ☕", emoji: "☕", desc: "Vintage coffee house markings and paper ring stains" },
    { id: "vintage", name: "Unedited Cine Film 🎞️", emoji: "🎞️", desc: "Retro cinematic film frames and lens stamp borders" },
    { id: "botanical", name: "Botanical Ivy Field 🌿", emoji: "🌿", desc: "Organic green plant motifs and botanical watermarks" }
  ];

  // Preset tones description
  const tonePresets = [
    { id: 'poetic', label: 'Poetic & Nostalgic 🌸', desc: 'Flowing sensory prose, focus on sunlight, warm recollections, and physical objects.' },
    { id: 'minimalist', label: 'Minimalist & Clear 🤍', desc: 'Brief, precise reflections focusing on pure geometry, time stamps, and silent spaces.' },
    { id: 'journalistic', label: 'Journalistic Diary 📸', desc: 'Human-centric stories, record of locations visited, conversational habits, and active adventures.' },
    { id: 'whimsical', label: 'Cosmic & Dreamy ✨', desc: 'Artistic metaphors, playful pairings, describing color palettes and emotional frequencies.' }
  ];

  // LIVE SPREADS MANAGEMENT
  const handleUpdateSpreadCaption = (spreadId: string, text: string) => {
    if (!currentBook) return;
    const nextSpreads = currentBook.spreads.map(s => {
      if (s.id === spreadId) {
        return { ...s, caption: text };
      }
      return s;
    });
    updateBookProp("spreads", nextSpreads);
  };

  const handleUpdateSpreadLayout = (spreadId: string, layout: 'single' | 'double' | 'split-vertical') => {
    if (!currentBook) return;
    const nextSpreads = currentBook.spreads.map(s => {
      if (s.id === spreadId) {
        let nextPhotos = [...s.photos];
        if (layout === 'single' && nextPhotos.length > 1) {
          nextPhotos = [nextPhotos[0]];
        } else if (layout !== 'single' && nextPhotos.length === 1 && fullPhotosPool.length > 0) {
          const usedIds = new Set(currentBook.spreads.flatMap(sph => sph.photos.map(p => p.id)));
          const available = fullPhotosPool.filter(p => !usedIds.has(p.id));
          if (available.length > 0) {
            nextPhotos.push(available[0]);
          } else {
            nextPhotos.push(fullPhotosPool[0]); // fallback
          }
        }
        return { ...s, layout, photos: nextPhotos };
      }
      return s;
    });
    updateBookProp("spreads", nextSpreads);
  };

  const handleMoveSpread = (index: number, direction: 'up' | 'down') => {
    if (!currentBook) return;
    const nextSpreads = [...currentBook.spreads];
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= nextSpreads.length) return;

    // Swap spreads
    const temp = nextSpreads[index];
    nextSpreads[index] = nextSpreads[targetIdx];
    nextSpreads[targetIdx] = temp;

    // Re-assign pageNumbers starts at 3
    const renumbered = nextSpreads.map((s, idx) => ({
      ...s,
      pageNumber: idx + 3
    }));

    updateBookProp("spreads", renumbered);
  };

  const handleDeleteSpreadIdx = (index: number) => {
    if (!currentBook) return;
    if (!confirm("Remove this physical spread from the album?")) return;
    const nextSpreads = currentBook.spreads.filter((_, idx) => idx !== index);
    
    // Re-assign pageNumbers
    const renumbered = nextSpreads.map((s, idx) => ({
      ...s,
      pageNumber: idx + 3
    }));

    onUpdateBook({
      ...currentBook,
      spreads: renumbered,
      photoCount: renumbered.reduce((acc, s) => acc + s.photos.length, 0)
    });
  };

  const handleAddNewSpread = () => {
    if (!currentBook) return;
    
    // Pick 1-2 unused photos from photosPool or fullPhotosPool if possible
    const bookPhotoIds = new Set(currentBook.spreads.flatMap(s => s.photos.map(p => p.id)));
    const unusedPhotos = fullPhotosPool.filter(p => !bookPhotoIds.has(p.id));
    
    const assignedPhotos: Photo[] = [];
    if (unusedPhotos.length > 0) {
      assignedPhotos.push(unusedPhotos[0]);
    } else if (fullPhotosPool.length > 0) {
      assignedPhotos.push(fullPhotosPool[0]);
    }

    const newSpread: BookSpread = {
      id: `spread-${Date.now()}`,
      pageNumber: currentBook.spreads.length + 3,
      layout: 'single',
      photos: assignedPhotos,
      caption: "A quiet visual story fragment captured in time."
    };

    const nextSpreads = [...currentBook.spreads, newSpread];
    onUpdateBook({
      ...currentBook,
      spreads: nextSpreads,
      photoCount: nextSpreads.reduce((acc, s) => acc + s.photos.length, 0)
    });
  };

  // ADVANCED PHOTO REARRANGING ENGINE
  const handleRemovePhotoFromSpread = (spreadId: string, photoId: string) => {
    if (!currentBook) return;
    const nextSpreads = currentBook.spreads.map(s => {
      if (s.id === spreadId) {
        const nextPhotos = s.photos.filter(p => p.id !== photoId);
        return {
          ...s,
          photos: nextPhotos,
          layout: nextPhotos.length === 1 ? ('single' as const) : s.layout
        };
      }
      return s;
    });

    onUpdateBook({
      ...currentBook,
      spreads: nextSpreads,
      photoCount: nextSpreads.reduce((acc, s) => acc + s.photos.length, 0)
    });
  };

  const handleMovePhotoToSpread = (photoId: string, sourceSpreadId: string, targetSpreadId: string) => {
    if (!currentBook || !targetSpreadId) return;
    
    // Find the photo from active source
    const sourceSpread = currentBook.spreads.find(s => s.id === sourceSpreadId);
    if (!sourceSpread) return;
    const photoToMove = sourceSpread.photos.find(p => p.id === photoId);
    if (!photoToMove) return;

    const nextSpreads = currentBook.spreads.map(s => {
      // Remove from source
      if (s.id === sourceSpreadId) {
        const nextPhotos = s.photos.filter(p => p.id !== photoId);
        return {
          ...s,
          photos: nextPhotos,
          layout: nextPhotos.length === 1 ? ('single' as const) : s.layout
        };
      }
      // Add to target
      if (s.id === targetSpreadId) {
        const nextPhotos = [...s.photos, photoToMove];
        return {
          ...s,
          photos: nextPhotos,
          layout: nextPhotos.length > 1 ? ('double' as const) : s.layout
        };
      }
      return s;
    });

    onUpdateBook({
      ...currentBook,
      spreads: nextSpreads,
      photoCount: nextSpreads.reduce((acc, s) => acc + s.photos.length, 0)
    });
  };

  const handleAddPhotoToSpread = (spreadId: string, photo: Photo) => {
    if (!currentBook) return;
    const nextSpreads = currentBook.spreads.map(s => {
      if (s.id === spreadId) {
        if (s.photos.some(p => p.id === photo.id)) return s; // prevent duplicates
        const nextPhotos = [...s.photos, photo];
        return {
          ...s,
          photos: nextPhotos,
          layout: nextPhotos.length > 1 ? ('double' as const) : s.layout
        };
      }
      return s;
    });

    onUpdateBook({
      ...currentBook,
      spreads: nextSpreads,
      photoCount: nextSpreads.reduce((acc, s) => acc + s.photos.length, 0)
    });
  };

  return (
    <div className="bg-cream-100/60 border border-cream-200/80 rounded-md p-5 shadow-sm text-ink-900 mt-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-cream-200/80 pb-4 mb-4 gap-3">
        <div className="flex items-center space-x-2">
          <div className="bg-terracotta/10 p-1.5 rounded text-terracotta">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-serif text-lg font-semibold text-ink-950 flex items-center gap-1.5">
              Creator Studio &amp; Rearranging Engine 🖋️🎨
              <span className="font-mono text-[9px] bg-sage/10 text-sage uppercase px-1.5 py-0.5 rounded tracking-widest leading-none">
                Interactive Studio
              </span>
            </h3>
            <p className="font-sans text-xs text-ink-500">
              Fine-tune, move photos across sheets, apply designer graphic watermarks, and insert new pages.
            </p>
          </div>
        </div>

        {/* Sync Current Button */}
        {currentBook && (
          <button
            onClick={handleSaveToBackend}
            disabled={isSaving}
            className={`flex items-center space-x-2 px-4 py-2 text-xs font-mono uppercase tracking-wider rounded border transition-all cursor-pointer ${
              saveSuccess 
                ? "bg-sage text-cream-50 border-sage" 
                : "bg-ink-950 text-cream-50 border-ink-950 hover:bg-ink-800"
            }`}
          >
            {isSaving ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : saveSuccess ? (
              <Check className="w-3.5 h-3.5" />
            ) : (
              <Save className="w-3.5 h-3.5 text-cream-400" />
            )}
            <span>{saveSuccess ? "Synced to server ✓" : "Sync Edits to Backend"}</span>
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-1 border-b border-cream-200/60 mb-4 pb-px">
        <button
          onClick={() => { setActiveTab('curator-studio'); setAddingPhotoSpreadId(null); }}
          className={`px-4 py-2 font-mono text-xs uppercase tracking-widest border-b-2 transition-all cursor-pointer ${
            activeTab === 'curator-studio' 
              ? "border-terracotta text-ink-950 font-bold" 
              : "border-transparent text-ink-500 hover:text-ink-800"
          }`}
        >
          <span className="flex items-center space-x-1.5">
            <Sliders className="w-3.5 h-3.5" />
            <span>Album Curator Studio 🎨</span>
          </span>
        </button>

        <button
          onClick={() => setActiveTab('drafts')}
          className={`px-4 py-2 font-mono text-xs uppercase tracking-widest border-b-2 transition-all cursor-pointer ${
            activeTab === 'drafts' 
              ? "border-terracotta text-ink-950 font-bold" 
              : "border-transparent text-ink-500 hover:text-ink-800"
          }`}
        >
          <span className="flex items-center space-x-1.5">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Saved Drafts ({savedBooks.length}) 📓</span>
          </span>
        </button>

        <button
          onClick={() => { setActiveTab('settings'); setAddingPhotoSpreadId(null); }}
          className={`px-4 py-2 font-mono text-xs uppercase tracking-widest border-b-2 transition-all cursor-pointer ${
            activeTab === 'settings' 
              ? "border-terracotta text-ink-950 font-bold" 
              : "border-transparent text-ink-500 hover:text-ink-800"
          }`}
        >
          <span className="flex items-center space-x-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Style &amp; Motif Options ✨</span>
          </span>
        </button>

        <button
          onClick={() => { setActiveTab('ai-logistics'); setAddingPhotoSpreadId(null); }}
          className={`px-4 py-2 font-mono text-xs uppercase tracking-widest border-b-2 transition-all cursor-pointer ${
            activeTab === 'ai-logistics' 
              ? "border-terracotta text-ink-950 font-bold" 
              : "border-transparent text-ink-500 hover:text-ink-800"
          }`}
        >
          <span className="flex items-center space-x-1.5">
            <Clock className="w-3.5 h-3.5" />
            <span>AI Storytelling Specs 🧭</span>
          </span>
        </button>
      </div>

      {/* NO BOOK LOADED SAFEGUARD FOR STUDIO */}
      {!currentBook && activeTab === 'curator-studio' && (
        <div className="text-center py-10 border border-dashed border-cream-300 rounded bg-cream-50/50">
          <BookOpen className="w-10 h-10 text-cream-400 mx-auto mb-3 animate-pulse" />
          <p className="font-serif text-sm text-ink-700 font-medium font-bold">No Active Album Loaded 🪵</p>
          <p className="font-sans text-xs text-ink-500 mt-1 max-w-md mx-auto">
            Curate your photobook first by linking your photos, or select a previously saved draft from the 
            <strong> Saved Drafts 📓</strong> tab.
          </p>
          <div className="mt-4">
            <button 
              onClick={() => setActiveTab('drafts')}
              className="px-4 py-2 border border-ink-950 font-mono text-xs uppercase tracking-wider rounded text-ink-950 hover:bg-cream-100/50"
            >
              Examine Saved Drafts
            </button>
          </div>
        </div>
      )}

      {/* CONTENT: ALBUM CURATOR STUDIO */}
      {currentBook && activeTab === 'curator-studio' && (
        <div className="grid lg:grid-cols-12 gap-6 items-start">
          
          {/* COLUMN 1: COVER & SHELL MATERIALS (col-span-4) */}
          <div className="lg:col-span-4 space-y-5 border-r border-cream-200 lg:pr-5">
            
            <span className="font-mono text-[9px] uppercase tracking-widest text-terracotta font-bold block mb-1">
              • Volume Metadata &amp; Shell Options
            </span>

            {/* Title / Subtitle */}
            <div className="space-y-3 p-3.5 bg-cream-50 rounded border border-cream-200">
              <div>
                <label className="font-mono text-[9px] text-ink-500 uppercase tracking-widest block mb-1">
                  Poetic Album Title 🖋️
                </label>
                <input
                  type="text"
                  value={currentBook.title}
                  onChange={(e) => updateBookProp("title", e.target.value)}
                  className="w-full font-serif text-sm p-2 bg-white border border-cream-200 rounded text-ink-950 font-bold focus:outline-none focus:border-terracotta"
                  placeholder="The Story of Light"
                />
              </div>

              <div>
                <label className="font-mono text-[9px] text-ink-500 uppercase tracking-widest block mb-1">
                  Album Poetic Subtitle 🎞️
                </label>
                <input
                  type="text"
                  value={currentBook.subtitle}
                  onChange={(e) => updateBookProp("subtitle", e.target.value)}
                  className="w-full font-serif italic text-xs p-2 bg-white border border-cream-200 rounded text-ink-750 focus:outline-none focus:border-terracotta"
                  placeholder="Minutes of Mornings"
                />
              </div>
            </div>

            {/* Opening Narrative */}
            <div className="p-3.5 bg-cream-50 rounded border border-cream-200">
              <label className="font-mono text-[9px] text-ink-500 uppercase tracking-widest block mb-1.5 flex justify-between">
                <span>Opening Preface Story (Page II) 🌟</span>
                <span className="text-terracotta lowercase font-sans font-normal italic">
                  {currentBook.openingNarrative.split(" ").length} words
                </span>
              </label>
              <textarea
                value={currentBook.openingNarrative}
                onChange={(e) => updateBookProp("openingNarrative", e.target.value)}
                className="w-full h-36 font-serif text-xs p-2 bg-white border border-cream-200 rounded text-ink-900 leading-relaxed focus:outline-none focus:border-terracotta"
                placeholder="A preface explaining the atmosphere of these pages..."
              />
            </div>

            {/* Designer Motif Select (Graphic Stamps Selection) */}
            <div className="p-3.5 bg-cream-50 rounded border border-cream-200">
              <label className="font-mono text-[10px] text-ink-950 uppercase tracking-widest block mb-3 font-bold flex items-center space-x-1">
                <Sparkle className="w-3.5 h-3.5 text-terracotta animate-pulse" />
                <span>Designer Motif &amp; Graphics 🌸</span>
              </label>
              
              <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
                {presetMotifs.map((motif) => (
                  <button
                    key={motif.id}
                    onClick={() => updateBookProp("motif", motif.id)}
                    className={`w-full p-2 border rounded text-left transition-all flex items-center justify-between cursor-pointer ${
                      (currentBook.motif || "none") === motif.id
                        ? "border-terracotta bg-white shadow-xs text-ink-950"
                        : "border-cream-200/80 bg-white/40 hover:bg-white text-ink-700"
                    }`}
                  >
                    <div>
                      <span className="font-serif text-[11px] font-bold block">{motif.name}</span>
                      <span className="font-sans text-[9px] text-zinc-400 block leading-none mt-0.5">{motif.desc}</span>
                    </div>
                    {(currentBook.motif || "none") === motif.id && (
                      <span className="text-xs bg-terracotta/10 text-terracotta p-0.5 rounded-full">✓</span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Typography pairings */}
            <div className="p-3.5 bg-cream-50 rounded border border-cream-200">
              <label className="font-mono text-[9px] text-ink-500 uppercase tracking-widest block mb-2 font-bold">
                Aesthetic Type Pairings 🖋️
              </label>
              <div className="space-y-1.5">
                {presetFontPairings.map((pair) => {
                  const isActive = (currentBook.fontTitle === pair.fontTitle) && (currentBook.fontBody === pair.fontBody);
                  return (
                    <div
                      key={pair.name}
                      onClick={() => {
                        onUpdateBook({
                          ...currentBook,
                          fontTitle: pair.fontTitle,
                          fontBody: pair.fontBody
                        });
                      }}
                      className={`border p-2 rounded cursor-pointer transition-all flex items-center justify-between text-left ${
                        isActive 
                          ? "border-terracotta bg-white shadow-sm" 
                          : "border-cream-200/80 bg-white/40 hover:bg-white/80"
                      }`}
                    >
                      <div className="overflow-hidden">
                        <span className="font-serif text-[11px] font-bold block text-ink-950">{pair.name}</span>
                        <span className="font-sans text-[9px] text-ink-400 block truncate leading-tight">{pair.desc}</span>
                      </div>
                      {isActive && <Check className="w-3.5 h-3.5 text-terracotta shrink-0" />}
                    </div>
                  );
                })}
              </div>
            </div>

          </div>

          {/* COLUMN 2: REALTIME PHOTO REARRANGING ENGINE & SPREADS (col-span-8) */}
          <div className="lg:col-span-8 space-y-4">
            
            <div className="flex justify-between items-center bg-cream-50 p-2.5 rounded border border-cream-200">
              <span className="font-mono text-[9px] uppercase tracking-widest text-terracotta font-bold flex items-center space-x-1">
                <span>• Live Interactive Leaf Foliage Editor ({currentBook.spreads.length} Spreads)</span>
              </span>

              <button
                type="button"
                onClick={handleAddNewSpread}
                className="flex items-center space-x-1.5 px-3 py-1 font-mono text-[10px] uppercase tracking-wider text-sage bg-sage/10 rounded-full hover:bg-sage/20 border border-sage/15 transition-all cursor-pointer"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>Add Empty Story Page ➕</span>
              </button>
            </div>

            {/* List of spreads */}
            <div className="space-y-4 max-h-[720px] overflow-y-auto pr-1">
              {currentBook.spreads.map((spread, sIdx) => {
                const pageText = `Pages ${spread.pageNumber}-${spread.pageNumber + 1}`;
                
                return (
                  <div 
                    key={spread.id} 
                    className="border border-cream-200 bg-white rounded p-4 shadow-sm space-y-3 relative group/item"
                  >
                    
                    {/* Spread Header Line */}
                    <div className="flex justify-between items-center pb-2 border-b border-cream-100">
                      <div className="flex items-center space-x-2">
                        <span className="font-mono text-[10px] bg-terracotta/10 text-terracotta rounded px-2.5 py-0.5 font-bold">
                          {pageText}
                        </span>
                        <span className="font-mono text-[9px] text-zinc-500 uppercase tracking-wider bg-cream-50 px-1.5 py-0.5 rounded">
                          [{spread.layout}]
                        </span>
                      </div>

                      {/* Moving Controls & Delete */}
                      <div className="flex items-center space-x-1">
                        <button
                          type="button"
                          disabled={sIdx === 0}
                          onClick={() => handleMoveSpread(sIdx, 'up')}
                          className="p-1 border border-cream-200 rounded hover:bg-cream-50 text-ink-500 disabled:opacity-20 cursor-pointer"
                          title="Move Spread Up"
                        >
                          <ArrowUp className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          disabled={sIdx === currentBook.spreads.length - 1}
                          onClick={() => handleMoveSpread(sIdx, 'down')}
                          className="p-1 border border-cream-200 rounded hover:bg-cream-50 text-ink-500 disabled:opacity-20 cursor-pointer"
                          title="Move Spread Down"
                        >
                          <ArrowDown className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteSpreadIdx(sIdx)}
                          className="p-1 border border-cream-200 rounded text-rose-600 hover:bg-rose-50 hover:border-rose-200 cursor-pointer"
                          title="Delete Leaf Spread"
                        >
                          <Trash2 className="w-3" />
                        </button>
                      </div>
                    </div>

                    {/* Layout selection */}
                    <div className="grid grid-cols-12 gap-3 bg-cream-50/50 p-2 rounded">
                      <div className="col-span-12">
                        <label className="font-mono text-[8px] text-zinc-400 uppercase block mb-1">Foliar Frame Layout Structure</label>
                        <div className="flex gap-2">
                          {(['single', 'double', 'split-vertical'] as const).map((l) => (
                            <button
                              key={l}
                              type="button"
                              onClick={() => handleUpdateSpreadLayout(spread.id, l)}
                              className={`flex-1 py-1 px-2 border rounded font-mono text-[9px] uppercase cursor-pointer text-center ${
                                spread.layout === l 
                                  ? "bg-stone-900 border-stone-900 text-white" 
                                  : "bg-white border-cream-200 text-stone-600 hover:bg-cream-100/50"
                              }`}
                            >
                              {l === 'single' ? "Single + Story" : l === 'double' ? "Double Spanned" : "Split Vertical"}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* DETAIL IMAGES REARRANGING CONTROLS FOR THIS PAGE */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-mono text-[9px] text-zinc-400 uppercase">Photos On This Page ({spread.photos.length})</span>
                        
                        {/* Add picture to spread button */}
                        <button
                          type="button"
                          onClick={() => setAddingPhotoSpreadId(addingPhotoSpreadId === spread.id ? null : spread.id)}
                          className="text-[9.5px] font-mono text-sage hover:underline flex items-center space-x-1 cursor-pointer"
                        >
                          <PlusCircle className="w-3 h-3" />
                          <span>{addingPhotoSpreadId === spread.id ? "Done" : "➕ Add Photo to Page"}</span>
                        </button>
                      </div>

                      {/* Display Photos list inside this spread */}
                      {spread.photos.length === 0 ? (
                        <div className="text-center py-4 border border-dashed border-cream-200 rounded text-xs text-zinc-400 font-serif">
                          No images placed on this leaf yet. Click "+ Add Photo To Page" below.
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {spread.photos.map((ph) => (
                            <div key={ph.id} className="flex items-center justify-between border border-cream-100 bg-cream-50/30 p-2 rounded transition-all">
                              <div className="flex items-center space-x-2">
                                <img src={ph.url} className="w-10 h-10 object-cover rounded shadow-xs shrink-0" alt="thumbnail" />
                                <div className="leading-tight">
                                  <span className="font-serif text-[10.5px] block font-semibold text-ink-900 truncate max-w-[120px]">
                                    {ph.location || "Preserved Snapshot"}
                                  </span>
                                  <span className="font-mono text-[8px] text-ink-400 block uppercase">
                                    {ph.category || "Moment"} • {ph.aspectRatio}
                                  </span>
                                </div>
                              </div>

                              {/* Rearranging Actions */}
                              <div className="flex items-center space-x-2 shrink-0">
                                {/* Move Target Dropdown Selector */}
                                <div className="flex items-center space-x-1">
                                  <ArrowLeftRight className="w-3 h-3 text-zinc-400" />
                                  <select
                                    onChange={(e) => {
                                      if (e.target.value) {
                                        handleMovePhotoToSpread(ph.id, spread.id, e.target.value);
                                        e.target.value = ""; // reset
                                      }
                                    }}
                                    defaultValue=""
                                    className="text-[10px] font-mono border border-cream-200 bg-white text-zinc-700 px-1 py-0.5 rounded focus:outline-none"
                                  >
                                    <option value="" disabled>Move to Sheet...</option>
                                    {currentBook.spreads
                                      .filter(oth => oth.id !== spread.id)
                                      .map(oth => (
                                        <option key={oth.id} value={oth.id}>
                                          Pages {oth.pageNumber}-{oth.pageNumber + 1}
                                        </option>
                                      ))
                                    }
                                  </select>
                                </div>

                                {/* Remove Image Button */}
                                <button
                                  type="button"
                                  onClick={() => handleRemovePhotoFromSpread(spread.id, ph.id)}
                                  className="p-1 text-zinc-400 hover:text-red-600 hover:bg-red-50 rounded"
                                  title="Unplace from this page"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Photo addition picker drawer inside this spread */}
                      {addingPhotoSpreadId === spread.id && (
                        <div className="bg-cream-50 p-2.5 rounded border border-cream-200 space-y-2 animate-fadeIn">
                          <span className="font-mono text-[8px] text-terracotta uppercase font-bold block mb-1">
                            Click Photo to Put on Page
                          </span>
                          
                          <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 max-h-[140px] overflow-y-auto pr-1">
                            {fullPhotosPool.map((phCandidate) => {
                              // Identify if already on this spread
                              const isPlacedOnThisSpread = spread.photos.some(p => p.id === phCandidate.id);
                              
                              return (
                                <div
                                  key={phCandidate.id}
                                  onClick={() => handleAddPhotoToSpread(spread.id, phCandidate)}
                                  className={`relative aspect-square rounded overflow-hidden border cursor-pointer hover:scale-102 transition-all ${
                                    isPlacedOnThisSpread 
                                      ? "opacity-40 border-sage" 
                                      : "border-cream-300 hover:border-terracotta"
                                  }`}
                                  title={phCandidate.location || "Preserved Moment"}
                                >
                                  <img src={phCandidate.url} className="w-full h-full object-cover" alt="stamp candidate" />
                                  {isPlacedOnThisSpread && (
                                    <div className="absolute inset-0 bg-sage/20 flex items-center justify-center">
                                      <span className="text-[8px] font-mono text-sage bg-white/95 px-1 py-0.5 rounded leading-none">Placed</span>
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Caption edit text */}
                    <div>
                      <label className="font-mono text-[8px] text-zinc-400 uppercase block mb-1">
                        Leaf Caption Line/Poetry 🌸
                      </label>
                      <input
                        type="text"
                        value={spread.caption}
                        onChange={(e) => handleUpdateSpreadCaption(spread.id, e.target.value)}
                        className="w-full font-serif italic text-[11px] p-2 bg-cream-50/40 border border-cream-200 rounded text-ink-900 focus:outline-none focus:border-terracotta"
                        placeholder="Poetic descriptive caption for facing margins..."
                      />
                    </div>

                  </div>
                );
              })}
            </div>

            <div className="p-3.5 bg-sage/5 border border-sage/20 rounded text-sage text-[11px] flex items-center space-x-2 font-mono">
              <Sliders className="w-3.5 h-3.5 text-sage" />
              <span>All changes you make to photos position and layout sync and render instantly into the physical book up above!</span>
            </div>

          </div>

        </div>
      )}

      {/* CONTENT: DRAFTS LIST */}
      {activeTab === 'drafts' && (
        <div className="space-y-3">
          {isLoading ? (
            <div className="text-center py-6">
              <RefreshCw className="w-5 h-5 animate-spin mx-auto text-ink-500" />
              <p className="text-xs font-mono text-ink-550 mt-1">Reading database store...</p>
            </div>
          ) : savedBooks.length === 0 ? (
            <div className="text-center py-8 border border-dashed border-cream-300 rounded bg-cream-50/50">
              <BookOpen className="w-8 h-8 text-cream-400 mx-auto mb-2" />
              <p className="font-serif text-sm text-ink-700 font-medium">No saved books in backend DB yet 📁</p>
              <p className="font-sans text-xs text-ink-400 mt-1">
                Your manual edits (captions change, cover headings, story writeups) will be persistent here when you click sync.
              </p>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 gap-4">
              {savedBooks.map((b) => (
                <div
                  key={b.id}
                  onClick={() => onLoadBook(b)}
                  className={`border p-4 rounded bg-cream-50/75 flex justify-between items-start cursor-pointer hover:shadow-sm hover:border-terracotta transition-all ${
                    currentBook?.id === b.id ? "border-terracotta ring-1 ring-terracotta/20 bg-cream-50" : "border-cream-300/80"
                  }`}
                >
                  <div className="space-y-1.5 overflow-hidden">
                    <div className="flex items-center space-x-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-sage shrink-0"></span>
                      <h4 className="font-serif text-sm font-semibold truncate text-ink-900">
                        {b.title}
                      </h4>
                    </div>
                    <p className="font-serif italic text-xs text-ink-500 truncate">{b.subtitle}</p>
                    <div className="flex items-center gap-3 font-mono text-[9px] text-zinc-500 uppercase pt-2">
                      <span>{b.spreads?.length || 0} spreads</span>
                      <span>•</span>
                      <span>{b.photoCount || 0} photos</span>
                      <span>•</span>
                      <span className="truncate max-w-[80px]">Theme: {b.motif || "Clean"}</span>
                    </div>
                  </div>

                  <button
                    onClick={(e) => handleDeleteDraft(e, b.id)}
                    className="p-1 px-1.5 border border-cream-200 text-ink-400 hover:text-rose-700 hover:border-rose-100 hover:bg-rose-50 rounded"
                    title="Delete Draft"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* CONTENT: SETTINGS & COVER/TEXT/BACKGROUND COLOR PRESETS */}
      {activeTab === 'settings' && (
        <div className="space-y-5">
          <p className="font-sans text-xs text-ink-600 leading-relaxed max-w-2xl">
            Choose the literary voice for the Gemini narrative model and configure core canvas layout hues, paper fibers, and designer accents.
          </p>

          <div className="grid md:grid-cols-3 gap-4">
            
            {/* Cover materials column */}
            <div className="bg-cream-50 p-3.5 border border-cream-200 rounded space-y-3">
              <label className="font-mono text-[9px] text-ink-500 uppercase tracking-widest block font-bold">
                Cover Velvet & Linen (Physical Cover) 📓
              </label>
              <div className="grid grid-cols-2 gap-2">
                {coverPresetColors.map((color) => {
                  const isActive = (currentBook?.coverColor || '#EDE5D8') === color.value;
                  return (
                    <button
                      key={color.value}
                      onClick={() => updateBookProp("coverColor", color.value)}
                      style={{ backgroundColor: color.value }}
                      className={`h-11 rounded border relative group transition-all text-left p-1 ${
                        isActive ? "ring-2 ring-terracotta border-white scale-102" : "border-cream-300"
                      }`}
                    >
                      <span className="text-[8px] font-sans block text-white font-bold leading-none select-none mix-blend-difference">
                        {color.name.split(" ").slice(0, 2).join(" ")}
                      </span>
                      {isActive && <Check className="w-3 h-3 text-white absolute bottom-1 right-1 mix-blend-difference" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Paper custom color */}
            <div className="bg-cream-50 p-3.5 border border-cream-200 rounded space-y-3">
              <label className="font-mono text-[9px] text-ink-500 uppercase tracking-widest block font-bold">
                Foliar Paper Stock Color 📜
              </label>
              <div className="grid grid-cols-2 gap-2">
                {pagePresetColors.map((color) => {
                  const isActive = (currentBook?.pageColor || '#FCFAF6') === color.value;
                  return (
                    <button
                      key={color.value}
                      onClick={() => updateBookProp("pageColor", color.value)}
                      style={{ backgroundColor: color.value }}
                      className={`h-11 rounded border relative group transition-all text-left p-1 ${
                        isActive ? "ring-2 ring-sage border-white scale-102" : "border-cream-300"
                      }`}
                    >
                      <span className="text-[8px] font-sans block text-black font-bold leading-none select-none mix-blend-difference">
                        {color.name.split(" ").slice(0, 2).join(" ")}
                      </span>
                      {isActive && <Check className="w-3 h-3 text-black absolute bottom-1 right-1 mix-blend-difference" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Text font color preset */}
            <div className="bg-cream-50 p-3.5 border border-cream-200 rounded space-y-3">
              <label className="font-mono text-[9px] text-ink-500 uppercase tracking-widest block font-bold">
                Ink Color &amp; Tone Accent 🌌
              </label>
              <div className="grid grid-cols-2 gap-2">
                {textPresetColors.map((color) => {
                  const isActive = (currentBook?.textColor || '#1C1B19') === color.value;
                  return (
                    <button
                      key={color.value}
                      onClick={() => updateBookProp("textColor", color.value)}
                      style={{ backgroundColor: color.value }}
                      className={`h-11 rounded border relative group transition-all text-left p-1 ${
                        isActive ? "ring-2 ring-ink-950 border-white scale-102" : "border-cream-300"
                      }`}
                    >
                      <span className="text-[8px] font-sans block text-white font-bold leading-none select-none mix-blend-difference">
                        {color.name.split(" ").slice(0, 2).join(" ")}
                      </span>
                      {isActive && <Check className="w-3 h-3 text-white absolute bottom-1 right-1 mix-blend-difference" />}
                    </button>
                  );
                })}
              </div>
            </div>

          </div>

          {/* Tone Presets list */}
          <div className="bg-cream-50 p-4 border border-cream-200 rounded space-y-3">
            <label className="font-mono text-[10px] text-ink-950 uppercase tracking-widest block font-bold">
              AI Story Writer Voice Vibe ✍️
            </label>
            <div className="grid md:grid-cols-2 gap-3">
              {tonePresets.map((t) => (
                <div
                  key={t.id}
                  onClick={() => onChangeTone(t.id)}
                  className={`border p-3.5 rounded-sm cursor-pointer transition-all flex flex-col justify-between ${
                    literaryTone === t.id 
                      ? "border-terracotta bg-white ring-1 ring-terracotta/20" 
                      : "bg-white/40 hover:bg-white"
                  }`}
                >
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <h4 className="font-serif text-sm font-semibold text-ink-900">{t.label}</h4>
                      {literaryTone === t.id && (
                        <span className="bg-terracotta/10 text-terracotta p-0.5 rounded-full">✓</span>
                      )}
                    </div>
                    <p className="font-sans text-xs text-ink-500 leading-relaxed mt-1">
                      {t.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center space-x-2.5 p-3 rounded bg-sage/5 border border-sage/20 text-sage-900 mt-2 max-w-xl">
            <Sliders className="w-4 h-4 text-sage shrink-0" />
            <p className="font-mono text-[10px] leading-relaxed">
              Active Parameters: <code>MODEL: gemini-3.5-flash</code> | <code>MIME: application/json</code> | <code>TEMP: 0.75</code>
            </p>
          </div>
        </div>
      )}

      {/* CONTENT: AI ALBUM CREATION LOGIC */}
      {activeTab === 'ai-logistics' && (
        <div className="space-y-4 font-sans text-xs text-ink-700 leading-relaxed max-w-3xl">
          <h4 className="font-serif text-sm font-semibold text-ink-950 mb-1">
            How does our Memoir AI convert raw photos into clothbound books? 📜🧭
          </h4>
          
          <div className="grid sm:grid-cols-3 gap-4 py-2">
            <div className="border border-cream-200 bg-cream-50 p-3.5 rounded">
              <div className="flex items-center space-x-1 text-terracotta font-mono font-bold tracking-wider text-[10px] uppercase mb-1.5">
                <Clock className="w-3.5 h-3.5" />
                <span>1. Time Clustering ⏱️</span>
              </div>
              <p className="text-ink-550 leading-relaxed text-[11px]">
                The curator parses photo timestamps to identify active days and quiet evenings. High photo-density intervals form individual chapters.
              </p>
            </div>

            <div className="border border-cream-200 bg-cream-50 p-3.5 rounded">
              <div className="flex items-center space-x-1 text-terracotta font-mono font-bold tracking-wider text-[10px] uppercase mb-1.5">
                <MapPin className="w-3.5 h-3.5" />
                <span>2. Geo Alignment 🗺️</span>
              </div>
              <p className="text-ink-550 leading-relaxed text-[11px]">
                Metadata locations (Paris, local cafe, coast roads) are reverse-geocoded to create authentic regional volume titles instead of generic dates.
              </p>
            </div>

            <div className="border border-cream-200 bg-cream-50 p-3.5 rounded">
              <div className="flex items-center space-x-1 text-terracotta font-mono font-bold tracking-wider text-[10px] uppercase mb-1.5">
                <Flame className="w-3.5 h-3.5" />
                <span>3. Aspect Sizing 📐</span>
              </div>
              <p className="text-ink-550 leading-relaxed text-[11px]">
                Landscape aspect ratio snapshots are assigned grand double-page spreads, while split portrait images map side-by-side vertical foliage.
              </p>
            </div>
          </div>

          <div className="p-4 bg-cream-50 rounded border border-cream-200/60 max-w-2xl font-serif italic text-ink-800 leading-relaxed">
            "By looking at parameters together—such as coffee category flags combined with early morning time signatures—the curator knows to structure a 'morning awakenings' spread, composing poetic lines to fit the quiet atmosphere."
          </div>
        </div>
      )}
    </div>
  );
}
