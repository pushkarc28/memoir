import React, { useState, useRef, useEffect } from "react";
import { Photo } from "../types";
import { mockAlbums, PhotoAlbum } from "../mockPhotos";
import { 
  FolderHeart, 
  Upload, 
  Check, 
  Sparkles, 
  Plus, 
  Calendar, 
  MapPin, 
  Image as ImageIcon,
  ChevronRight,
  RefreshCw,
  AlertCircle,
  Unlink,
  Link
} from "lucide-react";

interface PhotosPickerProps {
  onPhotosSelected: (albumName: string, selectedPhotos: Photo[]) => void;
  googleToken?: string | null;
  googleProfile?: any | null;
  onDisconnectGoogle?: () => void;
}

export default function PhotosPicker({ 
  onPhotosSelected, 
  googleToken, 
  googleProfile, 
  onDisconnectGoogle 
}: PhotosPickerProps) {
  const [selectedAlbum, setSelectedAlbum] = useState<PhotoAlbum | null>(null);
  const [photosPool, setPhotosPool] = useState<Photo[]>([]);
  const [checkedPhotoIds, setCheckedPhotoIds] = useState<Set<string>>(new Set());
  const [customPhotos, setCustomPhotos] = useState<Photo[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  // Tabs: 'local' | 'google'
  const [activeTab, setActiveTab] = useState<'local' | 'google'>(googleToken ? 'google' : 'local');
  
  // Google Photos integration states
  const [googleAlbums, setGoogleAlbums] = useState<any[]>([]);
  const [loadingGoogleAlbums, setLoadingGoogleAlbums] = useState(false);
  const [loadingGooglePhotos, setLoadingGooglePhotos] = useState(false);
  const [errorText, setErrorText] = useState<string | null>(null);

  // Sync active tab to google if user just logged in
  useEffect(() => {
    if (googleToken) {
      setActiveTab('google');
    } else {
      setActiveTab('local');
    }
  }, [googleToken]);

  // Fetch Google Photos Albums when activeTab becomes 'google'
  useEffect(() => {
    if (googleToken && activeTab === 'google') {
      fetchGoogleAlbums();
    }
  }, [googleToken, activeTab]);

  const fetchGoogleAlbums = async () => {
    setLoadingGoogleAlbums(true);
    setErrorText(null);
    try {
      const response = await fetch("/api/google-photos/albums", {
        headers: {
          "Authorization": `Bearer ${googleToken}`
        }
      });
      if (!response.ok) {
        throw new Error("Unable to retrieve your Google Albums. Please check application authorization or re-connect.");
      }
      const data = await response.json();
      setGoogleAlbums(data);
    } catch (err: any) {
      console.error(err);
      setErrorText(err.message || "Failed to fetch Google Photos albums.");
    } finally {
      setLoadingGoogleAlbums(false);
    }
  };

  // Google Album Photoselection extraction
  const handleSelectGoogleAlbum = async (gAlbum: any) => {
    setLoadingGooglePhotos(true);
    setErrorText(null);
    
    const albumTitle = gAlbum.title || "Google Album";
    const albumRep: PhotoAlbum = {
      id: gAlbum.id,
      name: albumTitle,
      description: `Linked Google Album with ${gAlbum.mediaItemsCount || 0} media assets.`,
      coverUrl: gAlbum.coverPhotoBaseUrl ? `${gAlbum.coverPhotoBaseUrl}=w500` : "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=500",
      photos: []
    };
    
    setSelectedAlbum(albumRep);

    try {
      const response = await fetch(`/api/google-photos/album-photos?albumId=${gAlbum.id}`, {
        headers: {
          "Authorization": `Bearer ${googleToken}`
        }
      });
      if (!response.ok) {
        throw new Error("Google Photos API error while fetching folder assets.");
      }
      const pData = await response.json();
      setPhotosPool(pData);
      // Automatically select all found items to make book assembly intuitive
      setCheckedPhotoIds(new Set(pData.map((p: any) => p.id)));
    } catch (err: any) {
      console.error(err);
      setErrorText(err.message || "Could not retrieve photos from Google Photos folder.");
      setSelectedAlbum(null);
    } finally {
      setLoadingGooglePhotos(false);
    }
  };

  // Automatic extraction of all photos (Feed Photos)
  const handleExtractAllLibraryPhotos = async () => {
    setLoadingGooglePhotos(true);
    setErrorText(null);
    
    const albumRep: PhotoAlbum = {
      id: "google-feed",
      name: "Recent Google Photos Feed",
      description: "Automatically extracted high resolution assets from your Google Photos stream.",
      coverUrl: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=500",
      photos: []
    };
    
    setSelectedAlbum(albumRep);

    try {
      const response = await fetch("/api/google-photos/all-photos", {
        headers: {
          "Authorization": `Bearer ${googleToken}`
        }
      });
      if (!response.ok) {
        throw new Error("Unable to call Google API to sync stream elements.");
      }
      const pData = await response.json();
      setPhotosPool(pData);
      setCheckedPhotoIds(new Set(pData.map((p: any) => p.id)));
    } catch (err: any) {
      console.error(err);
      setErrorText(err.message || "Failed to extract Google Photos feed.");
      setSelectedAlbum(null);
    } finally {
      setLoadingGooglePhotos(false);
    }
  };

  // When standard local album is chosen
  const handleSelectAlbum = (album: PhotoAlbum) => {
    setSelectedAlbum(album);
    
    const mergedPhotos = [...album.photos];
    if (album.id !== "custom-volume") {
      customPhotos.forEach(cp => {
        if (cp.category === 'custom' && !mergedPhotos.some(p => p.id === cp.id)) {
          mergedPhotos.push(cp);
        }
      });
    }
    setPhotosPool(mergedPhotos);
    
    const defaultIds = album.photos.map(p => p.id);
    const customIds = customPhotos.map(p => p.id);
    setCheckedPhotoIds(new Set([...defaultIds, ...customIds]));
  };

  const handleTogglePhoto = (id: string) => {
    const next = new Set(checkedPhotoIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setCheckedPhotoIds(next);
  };

  const handleSelectAll = () => {
    if (checkedPhotoIds.size === photosPool.length) {
      setCheckedPhotoIds(new Set());
    } else {
      setCheckedPhotoIds(new Set(photosPool.map(p => p.id)));
    }
  };

  // Process custom file upload triggers
  const handleFiles = async (files: FileList) => {
    const compressAndResizeImage = (file: File, maxW = 1200, maxH = 1200, quality = 0.8): Promise<string> => {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
          const img = new Image();
          img.onload = () => {
            let width = img.width;
            let height = img.height;
            
            if (width > maxW || height > maxH) {
              const ratio = Math.min(maxW / width, maxH / height);
              width = Math.round(width * ratio);
              height = Math.round(height * ratio);
            }
            
            const canvas = document.createElement("canvas");
            canvas.width = width;
            canvas.height = height;
            
            const ctx = canvas.getContext("2d");
            if (!ctx) {
              // fallback to raw base64 if canvas drawing fails
              resolve(e.target?.result as string);
              return;
            }
            
            ctx.drawImage(img, 0, 0, width, height);
            
            // Output as JPEG to guarantee high quality at low weight
            resolve(canvas.toDataURL("image/jpeg", quality));
          };
          img.onerror = reject;
          img.src = e.target?.result as string;
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
    };

    const newPhotos: Photo[] = [];
    const dateNow = new Date();
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        const url = await compressAndResizeImage(file);
        
        const randomOffsetDays = Math.floor(Math.random() * 30);
        const fileDate = new Date(dateNow.getTime() - randomOffsetDays * 24 * 60 * 60 * 1000);
        
        const locations = ["Coastal Haven", "Familiar Courtyard", "Street Vista", "Cozy Hearth", "High Peak"];
        const randomLocation = locations[Math.floor(Math.random() * locations.length)];
        
        const randStr = Math.random().toString(36).substring(2, 9);
        newPhotos.push({
          id: `custom-${customPhotos.length + i}-${Date.now()}-${randStr}`,
          url,
          timestamp: fileDate.toISOString(),
          location: randomLocation,
          category: "custom",
          aspectRatio: "landscape"
        });
      } catch (err) {
        console.error("Error converting/compressing file:", err);
      }
    }

    setCustomPhotos(prev => [...prev, ...newPhotos]);
    setPhotosPool(prev => [...prev, ...newPhotos]);
    setCheckedPhotoIds(prev => {
      const next = new Set(prev);
      newPhotos.forEach(p => next.add(p.id));
      return next;
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const handleAssemble = () => {
    const finalSelected = photosPool.filter(p => checkedPhotoIds.has(p.id));
    if (finalSelected.length === 0) return;
    const albumTitle = selectedAlbum ? selectedAlbum.name : "Custom Memoir";
    onPhotosSelected(albumTitle, finalSelected);
  };

  const triggerAppOAuth = async () => {
    // Call the parent window triggers to display credentials screen popup
    const headerBtn = document.querySelector('[title="Link Google Photos"]') || document.querySelector('button :contains("Connect")');
    if (headerBtn) {
      (headerBtn as HTMLButtonElement).click();
    } else {
      // Direct call fallback
      try {
        const res = await fetch("/api/auth/google/url");
        if (res.ok) {
          const data = await res.json();
          window.open(data.url, "Google Photos Authentication", "width=600,height=700");
        }
      } catch (e) {
        console.error(e);
      }
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-6">
      
      {/* Tab Selectors & OAuth State indicator */}
      {!selectedAlbum && (
        <div className="flex flex-col sm:flex-row items-center justify-between border-b border-cream-200 pb-4 mb-8 gap-4">
          <div className="flex bg-cream-100 p-1 rounded-md">
            <button
              onClick={() => setActiveTab('local')}
              className={`px-4 py-2 font-serif text-xs font-semibold rounded transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'local' 
                  ? "bg-cream-50 text-ink-900 shadow-sm" 
                  : "text-ink-500 hover:text-ink-900"
              }`}
            >
              Demo Volumes
            </button>
            <button
              onClick={() => setActiveTab('google')}
              className={`px-4 py-2 font-serif text-xs font-semibold rounded transition-all whitespace-nowrap flex items-center space-x-1.5 cursor-pointer ${
                activeTab === 'google' 
                  ? "bg-cream-50 text-ink-900 shadow-sm" 
                  : "text-ink-500 hover:text-ink-900"
              }`}
            >
              <svg className="w-3.5 h-3.5 text-terracotta" viewBox="0 0 24 24">
                <path
                  fill="currentColor"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="currentColor"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="currentColor"
                  d="m5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22c-.08-.21-.14-.42-.14-.63z"
                />
                <path
                  fill="currentColor"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Google Photos</span>
              {googleToken && (
                <span className="w-1.5 h-1.5 rounded-full bg-sage animate-pulse"></span>
              )}
            </button>
          </div>

          {googleToken && onDisconnectGoogle && (
            <button
              onClick={onDisconnectGoogle}
              className="flex items-center space-x-1 font-mono text-[9px] uppercase tracking-wider text-ink-500 hover:text-terracotta cursor-pointer"
            >
              <Unlink className="w-3 h-3 text-terracotta" />
              <span>Unlink Google Account</span>
            </button>
          )}
        </div>
      )}

      {!selectedAlbum ? (
        /* SCREEN 1: Album List Cover */
        <div>
          {activeTab === 'google' && !googleToken ? (
            /* Google Photos CTA Screen when unconnected */
            <div className="max-w-md mx-auto text-center py-12 px-6 border border-cream-200 bg-cream-50 rounded-sm moleskine-shadow space-y-6">
              <div className="w-12 h-12 rounded-full bg-cream-100 flex items-center justify-center mx-auto text-terracotta border border-cream-200">
                <Link className="w-5 h-5 text-terracotta" />
              </div>
              <div className="space-y-2">
                <h3 className="font-serif text-xl font-medium text-ink-900 leading-tight">
                  Link Google Photos Library
                </h3>
                <p className="font-sans text-xs text-ink-500 leading-relaxed">
                  Unlock dynamic and automated photo curations. Grant Memoir Read-Only credentials to extract high-resolution photos securely from your albums or catalog feed on a fly!
                </p>
              </div>
              
              <button
                onClick={triggerAppOAuth}
                className="inline-flex items-center space-x-2 bg-ink-900 hover:bg-ink-700 text-cream-50 font-sans text-xs font-semibold uppercase tracking-wider px-6 py-3 rounded-sm shadow cursor-pointer active:scale-95 transition-all"
              >
                <svg className="w-4 h-4 text-cream-50" viewBox="0 0 24 24">
                  <path
                    fill="currentColor"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="currentColor"
                    d="m5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22c-.08-.21-.14-.42-.14-.63z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Authorize Google Photos</span>
              </button>
              
              <div className="border-t border-cream-200/50 pt-4 flex items-center justify-center space-x-1 text-[9px] font-mono tracking-wide text-zinc-500 uppercase leading-none">
                <span>🔒 SECURE CONNECTION</span>
                <span className="w-1 h-1 rounded-full bg-cream-300"></span>
                <span>PCI COMPLIANT</span>
              </div>
            </div>
          ) : (
            /* Normal grid layouts */
            <div>
              <div className="text-center mb-8 max-w-lg mx-auto">
                <span className="font-serif italic text-xs text-terracotta bg-terracotta/5 px-3 py-1 rounded-full">
                  Begin your printed book
                </span>
                <h2 className="font-serif text-3xl font-medium tracking-tight text-ink-900 mt-2">
                  {activeTab === 'google' 
                    ? `Linked Google Library: ${googleProfile?.name || "Connected"}` 
                    : "Select a volume to assemble"}
                </h2>
                <p className="font-sans text-xs text-ink-500 mt-1.5 leading-relaxed">
                  {activeTab === 'google'
                    ? "Choose a photo folder from your Google Account, or use automatic streaming to harvest 100 recent photos instantly."
                    : "Use pre-made chapters or bound arbitrary files. The premium curation engine transforms raw frames into literary stories."}
                </p>
              </div>

              {errorText && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200/50 text-red-700 rounded-sm flex items-start space-x-3 max-w-xl mx-auto">
                  <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                  <div className="text-xs font-sans">
                    <p className="font-semibold">Sync Interrupted</p>
                    <p className="opacity-90 mt-0.5">{errorText}</p>
                    <button 
                      onClick={activeTab === 'google' ? fetchGoogleAlbums : () => setErrorText(null)}
                      className="font-mono underline uppercase font-bold text-[9px] block mt-2 text-red-900"
                    >
                      Try Again
                    </button>
                  </div>
                </div>
              )}

              {activeTab === 'google' ? (
                /* Google Albums Selector Grid */
                <div>
                  <div className="grid md:grid-cols-3 gap-6 mb-10">
                    
                    {/* Special Stream harvester Card */}
                    <button
                      onClick={handleExtractAllLibraryPhotos}
                      className="group text-left border border-amber-200/60 hover:border-terracotta bg-amber-50/20 hover:bg-amber-50/40 p-4 rounded-sm transition-all duration-300 relative moleskine-shadow hover:-translate-y-1 focus:outline-none flex flex-col justify-between min-h-[220px]"
                    >
                      <div>
                        {/* Premium custom representation banner */}
                        <div className="aspect-[4/3] w-full overflow-hidden rounded-sm bg-gradient-to-tr from-terracotta/50 to-sage/40 mb-4 relative flex items-center justify-center p-4">
                          <div className="text-center space-y-2">
                            <Sparkles className="w-8 h-8 text-terracotta mx-auto animate-pulse" />
                            <span className="font-mono text-[8px] uppercase tracking-widest text-ink-900 font-bold bg-cream-50 px-2 py-0.5 rounded shadow">
                              SUPERIOR MATCH
                            </span>
                          </div>
                        </div>

                        <h3 className="font-serif text-base font-bold text-ink-900 tracking-tight flex items-center space-x-1.5">
                          <span className="text-terracotta">✨</span>
                          <span>Auto-Extract Feed Stream</span>
                        </h3>
                        <p className="font-sans text-[11px] text-ink-600 mt-1 line-clamp-2 leading-relaxed">
                          No albums? No problem. Extracts 100 most recent snaps from your Google library feed and lets AI stitch them into an elegant memoir.
                        </p>
                      </div>

                      <div className="flex items-center text-xs font-semibold text-terracotta font-mono tracking-wider uppercase mt-4 group-hover:translate-x-1 transition-transform">
                        <span>Harvest Media Stream</span>
                        <ChevronRight className="w-3 h-3 ml-1" />
                      </div>
                    </button>

                    {/* Google albums loaded */}
                    {loadingGoogleAlbums ? (
                      /* Skeletons load effect */
                      Array.from({ length: 2 }).map((_, idx) => (
                        <div key={idx} className="border border-cream-200 bg-cream-50/50 p-4 rounded-sm animate-pulse flex flex-col space-y-4">
                          <div className="aspect-[4/3] w-full bg-cream-200 rounded-sm"></div>
                          <div className="h-4 bg-cream-200 rounded w-2/3"></div>
                          <div className="h-3 bg-cream-200 rounded w-1/2"></div>
                        </div>
                      ))
                    ) : googleAlbums.length > 0 ? (
                      googleAlbums.map((gAlbum) => (
                        <button
                          key={gAlbum.id}
                          onClick={() => handleSelectGoogleAlbum(gAlbum)}
                          className="group text-left border border-cream-200 hover:border-cream-400 bg-cream-50 hover:bg-cream-100/40 p-4 rounded-sm transition-all duration-300 pointer-events-auto moleskine-shadow hover:-translate-y-1 focus:outline-none flex flex-col justify-between min-h-[220px]"
                        >
                          <div>
                            <div className="aspect-[4/3] w-full overflow-hidden rounded-sm bg-neutral-100 mb-4 relative">
                              <img 
                                src={gAlbum.coverPhotoBaseUrl ? `${gAlbum.coverPhotoBaseUrl}=w400` : "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=400"} 
                                alt={gAlbum.title}
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover transition-all duration-700 group-hover:scale-105"
                              />
                              <div className="absolute top-2 right-2 bg-ink-900/40 backdrop-blur-sm text-cream-50 font-mono text-[9px] px-2 py-0.5 rounded-full flex items-center space-x-1">
                                <FolderHeart className="w-3 h-3 text-terracotta" />
                                <span>{gAlbum.mediaItemsCount || 0} photos</span>
                              </div>
                            </div>
                            <h3 className="font-serif text-sm font-semibold text-ink-900 tracking-tight group-hover:text-terracotta transition-colors line-clamp-1">
                              {gAlbum.title || "Unnamed Album"}
                            </h3>
                            <p className="font-sans text-[11px] text-ink-500 mt-1 line-clamp-2 leading-relaxed">
                              Import photostack directly from Google Photos.
                            </p>
                          </div>
                          
                          <div className="flex items-center text-xs font-semibold text-ink-700 font-mono tracking-wider uppercase mt-4 group-hover:translate-x-1 transition-transform">
                            <span>Open Google Folder</span>
                            <ChevronRight className="w-3 h-3 ml-1" />
                          </div>
                        </button>
                      ))
                    ) : !loadingGoogleAlbums && (
                      <div className="col-span-2 border border-dashed border-cream-300 p-8 text-center bg-cream-100/10 rounded flex flex-col items-center justify-center space-y-2">
                        <ImageIcon className="w-8 h-8 text-zinc-400" />
                        <p className="font-serif text-sm text-ink-800 font-medium">No Google folders detected</p>
                        <p className="font-sans text-xs text-zinc-500 max-w-xs">
                          We didn't see folders in your cloud catalog. Use the auto-harvest stream card above to fetch photos!
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                /* Demo local albums selectors */
                <div className="grid md:grid-cols-3 gap-6 mb-10">
                  {mockAlbums.map((album) => (
                    <button
                      key={album.id}
                      onClick={() => handleSelectAlbum(album)}
                      className="group text-left border border-cream-200 hover:border-cream-400 bg-cream-50 hover:bg-cream-100/40 p-4 rounded-sm transition-all duration-300 pointer-events-auto moleskine-shadow hover:-translate-y-1 focus:outline-none flex flex-col justify-between min-h-[220px]"
                    >
                      <div>
                        <div className="aspect-[4/3] w-full overflow-hidden rounded-sm bg-neutral-100 mb-4 relative">
                          <img 
                            src={album.coverUrl} 
                            alt={album.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover grayscale-10 transition-all duration-700 group-hover:scale-105 group-hover:grayscale-0"
                          />
                          <div className="absolute top-2 right-2 bg-ink-900/40 backdrop-blur-md text-cream-50 font-mono text-[9px] px-2 py-0.5 rounded-full flex items-center space-x-1">
                            <FolderHeart className="w-3 h-3 text-terracotta" />
                            <span>{album.photos.length} photos</span>
                          </div>
                        </div>
                        <h3 className="font-serif text-sm font-semibold text-ink-900 tracking-tight group-hover:text-terracotta transition-colors line-clamp-1">
                          {album.name}
                        </h3>
                        <p className="font-sans text-[11px] text-ink-500 mt-1 line-clamp-2 leading-relaxed">
                          {album.description}
                        </p>
                      </div>
                      
                      <div className="flex items-center text-xs font-semibold text-ink-700 font-mono tracking-wider uppercase mt-4 group-hover:translate-x-1 transition-transform">
                        <span>Explore Collection</span>
                        <ChevronRight className="w-3 h-3 ml-1" />
                      </div>
                    </button>
                  ))}
                </div>
              )}

              <div className="h-px bg-cream-200 my-8"></div>

              {/* Drag & Drop Core Zone */}
              <div className="text-center">
                <h3 className="font-serif text-xl font-medium text-ink-900 mb-4">
                  Or, bind custom snapshots
                </h3>
                
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  onClick={triggerFileInput}
                  className={`border-2 border-dashed rounded-lg p-10 cursor-pointer transition-all duration-300 text-center ${
                    isDragging 
                      ? "border-terracotta bg-terracotta/5" 
                      : "border-cream-300 hover:border-cream-400 bg-cream-100/20"
                  }`}
                >
                  <input 
                    type="file" 
                    ref={fileInputRef}
                    onChange={(e) => e.target.files && handleFiles(e.target.files)}
                    multiple 
                    accept="image/*"
                    className="hidden" 
                  />
                  <Upload className="w-8 h-8 text-ink-500 mx-auto mb-3" />
                  <p className="font-serif text-sm font-medium text-ink-700">
                    Drag and drop your photographs here
                  </p>
                  <p className="font-sans text-xs text-ink-500 mt-1">
                    Supports high-resolution camera snap. We process locally, protecting your privacy.
                  </p>
                  <button className="mt-4 inline-flex items-center space-x-1.5 bg-ink-900 text-sm font-medium text-cream-50 px-4 py-2 hover:bg-ink-700 rounded-sm pointer-events-none">
                    <Plus className="w-4 h-4" />
                    <span>Choose Snapshots</span>
                  </button>
                </div>
                
                {customPhotos.length > 0 && (
                  <div className="mt-6 text-left">
                    <h4 className="font-serif text-sm text-ink-700 font-semibold mb-3">
                      Uploaded files ({customPhotos.length})
                    </h4>
                    <div className="grid grid-cols-6 gap-3">
                      {customPhotos.map((photo) => (
                        <div key={photo.id} className="aspect-square bg-gray-100 rounded-sm overflow-hidden relative border border-cream-200">
                          <img src={photo.url} alt="custom" className="w-full h-full object-cover" />
                        </div>
                      ))}
                      <button 
                        onClick={() => {
                          const album: PhotoAlbum = {
                            id: "custom-volume",
                            name: "Personal Memoir",
                            description: "A custom volume of local photo libraries.",
                            coverUrl: customPhotos[0].url,
                            photos: customPhotos
                          };
                          handleSelectAlbum(album);
                        }}
                        className="aspect-square rounded-sm border border-dashed border-cream-400 hover:border-ink-900 flex flex-col items-center justify-center p-2 text-center group text-ink-700 hover:text-ink-900 cursor-pointer"
                      >
                        <Sparkles className="w-5 h-5 text-terracotta animate-pulse" />
                        <span className="font-sans text-[9px] mt-1 uppercase tracking-widest font-bold">Assemble</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      ) : (
        /* SCREEN 2: Individual Photo Check-list selectors */
        <div className="bg-cream-100/30 border border-cream-200/60 p-6 rounded-md">
          {loadingGooglePhotos ? (
            /* Loading Google folder state loading indicator */
            <div className="py-20 text-center space-y-4">
              <RefreshCw className="w-8 h-8 text-terracotta mx-auto animate-spin" />
              <p className="font-serif text-lg font-medium text-ink-900">Synchronizing cloud library assets...</p>
              <p className="font-sans text-xs text-ink-500">Retrieving full resolution media metadata securely from Google servers</p>
            </div>
          ) : (
            <div>
              {/* Header Controls */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-cream-200 gap-4">
                <div>
                  <button 
                    onClick={() => setSelectedAlbum(null)}
                    className="font-mono text-xs text-ink-500 hover:text-ink-900 focus:outline-none mb-1 inline-block cursor-pointer"
                  >
                    ← Back to volumes
                  </button>
                  <h2 className="font-serif text-2xl font-semibold text-ink-900 leading-tight">
                    {selectedAlbum.name}
                  </h2>
                  <p className="font-sans text-xs text-ink-500 mt-1">
                    Choose the memories to include in your bounded story. Let our editor curate the margins.
                  </p>
                </div>

                <div className="flex items-center space-x-3">
                  <button
                    onClick={handleSelectAll}
                    className="text-xs font-semibold font-mono uppercase tracking-wider text-ink-700 hover:text-ink-900 border border-cream-300 px-3 py-1.5 rounded bg-cream-50 hover:bg-cream-100 cursor-pointer"
                  >
                    {checkedPhotoIds.size === photosPool.length ? "Deselect All" : "Select All"}
                  </button>

                  <button
                    disabled={checkedPhotoIds.size === 0}
                    onClick={handleAssemble}
                    className={`flex items-center space-x-2 bg-ink-900 text-cream-50 font-sans text-xs font-semibold uppercase tracking-wider px-5 py-2.5 rounded-sm shadow-sm transition-all focus:outline-none shrink-0 ${
                      checkedPhotoIds.size === 0 
                        ? "opacity-45 cursor-not-allowed" 
                        : "hover:bg-ink-700 cursor-pointer hover:shadow active:scale-95"
                    }`}
                  >
                    <Sparkles className="w-3.5 h-3.5 text-cream-200 animate-pulse" />
                    <span>Assemble Book ({checkedPhotoIds.size})</span>
                  </button>
                </div>
              </div>

              {/* Photo library select grid */}
              <div className="my-6">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-mono text-[10px] tracking-wider uppercase text-ink-500">
                    Memories selected ({checkedPhotoIds.size} of {photosPool.length})
                  </span>
                  <button 
                    onClick={triggerFileInput}
                    className="flex items-center space-x-1 font-mono text-[10px] uppercase text-terracotta hover:text-amber-800"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Upload more snapshots</span>
                  </button>
                </div>

                {photosPool.length === 0 ? (
                  <div className="py-12 text-center border-2 border-dashed border-cream-200 rounded p-6">
                    <ImageIcon className="w-8 h-8 text-zinc-400 mx-auto mb-2" />
                    <p className="font-serif text-sm font-semibold text-ink-900">This volume is empty</p>
                    <p className="font-sans text-xs text-ink-500 mt-1">Upload files or select a different folder</p>
                  </div>
                ) : (
                  /* Grid of photos */
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    {photosPool.map((photo) => {
                      const isSelected = checkedPhotoIds.has(photo.id);
                      return (
                        <div
                          key={photo.id}
                          onClick={() => handleTogglePhoto(photo.id)}
                          className={`group relative aspect-[4/3] rounded overflow-hidden shadow-sm cursor-pointer border transition-all duration-300 ${
                            isSelected 
                              ? "border-terracotta ring-1 ring-terracotta/20 scale-[0.98]" 
                              : "border-cream-300 scale-100 opacity-80 hover:opacity-100 hover:scale-[1.01]"
                          }`}
                        >
                          <img 
                            src={photo.url} 
                            alt="memoir library thumbnail" 
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover transition-all" 
                          />
                          
                          {/* Checked badge */}
                          <div className={`absolute top-2 left-2 w-5 h-5 rounded-sm border flex items-center justify-center transition-all ${
                            isSelected 
                              ? "bg-terracotta border-terracotta text-cream-50" 
                              : "bg-ink-900/40 border-cream-200/40 text-transparent group-hover:bg-ink-900/60"
                          }`}>
                            <Check className="w-3.5 h-3.5" />
                          </div>

                          {/* Float Metadata Panel */}
                          {(photo.location || photo.timestamp) && (
                            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink-900/90 to-transparent p-2 text-cream-50 font-sans opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end">
                              {photo.location && (
                                <div className="flex items-center space-x-1 text-[9px] font-medium leading-none mb-0.5">
                                  <MapPin className="w-2.5 h-2.5 text-terracotta shrink-0" />
                                  <span className="truncate">{photo.location}</span>
                                </div>
                              )}
                              {photo.timestamp && (
                                <div className="flex items-center space-x-1 text-[8px] text-cream-300 font-mono leading-none">
                                  <Calendar className="w-2.5 h-2.5 shrink-0" />
                                  <span>{new Date(photo.timestamp).toLocaleDateString(undefined, {month: 'short', year: 'numeric'})}</span>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
