import React, { useState } from "react";
import { MemoirBook, OrderDetails } from "../types";
import { BookOpen, MapPin, Truck, ShieldCheck } from "lucide-react";

interface OrderFormProps {
  book: MemoirBook;
  userEmail: string | null;
  onBack: () => void;
  onSubmitOrder: (orderDetails: Omit<OrderDetails, "id" | "createdAt" | "paymentStatus">) => void;
}

export default function OrderForm({ book, userEmail, onBack, onSubmitOrder }: OrderFormProps) {
  const [size, setSize] = useState<'6x6' | '8x8' | '10x10'>('8x8');
  const [format, setFormat] = useState<'softcover' | 'hardcover' | 'leather'>('hardcover');
  const [address, setAddress] = useState({
    fullName: "",
    email: userEmail || "pushkarytube@gmail.com",
    phone: "",
    addressLine1: "",
    addressLine2: "",
    city: "",
    state: "",
    postalCode: "",
    country: "India"
  });

  // Prices in INR (Razorpay ready)
  const getPrice = () => {
    let base = 1499; // 6x6 Softcover
    if (size === '8x8') base = 2499; // Classic
    if (size === '10x10') base = 3590; // Large
    
    if (format === 'hardcover') base += 500;
    if (format === 'leather') base += 1200;
    
    return base;
  };

  const currentPrice = getPrice();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAddress({
      ...address,
      [e.target.name]: e.target.value
    });
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!address.fullName || !address.phone || !address.addressLine1 || !address.city || !address.postalCode) {
      alert("Please fill in all standard delivery fields.");
      return;
    }
    onSubmitOrder({
      bookId: book.id,
      bookTitle: book.title,
      format,
      size,
      price: currentPrice,
      shippingAddress: address
    });
  };

  return (
    <div className="max-w-4xl mx-auto py-6">
      {/* Back button */}
      <button
        onClick={onBack}
        className="font-mono text-xs text-ink-500 hover:text-ink-900 mb-6 block focus:outline-none"
      >
        ← Back to book layout
      </button>

      <div className="text-center mb-8">
        <h2 className="font-serif text-3xl font-medium tracking-tight text-ink-900">
          Complete your printed memoir
        </h2>
        <p className="font-sans text-xs text-ink-500 mt-1 max-w-md mx-auto">
          Choose materials worthy of your memories. Hand-stitched, ink-on-cream paper, bounded for generations.
        </p>
      </div>

      <form onSubmit={handleFormSubmit} className="grid md:grid-cols-12 gap-8 items-start">
        {/* LEFT COLUMN: OPTIONS & ADDRESS */}
        <div className="md:col-span-7 space-y-6">
          
          {/* Format Selection Card */}
          <div className="bg-cream-100/30 border border-cream-200 p-5 rounded-md">
            <h3 className="font-serif text-base font-semibold text-ink-900 border-b border-cream-200 pb-2 mb-4">
              1. Curate book binding materials
            </h3>
            
            <div className="grid grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => { setFormat('softcover'); if (size === '10x10') setSize('8x8'); }}
                className={`p-3 text-center rounded border flex flex-col items-center justify-between transition-all cursor-pointer bg-cream-50 ${
                  format === 'softcover' 
                    ? "border-terracotta text-terracotta bg-terracotta/5" 
                    : "border-cream-300 text-ink-700 hover:border-cream-400"
                }`}
              >
                <BookOpen className="w-5 h-5 mb-1.5 opacity-80" />
                <span className="font-serif text-xs font-semibold">Softcover</span>
                <span className="font-mono text-[9px] mt-1 text-ink-500">Lightweight</span>
              </button>

              <button
                type="button"
                onClick={() => setFormat('hardcover')}
                className={`p-3 text-center rounded border flex flex-col items-center justify-between transition-all cursor-pointer bg-cream-50 ${
                  format === 'hardcover' 
                    ? "border-terracotta text-terracotta bg-terracotta/5" 
                    : "border-cream-300 text-ink-700 hover:border-cream-400"
                }`}
              >
                <BookOpen className="w-5 h-5 mb-1.5 text-sage" />
                <span className="font-serif text-xs font-semibold">Clothbound</span>
                <span className="font-mono text-[9px] mt-1 text-ink-500">Classic Book</span>
              </button>

              <button
                type="button"
                onClick={() => setFormat('leather')}
                className={`p-3 text-center rounded border flex flex-col items-center justify-between transition-all cursor-pointer bg-cream-50 ${
                  format === 'leather' 
                    ? "border-terracotta text-terracotta bg-terracotta/5" 
                    : "border-cream-300 text-ink-700 hover:border-cream-400"
                }`}
              >
                <BookOpen className="w-5 h-5 mb-1.5 text-orange-950" />
                <span className="font-serif text-xs font-semibold">Italian Leather</span>
                <span className="font-mono text-[9px] mt-1 text-ink-500">Heirloom</span>
              </button>
            </div>

            {/* Size options */}
            <div className="mt-5">
              <label className="font-mono text-[9px] uppercase tracking-widest text-ink-500 block mb-2">
                Physical size preset
              </label>
              <div className="grid grid-cols-3 gap-3">
                <button
                  type="button"
                  onClick={() => setSize('6x6')}
                  className={`py-2 px-3 text-center rounded border text-xs font-medium cursor-pointer ${
                    size === '6x6' 
                      ? "border-terracotta text-terracotta bg-terracotta/5" 
                      : "border-cream-300 text-ink-700 hover:border-cream-400 bg-cream-50"
                  }`}
                >
                  6” × 6” Pocket
                </button>
                <button
                  type="button"
                  onClick={() => setSize('8x8')}
                  className={`py-2 px-3 text-center rounded border text-xs font-medium cursor-pointer ${
                    size === '8x8' 
                      ? "border-terracotta text-terracotta bg-terracotta/5" 
                      : "border-cream-300 text-ink-700 hover:border-cream-400 bg-cream-50"
                  }`}
                >
                  8” × 8” Standard
                </button>
                <button
                  type="button"
                  disabled={format === 'softcover'}
                  onClick={() => setSize('10x10')}
                  className={`py-2 px-3 text-center rounded border text-xs font-medium ${
                    size === '10x10' 
                      ? "border-terracotta text-terracotta bg-terracotta/5" 
                      : format === 'softcover'
                      ? "opacity-40 cursor-not-allowed border-cream-200"
                      : "border-cream-300 text-ink-700 hover:border-cream-400 bg-cream-50 cursor-pointer"
                  }`}
                >
                  10” × 10” Grande
                </button>
              </div>
            </div>
          </div>

          {/* Delivery Address Grid */}
          <div className="bg-cream-100/30 border border-cream-200 p-5 rounded-md">
            <h3 className="font-serif text-base font-semibold text-ink-900 border-b border-cream-200 pb-2 mb-4">
              2. Delivery logistics & destination
            </h3>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="font-mono text-[9px] uppercase tracking-widest text-ink-500 block mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    name="fullName"
                    value={address.fullName}
                    onChange={handleInputChange}
                    placeholder="e.g. Pushkar"
                    className="w-full font-serif text-xs px-3 py-2.5 bg-cream-50 border border-cream-300 focus:outline-none focus:border-ink-900 rounded-sm"
                  />
                </div>
                <div>
                  <label className="font-mono text-[9px] uppercase tracking-widest text-ink-500 block mb-1">Phone Number</label>
                  <input
                    type="tel"
                    required
                    name="phone"
                    value={address.phone}
                    onChange={handleInputChange}
                    placeholder="e.g. +91 98765 43210"
                    className="w-full font-serif text-xs px-3 py-2.5 bg-cream-50 border border-cream-300 focus:outline-none focus:border-ink-900 rounded-sm"
                  />
                </div>
              </div>

              <div>
                <label className="font-mono text-[9px] uppercase tracking-widest text-ink-500 block mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  name="email"
                  value={address.email}
                  onChange={handleInputChange}
                  placeholder="e.g. details@memoirpress.com"
                  className="w-full font-serif text-xs px-3 py-2.5 bg-cream-50 border border-cream-300 focus:outline-none focus:border-ink-900 rounded-sm"
                />
              </div>

              <div>
                <label className="font-mono text-[9px] uppercase tracking-widest text-ink-500 block mb-1">Address Line 1</label>
                <input
                  type="text"
                  required
                  name="addressLine1"
                  value={address.addressLine1}
                  onChange={handleInputChange}
                  placeholder="Street name, apartment, building"
                  className="w-full font-serif text-xs px-3 py-2.5 bg-cream-50 border border-cream-300 focus:outline-none focus:border-ink-900 rounded-sm"
                />
              </div>

              <div>
                <label className="font-mono text-[9px] uppercase tracking-widest text-ink-500 block mb-1">Address Line 2 (Optional)</label>
                <input
                  type="text"
                  name="addressLine2"
                  value={address.addressLine2}
                  onChange={handleInputChange}
                  placeholder="Floor, suite, landmark, block"
                  className="w-full font-serif text-xs px-3 py-2.5 bg-cream-50 border border-cream-300 focus:outline-none focus:border-ink-900 rounded-sm"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="font-mono text-[9px] uppercase tracking-widest text-ink-500 block mb-1">City</label>
                  <input
                    type="text"
                    required
                    name="city"
                    value={address.city}
                    onChange={handleInputChange}
                    placeholder="New Delhi"
                    className="w-full font-serif text-xs px-3 py-2.5 bg-cream-50 border border-cream-300 focus:outline-none focus:border-ink-900 rounded-sm"
                  />
                </div>
                <div>
                  <label className="font-mono text-[9px] uppercase tracking-widest text-ink-500 block mb-1">State</label>
                  <input
                    type="text"
                    required
                    name="state"
                    value={address.state}
                    onChange={handleInputChange}
                    placeholder="Delhi"
                    className="w-full font-serif text-xs px-3 py-2.5 bg-cream-50 border border-cream-300 focus:outline-none focus:border-ink-900 rounded-sm"
                  />
                </div>
                <div>
                  <label className="font-mono text-[9px] uppercase tracking-widest text-ink-500 block mb-1">PIN / Post Code</label>
                  <input
                    type="text"
                    required
                    name="postalCode"
                    value={address.postalCode}
                    onChange={handleInputChange}
                    placeholder="110001"
                    className="w-full font-serif text-xs px-3 py-2.5 bg-cream-50 border border-cream-300 focus:outline-none focus:border-ink-900 rounded-sm"
                  />
                </div>
              </div>

              <div>
                <label className="font-mono text-[9px] uppercase tracking-widest text-ink-500 block mb-1">Country</label>
                <input
                  type="text"
                  required
                  name="country"
                  value={address.country}
                  onChange={handleInputChange}
                  className="w-full font-serif text-xs px-3 py-2.5 bg-cream-100 border border-cream-200 cursor-not-allowed text-ink-500 rounded-sm"
                />
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: BOOK SUMMARY & BILLING */}
        <div className="md:col-span-5 bg-cream-100/30 border border-cream-200 p-6 rounded-md moleskine-shadow space-y-6">
          <h3 className="font-serif text-base font-semibold text-ink-900 border-b border-cream-200 pb-2 mb-4">
            Order Leaf Ledger
          </h3>

          <div className="flex items-start space-x-3 pb-4 border-b border-cream-200">
            <div className="w-16 aspect-[4/3] bg-neutral-100 border border-cream-300 rounded overflow-hidden relative shrink-0">
              <img 
                src={book.coverPhotoUrl} 
                alt="cover art thumbnail" 
                className="w-full h-full object-cover" 
              />
            </div>
            <div>
              <h4 className="font-serif text-sm font-semibold text-ink-900 leading-tight">
                {book.title}
              </h4>
              <p className="font-serif text-[10px] text-ink-500 italic mt-0.5">
                {book.subtitle}
              </p>
              <div className="font-mono text-[8px] text-zinc-500 uppercase mt-1">
                {book.spreads.length + 2} detailed leaves &mdash; {book.photoCount} photos
              </div>
            </div>
          </div>

          {/* Pricing detail list */}
          <div className="space-y-2.5 font-sans text-xs">
            <div className="flex justify-between text-ink-700">
              <span>Binding ({format})</span>
              <span className="font-mono font-medium">
                ₹{format === 'softcover' ? "1,499" : format === 'hardcover' ? "1,999" : "2,699"}
              </span>
            </div>
            <div className="flex justify-between text-ink-700">
              <span>Size Supplement ({size})</span>
              <span className="font-mono font-medium">
                ₹{size === '6x6' ? "0" : size === '8x8' ? "500" : "1,591"}
              </span>
            </div>
            <div className="flex justify-between text-ink-700">
              <span>Hand Stitching & Curation</span>
              <span className="font-mono text-sage font-medium">Included</span>
            </div>
            <div className="flex justify-between text-ink-700">
              <span className="flex items-center">
                <Truck className="w-3.5 h-3.5 text-ink-500 mr-1 shrink-0" />
                <span>Secure Bound Shipping</span>
              </span>
              <span className="font-mono text-sage font-medium">Free</span>
            </div>

            <div className="h-px bg-cream-300 my-4"></div>

            <div className="flex justify-between items-baseline text-ink-900 font-serif">
              <span className="text-sm font-semibold">Preservation Bond</span>
              <span className="font-mono text-xl font-bold">
                ₹{currentPrice.toLocaleString("en-IN")}
              </span>
            </div>
          </div>

          <div className="bg-sage/5 border border-sage/20 p-3 rounded flex items-start space-x-2.5">
            <ShieldCheck className="w-4 h-4 text-sage mt-0.5 shrink-0" />
            <p className="font-sans text-[10px] text-sage leading-relaxed">
              <strong>Preservation Guarantee:</strong> Each volume is printed using organic acid-free paper and Japanese archive-ink, securing details for a minimum of 300 years of display.
            </p>
          </div>

          {/* Payment CTA button */}
          <button
            type="submit"
            className="w-full bg-ink-900 hover:bg-ink-700 text-cream-50 py-3 rounded-sm font-sans text-xs font-semibold uppercase tracking-wider transition-all hover:shadow cursor-pointer active:scale-[0.99] text-center block"
          >
            Pay with Razorpay
          </button>
        </div>
      </form>
    </div>
  );
}
