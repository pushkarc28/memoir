import { OrderDetails } from "../types";
import { Check, Mail, Heart, Calendar, Truck, Landmark } from "lucide-react";

interface OrderConfirmationProps {
  order: OrderDetails;
  onRestart: () => void;
}

export default function OrderConfirmation({ order, onRestart }: OrderConfirmationProps) {
  const steps = [
    { name: "Curation Locked", desc: "AI narrative structure and captions approved", active: true },
    { name: "Pressing Covers", desc: "Applying custom text titles to cloth/leather frames", active: true },
    { name: "Smyth Sewing", desc: "Japanese style multi-signature hand-stitching", active: false },
    { name: "Secure transit", desc: "Atelier hand-packed dispatched via express transit", active: false }
  ];

  return (
    <div className="max-w-xl mx-auto py-10 px-4 animate-scaleUp">
      <div className="bg-cream-100 border border-cream-200 p-8 rounded-md shadow-xl text-center relative overflow-hidden">
        
        {/* Soft elegant physical banner ribbon fold */}
        <div className="absolute top-0 right-0 w-28 h-28 overflow-hidden pointer-events-none">
          <div className="bg-sage text-cream-50 font-mono text-[9px] font-semibold tracking-wider text-center py-1 absolute top-6 -right-8 w-32 rotate-45 uppercase shadow-sm">
            Handmade
          </div>
        </div>

        {/* Heart icon */}
        <div className="w-12 h-12 bg-sage/10 text-sage flex items-center justify-center rounded-full mx-auto mb-6">
          <Heart className="w-6 h-6 animate-pulse" />
        </div>

        <h2 className="font-serif text-3xl font-medium tracking-tight text-ink-900 leading-tight">
          Your book is on its way
        </h2>
        <p className="font-serif italic text-sm text-ink-500 mt-2 max-w-sm mx-auto leading-relaxed">
          The fragments of your story have been captured in paper, and are currently being stitched in our atelier.
        </p>

        <div className="h-px bg-cream-300 my-6"></div>

        {/* Order Details list */}
        <div className="space-y-3 font-mono text-[10px] uppercase text-left max-w-xs mx-auto border border-cream-300 p-4 rounded bg-cream-50/50">
          <div className="flex justify-between text-zinc-600">
            <span>Volume Id</span>
            <span className="font-bold text-ink-900">{order.id.slice(0, 10).toUpperCase()}</span>
          </div>
          <div className="flex justify-between text-zinc-600">
            <span>Title</span>
            <span className="font-bold text-ink-900 truncate max-w-[120px]">{order.bookTitle}</span>
          </div>
          <div className="flex justify-between text-zinc-600">
            <span>Binding style</span>
            <span className="font-bold text-ink-900">{order.format} ({order.size})</span>
          </div>
          <div className="flex justify-between text-zinc-600">
            <span>Secure payment vpa</span>
            <span className="font-bold text-ink-900 truncate max-w-[120px]">{order.paymentId || "UPI_TXN_OK"}</span>
          </div>
          <div className="flex justify-between text-zinc-600">
            <span>Deliver to</span>
            <span className="font-bold text-ink-900 truncate max-w-[120px]">{order.shippingAddress.fullName}</span>
          </div>
        </div>

        <div className="h-px bg-cream-300 my-6"></div>

        {/* Curation Atelier Steps */}
        <div className="text-left max-w-xs mx-auto mb-8">
          <h4 className="font-sans text-[10px] font-bold uppercase tracking-wider text-ink-900 mb-4">
            Atelier handcraft stages
          </h4>
          
          <div className="space-y-4">
            {steps.map((s, idx) => (
              <div key={idx} className="flex items-start space-x-3">
                <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 mt-0.5 ${
                  s.active 
                    ? "bg-sage border-sage text-cream-50" 
                    : "border-cream-400 bg-cream-100 text-transparent"
                }`}>
                  <Check className="w-2.5 h-2.5" />
                </div>
                <div>
                  <h5 className="font-serif text-xs font-semibold text-ink-900 leading-none">
                    {s.name}
                  </h5>
                  <p className="font-sans text-[9px] text-zinc-500 mt-1 leading-normal">
                    {s.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-sage/5 border border-sage/10 p-3 rounded text-left flex items-start space-x-2 mb-6">
          <Mail className="w-4 h-4 text-sage shrink-0 mt-0.5" />
          <p className="font-sans text-[10px] text-zinc-600 leading-relaxed">
            Your ledger invoice and digital layout preview has been sent to <strong>{order.shippingAddress.email}</strong>. Track delivery via notifications.
          </p>
        </div>

        <button
          onClick={onRestart}
          className="w-full bg-ink-900 hover:bg-ink-700 text-cream-50 py-3 rounded-sm font-sans text-xs font-semibold uppercase tracking-wider transition-all hover:shadow cursor-pointer"
        >
          Assemble another Volume
        </button>

      </div>
    </div>
  );
}
