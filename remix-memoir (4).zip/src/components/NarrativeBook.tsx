import { useState } from "react";
import { Photo, MemoirBook, BookSpread } from "../types";
import { 
  Book, 
  ChevronLeft, 
  ChevronRight, 
  Edit3, 
  Trash2, 
  Sparkles, 
  RefreshCw, 
  LayoutGrid, 
  ShoppingBag,
  MapPin,
  Calendar,
  Check,
  Printer,
  Sparkle
} from "lucide-react";

interface NarrativeBookProps {
  book: MemoirBook;
  fullPhotosPool: Photo[];
  onUpdateBook: (updatedBook: MemoirBook) => void;
  onPlaceOrder: () => void;
}

export default function NarrativeBook({ 
  book, 
  fullPhotosPool, 
  onUpdateBook, 
  onPlaceOrder 
}: NarrativeBookProps) {
  const [currentSpreadIndex, setCurrentSpreadIndex] = useState(-1); // -1 = Cover, 0 = Opening Narrative, 1..N = Book Spreads
  const [editingCaptionId, setEditingCaptionId] = useState<string | null>(null);
  const [editingNarrative, setEditingNarrative] = useState(false);
  const [tempNarrative, setTempNarrative] = useState(book.openingNarrative);
  const [tempCaptionText, setTempCaptionText] = useState("");
  const [swappingPhotoState, setSwappingPhotoState] = useState<{
    spreadId: string;
    photoIndex: number;
    photoId: string;
  } | null>(null);
  const [showDownloadSuccess, setShowDownloadSuccess] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const totalPages = book.spreads.length + 2; // Cover + Narrative + Spreads

  const nextSpread = () => {
    if (currentSpreadIndex < book.spreads.length) {
      setCurrentSpreadIndex(prev => prev + 1);
    }
  };

  const prevSpread = () => {
    if (currentSpreadIndex > -1) {
      setCurrentSpreadIndex(prev => prev - 1);
    }
  };

  // Edit Caption
  const handleStartEditCaption = (spreadId: string, currentCaption: string) => {
    setEditingCaptionId(spreadId);
    setTempCaptionText(currentCaption);
  };

  const handleSaveCaption = (spreadId: string) => {
    const updatedSpreads = book.spreads.map(spread => {
      if (spread.id === spreadId) {
        return { ...spread, caption: tempCaptionText };
      }
      return spread;
    });
    onUpdateBook({ ...book, spreads: updatedSpreads });
    setEditingCaptionId(null);
  };

  // Handle Narrative Story edits
  const handleSaveNarrative = () => {
    onUpdateBook({ ...book, openingNarrative: tempNarrative });
    setEditingNarrative(false);
  };

  // Swap out a photo in a spread
  const handleTriggerSwap = (spreadId: string, photoId: string, idx: number) => {
    setSwappingPhotoState({ spreadId, photoId, photoIndex: idx });
  };

  const handleExecuteSwap = (newPhoto: Photo) => {
    if (!swappingPhotoState) return;
    
    const updatedSpreads = book.spreads.map(spread => {
      if (spread.id === swappingPhotoState.spreadId) {
        const nextPhotos = [...spread.photos];
        nextPhotos[swappingPhotoState.photoIndex] = newPhoto;
        return { ...spread, photos: nextPhotos };
      }
      return spread;
    });

    onUpdateBook({ ...book, spreads: updatedSpreads });
    setSwappingPhotoState(null);
  };

  // Delete a spread
  const handleDeleteSpread = (spreadId: string) => {
    const updatedSpreads = book.spreads.filter(s => s.id !== spreadId);
    // Adjust page numbers
    const renumberedSpreads = updatedSpreads.map((s, idx) => ({
      ...s,
      pageNumber: idx + 3
    }));

    onUpdateBook({ 
      ...book, 
      spreads: renumberedSpreads,
      photoCount: renumberedSpreads.reduce((sum, s) => sum + s.photos.length, 0)
    });
    
    // reset pagination if we fell off the cliff
    if (currentSpreadIndex >= renumberedSpreads.length) {
      setCurrentSpreadIndex(renumberedSpreads.length - 1);
    }
  };

  // Toggle Page Spread Layout
  const handleToggleLayout = (spreadId: string) => {
    const layouts: ('single' | 'double' | 'split-vertical')[] = ['single', 'double', 'split-vertical'];
    
    const updatedSpreads = book.spreads.map(spread => {
      if (spread.id === spreadId) {
        const nextIdx = (layouts.indexOf(spread.layout as any) + 1) % layouts.length;
        const targetLayout = layouts[nextIdx];
        
        let finalPhotos = [...spread.photos];
        if (targetLayout !== 'single' && finalPhotos.length === 1) {
          const usedIds = new Set(book.spreads.flatMap(s => s.photos.map(p => p.id)));
          const available = fullPhotosPool.filter(p => !usedIds.has(p.id));
          if (available.length > 0) {
            finalPhotos.push(available[0]);
          }
        } else if (targetLayout === 'single' && finalPhotos.length > 1) {
          finalPhotos = [finalPhotos[0]];
        }

        return { 
          ...spread, 
          layout: targetLayout, 
          photos: finalPhotos
        };
      }
      return spread;
    });

    onUpdateBook({ ...book, spreads: updatedSpreads });
  };

  // High-fidelity HTML export matching the premium, flat, serif design
  const handleExportBookHtml = async () => {
    setIsExporting(true);
    
    const convertImageToBase64 = async (imgUrl: string): Promise<string> => {
      if (!imgUrl) return '';
      if (imgUrl.startsWith('data:')) return imgUrl;
      
      try {
        const res = await fetch(imgUrl);
        const blob = await res.blob();
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.onerror = () => resolve(imgUrl);
          reader.readAsDataURL(blob);
        });
      } catch (e) {
        return new Promise((resolve) => {
          const img = new Image();
          img.crossOrigin = 'anonymous';
          img.onload = () => {
            try {
              const canvas = document.createElement('canvas');
              canvas.width = img.naturalWidth || img.width;
              canvas.height = img.naturalHeight || img.height;
              const ctx = canvas.getContext('2d');
              if (ctx) {
                ctx.drawImage(img, 0, 0);
                resolve(canvas.toDataURL('image/jpeg', 0.85));
                return;
              }
            } catch (err) {}
            resolve(imgUrl);
          };
          img.onerror = () => resolve(imgUrl);
          img.src = imgUrl;
        });
      }
    };

    const base64Cache: Record<string, string> = {};
    try {
      const allPhotos = book.spreads.flatMap(s => s.photos);
      const uniquePhotos = Array.from(new Map(allPhotos.map(p => [p.url, p])).values());
      await Promise.all(uniquePhotos.map(async (ph) => {
        base64Cache[ph.id] = await convertImageToBase64(ph.url);
      }));
    } catch (e) {
      console.warn("Failed packaging photos:", e);
    }

    let motifEmoji = '📓';
    let motifTitle = 'Classic Minimal';

    if (book.motif === 'sakura') { motifEmoji = '🌸'; motifTitle = 'Kyoto Sakura Series'; }
    else if (book.motif === 'mountain') { motifEmoji = '🏔️'; motifTitle = 'Alpine Peaks & Pines'; }
    else if (book.motif === 'ocean') { motifEmoji = '🌊'; motifTitle = 'Pacific Ocean Coastline'; }
    else if (book.motif === 'cafe') { motifEmoji = '☕'; motifTitle = 'Specialty Espresso Brew'; }
    else if (book.motif === 'vintage') { motifEmoji = '🎞️'; motifTitle = 'Archival Noir Film Proof'; }
    else if (book.motif === 'botanical') { motifEmoji = '🌿'; motifTitle = 'Botanical Ivy Greenhouse'; }

    let pagesHtml = '';

    // COVER PAGE - Full bleed cover photo with dark gradient overlay, text on top
    pagesHtml += `
      <div class="print-page cover-page" style="background-color: ${book.pageColor || '#1C1B19'}; position: relative; overflow: hidden; border-radius: 8px; min-height: 520px; display: flex; flex-direction: column; justify-content: flex-end;">
        <img src="${book.coverPhotoUrl}" alt="cover" style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover;" />
        <div style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0.2) 50%, rgba(0,0,0,0) 100%); z-index: 1;"></div>
        <div style="position: relative; z-index: 2; padding: 40px; color: #fff; text-align: left;">
          <p style="font-family: monospace; font-size: 10px; letter-spacing: 3px; text-transform: uppercase; opacity: 0.7; margin-bottom: 12px;">Memoir</p>
          <h1 style="font-family: 'Playfair Display', Georgia, serif; font-size: 38px; font-weight: 500; line-height: 1.15; margin: 0 0 10px; letter-spacing: -0.5px; color: #fff;">${book.title}</h1>
          <p style="font-family: Georgia, serif; font-size: 16px; font-style: italic; opacity: 0.85; margin: 0; color: #fff;">${book.subtitle}</p>
        </div>
      </div>
    `;

    // PREFACE / NARRATIVE STORY PAGE - Left Title Leaf
    pagesHtml += `
      <div class="print-page preface-page-left" style="background-color: #FDFAF5; color: #1C1B19; padding: 40px; min-height: 520px; display: flex; flex-direction: column; justify-content: space-between; page-break-after: always;">
        <div style="font-family: monospace; font-size: 10px; letter-spacing: 2px; text-transform: uppercase; opacity: 0.6; text-align: center; margin-bottom: 20px;">TITLE PAGE</div>
        <div style="margin: auto; text-align: center; max-width: 320px;">
          <span style="font-size: 32px; display: block; margin-bottom: 12px;">${motifEmoji}</span>
          <h1 style="font-family: 'Playfair Display', Georgia, serif; font-size: 26px; font-weight: 500; margin: 0 0 10px; color: #1C1B19; line-height: 1.2;">${book.title}</h1>
          <div style="width: 40px; height: 1px; background-color: #B85E3B; margin: 12px auto;"></div>
          <p style="font-family: Georgia, serif; font-size: 14px; font-style: italic; color: #8c8c83; margin: 0;">${book.subtitle}</p>
        </div>
        <div style="font-family: monospace; font-size: 10px; opacity: 0.5; border-top: 1px solid rgba(28,27,25,0.08); padding-top: 15px; margin-top: 30px; display: flex; justify-content: space-between; align-items: center;">
          <span>Volume Title Page</span>
          <span>Printed Page I</span>
        </div>
      </div>
    `;

    // PREFACE / NARRATIVE STORY PAGE - Right Foreword Story
    const dropCapChar = book.openingNarrative ? book.openingNarrative.trim().charAt(0) : '';
    const dropCapRest = book.openingNarrative ? book.openingNarrative.trim().slice(1).replace(/\n/g, '<br/><br/>') : '';
    pagesHtml += `
      <div class="print-page preface-page-right" style="background-color: #FDFAF5; color: #1C1B19; padding: 40px; min-height: 520px; display: flex; flex-direction: column; justify-content: space-between; page-break-after: always;">
        <div style="font-family: monospace; font-size: 10px; letter-spacing: 2px; text-transform: uppercase; opacity: 0.6; text-align: center; margin-bottom: 20px;">FOREWORD</div>
        <div style="max-width: 420px; margin: auto; text-align: justify;">
          <p style="font-family: Georgia, serif; font-size: 15px; line-height: 1.8; color: #1C1B19; margin: 0;">
            <span style="font-size: 40px; font-family: 'Playfair Display', Georgia, serif; font-weight: bold; color: #B85E3B; float: left; line-height: 32px; margin-right: 10px; margin-top: 2px;">${dropCapChar}</span>${dropCapRest}
          </p>
        </div>
        <div style="font-family: monospace; font-size: 10px; opacity: 0.5; border-top: 1px solid rgba(28,27,25,0.08); padding-top: 15px; margin-top: 30px; display: flex; justify-content: space-between; align-items: center;">
          <span>Volume Narrative Preface</span>
          <span>Printed Page II</span>
        </div>
      </div>
    `;

    // ALL GRAPHICAL SPREADS
    book.spreads.forEach((spread, sIdx) => {
      const isSingle = spread.photos.length === 1;
      const leftPageNum = sIdx * 2 + 3;
      const rightPageNum = sIdx * 2 + 4;
      
      if (isSingle) {
        const ph = spread.photos[0];
        const photoSrc = base64Cache[ph.id] || ph.url;
        
        // Left Page: The Photo (elegantly framed)
        pagesHtml += `
          <div class="print-page spread-page-left" style="background-color: #FDFAF5; color: #1C1B19; padding: 40px; min-height: 520px; display: flex; flex-direction: column; justify-content: space-between; page-break-after: always;">
            <div style="display: flex; justify-content: space-between; align-items: center; font-family: monospace; font-size: 10px; opacity: 0.6; border-bottom: 1px solid rgba(28,27,25,0.08); padding-bottom: 15px; margin-bottom: 20px;">
              <span style="text-transform: uppercase;">${book.title}</span>
              <span style="color: #B85E3B; font-style: italic;">Left Page</span>
              <span>Spread ${sIdx + 1}</span>
            </div>

            <div style="margin: auto; width: 100%; max-width: 480px; display: flex; flex-direction: column; align-items: center; justify-content: center; flex-grow: 1;">
              <div style="width: 100%; aspect-ratio: 4/3; border-radius: 6px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.08); background-color: #ffffff; padding: 12px; border: 1px solid rgba(0,0,0,0.05);">
                <img src="${photoSrc}" alt="Spread Moment" style="width: 100%; height: 100%; object-fit: cover; border-radius: 4px;" />
              </div>
            </div>

            <div style="font-family: monospace; font-size: 10px; opacity: 0.5; border-top: 1px solid rgba(28,27,25,0.08); padding-top: 15px; margin-top: 20px; display: flex; justify-content: space-between; align-items: center;">
              <span>Spread ${sIdx + 1} &mdash; page ${leftPageNum}</span>
              <span>Printed Left Leaf</span>
            </div>
          </div>
        `;

        // Right Page: The Caption
        const captionText = (spread.caption || "A moment worth keeping.").replace(/^["'“'”]+|["'“'”]+$/g, "");
        pagesHtml += `
          <div class="print-page spread-page-right" style="background-color: #FDFAF5; color: #1C1B19; padding: 40px; min-height: 520px; display: flex; flex-direction: column; justify-content: space-between; page-break-after: always;">
            <div style="display: flex; justify-content: space-between; align-items: center; font-family: monospace; font-size: 10px; opacity: 0.6; border-bottom: 1px solid rgba(28,27,25,0.08); padding-bottom: 15px; margin-bottom: 20px;">
              <span style="text-transform: uppercase;">${book.title}</span>
              <span style="color: #B85E3B; font-style: italic;">${motifEmoji} ${motifTitle}</span>
              <span>Spread ${sIdx + 1}</span>
            </div>

            <div style="margin: auto; width: 100%; max-width: 440px; display: flex; flex-direction: column; align-items: center; justify-content: center; flex-grow: 1; text-align: center;">
              <div style="font-size: 24px; margin-bottom: 14px;">${motifEmoji}</div>
              <div style="width: 30px; height: 1px; background-color: #B85E3B; margin: 0 auto 16px;"></div>
              <p style="font-family: Georgia, serif; font-size: 16px; font-style: italic; color: #1C1B19; line-height: 1.8; margin: 0; max-width: 360px;">
                "${captionText}"
              </p>
            </div>

            <div style="font-family: monospace; font-size: 10px; opacity: 0.5; border-top: 1px solid rgba(28,27,25,0.08); padding-top: 15px; margin-top: 20px; display: flex; justify-content: space-between; align-items: center;">
              <span>Spread ${sIdx + 1} &mdash; page ${rightPageNum}</span>
              <span>Printed Right Leaf</span>
            </div>
          </div>
        `;
        
      } else {
        // DOUBLE LAYOUT
        const ph1 = spread.photos[0];
        const ph2 = spread.photos[1] || ph1;
        const photo1Src = base64Cache[ph1.id] || ph1.url;
        const photo2Src = base64Cache[ph2.id] || ph2.url;

        // Left Page: Photo 1
        pagesHtml += `
          <div class="print-page spread-page-left" style="background-color: #FDFAF5; color: #1C1B19; padding: 40px; min-height: 520px; display: flex; flex-direction: column; justify-content: space-between; page-break-after: always;">
            <div style="display: flex; justify-content: space-between; align-items: center; font-family: monospace; font-size: 10px; opacity: 0.6; border-bottom: 1px solid rgba(28,27,25,0.08); padding-bottom: 15px; margin-bottom: 20px;">
              <span style="text-transform: uppercase;">${book.title}</span>
              <span style="color: #B85E3B; font-style: italic;">Left Page</span>
              <span>Spread ${sIdx + 1}</span>
            </div>

            <div style="margin: auto; width: 100%; max-width: 480px; display: flex; flex-direction: column; align-items: center; justify-content: center; flex-grow: 1;">
              <div style="width: 100%; aspect-ratio: 4/3; border-radius: 6px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.08); background-color: #ffffff; padding: 12px; border: 1px solid rgba(0,0,0,0.05);">
                <img src="${photo1Src}" alt="Spread Moment Left" style="width: 100%; height: 100%; object-fit: cover; border-radius: 4px;" />
              </div>
            </div>

            <div style="font-family: monospace; font-size: 10px; opacity: 0.5; border-top: 1px solid rgba(28,27,25,0.08); padding-top: 15px; margin-top: 20px; display: flex; justify-content: space-between; align-items: center;">
              <span>Spread ${sIdx + 1} &mdash; page ${leftPageNum}</span>
              <span>Printed Left Leaf</span>
            </div>
          </div>
        `;

        // Right Page: Photo 2 + Caption at the bottom
        const captionText = (spread.caption || "A moment worth keeping.").replace(/^["'“'”]+|["'“'”]+$/g, "");
        const captionHtml = spread.caption && spread.caption.trim() !== '' ? `
          <div style="text-align: center; margin-top: 20px; width: 100%;">
            <div style="width: 24px; height: 1px; background-color: #B85E3B; margin: 0 auto 10px;"></div>
            <p style="font-family: Georgia, serif; font-size: 13px; font-style: italic; color: #1C1B19; line-height: 1.6; margin: 0; max-width: 320px; margin-left: auto; margin-right: auto;">
              "${captionText}"
            </p>
          </div>
        ` : '';

        pagesHtml += `
          <div class="print-page spread-page-right" style="background-color: #FDFAF5; color: #1C1B19; padding: 40px; min-height: 520px; display: flex; flex-direction: column; justify-content: space-between; page-break-after: always;">
            <div style="display: flex; justify-content: space-between; align-items: center; font-family: monospace; font-size: 10px; opacity: 0.6; border-bottom: 1px solid rgba(28,27,25,0.08); padding-bottom: 15px; margin-bottom: 20px;">
              <span style="text-transform: uppercase;">${book.title}</span>
              <span style="color: #B85E3B; font-style: italic;">${motifEmoji} ${motifTitle}</span>
              <span>Spread ${sIdx + 1}</span>
            </div>

            <div style="margin: auto; width: 100%; max-width: 480px; display: flex; flex-direction: column; align-items: center; justify-content: center; flex-grow: 1;">
              <div style="width: 100%; aspect-ratio: 4/3; border-radius: 6px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.08); background-color: #ffffff; padding: 12px; border: 1px solid rgba(0,0,0,0.05); margin-bottom: 16px;">
                <img src="${photo2Src}" alt="Spread Moment Right" style="width: 100%; height: 100%; object-fit: cover; border-radius: 4px;" />
              </div>
              ${captionHtml}
            </div>

            <div style="font-family: monospace; font-size: 10px; opacity: 0.5; border-top: 1px solid rgba(28,27,25,0.08); padding-top: 15px; margin-top: 20px; display: flex; justify-content: space-between; align-items: center;">
              <span>Spread ${sIdx + 1} &mdash; page ${rightPageNum}</span>
              <span>Printed Right Leaf</span>
            </div>
          </div>
        `;
      }
    });

    const fullPageContent = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>${book.title} &mdash; Standalone Printed Book Album</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Playfair+Display:ital,wght@0,400;0,600;1,400&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
  <style>
    body {
      background-color: #f4ecd8;
      color: #1C1B19;
      font-family: Georgia, serif;
      margin: 0;
      padding: 40px 20px;
      display: flex;
      flex-direction: column;
      align-items: center;
      min-height: 100vh;
      box-sizing: border-box;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }

    .designer-control-deck {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: #ffffff;
      padding: 16px 28px;
      border-radius: 12px;
      border: 1px solid rgba(0,0,0,0.06);
      box-shadow: 0 10px 40px rgba(0,0,0,0.08);
      width: 100%;
      max-width: 900px;
      margin-bottom: 35px;
      box-sizing: border-box;
    }

    .brand-group {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .brand-name {
      font-family: 'Playfair Display', Georgia, serif;
      font-weight: 600;
      font-size: 17px;
      margin: 0;
      color: #121211;
    }

    .brand-tag {
      font-size: 10px;
      font-family: monospace;
      color: #8c8c83;
      letter-spacing: 1.5px;
      text-transform: uppercase;
      margin: 2px 0 0 0;
    }

    .print-trigger-button {
      background: linear-gradient(135deg, #CF6B44 0%, #B85E3B 100%);
      color: #ffffff;
      border: none;
      padding: 12px 28px;
      border-radius: 6px;
      font-family: sans-serif;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 4px 15px rgba(184, 94, 59, 0.3);
      transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .print-trigger-button:hover {
      transform: translateY(-1.5px);
      box-shadow: 0 6px 20px rgba(184, 94, 59, 0.4);
    }

    .printed-leaves-stack {
      width: 100%;
      max-width: 900px;
    }

    .print-page {
      background-color: #FDFAF5;
      color: #1C1B19;
      padding: 40px;
      margin-bottom: 45px;
      box-sizing: border-box;
      min-height: 640px;
      border-radius: 8px;
      box-shadow: 0 8px 30px rgba(0,0,0,0.06);
      border: 1px solid rgba(0,0,0,0.05);
      position: relative;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      page-break-after: always;
      overflow: hidden;
    }

    @media print {
      body {
        background-color: #ffffff !important;
        padding: 0 !important;
      }

      .designer-control-deck {
        display: none !important;
      }

      .print-page {
        box-shadow: none !important;
        border: none !important;
        border-radius: 0 !important;
        margin: 0 !important;
        padding: 12mm 15mm !important;
        width: 100% !important;
        height: 297mm !important;
        min-height: 297mm !important;
      }
    }
  </style>
</head>
<body>
  <div class="designer-control-deck">
    <div class="brand-group">
      <span style="font-size: 28px;">${motifEmoji}</span>
      <div>
        <h4 class="brand-name">${book.title}</h4>
        <p class="brand-tag">${motifTitle} Edition • Memoir Album</p>
      </div>
    </div>
    <div style="display: flex; gap: 8px;">
       <button class="print-trigger-button" onclick="window.print()">📥 Save Book as PDF</button>
    </div>
  </div>

  <div class="printed-leaves-stack">
    ${pagesHtml}
  </div>
</body>
</html>
    `;

    const blob = new Blob([fullPageContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${book.title.replace(/[^A-Za-z0-9_-]/g, '_')}_Printed_Album.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setIsExporting(false);
    setShowDownloadSuccess(true);
  };

  const bookPhotoIds = new Set(book.spreads.flatMap(s => s.photos.map(p => p.id)));
  const unusedPhotoCandidates = fullPhotosPool.filter(p => !bookPhotoIds.has(p.id));

  return (
    <div className="max-w-5xl mx-auto py-6">
      {/* SCREEN VIEW SECTION (HIDDEN ON PRINT) */}
      <div className="screen-only">
        {/* Narrative Header Bar */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 pb-4 border-b border-cream-200 gap-4">
          <div>
            <span className="font-mono text-[10px] uppercase tracking-widest text-ink-500">
              Book Layout Studio 📓
            </span>
            <h2 className="font-serif text-xl font-medium text-ink-900 mt-1 flex items-center gap-1.5">
              "{book.title}" &mdash; {book.spreads.length + 2} printed leaves
              {book.motif && book.motif !== 'none' && (
                <span className="text-xs bg-terracotta/10 text-terracotta px-2 py-0.5 rounded-full font-sans font-normal italic flex items-center space-x-1">
                  <span>with {book.motif === 'sakura' ? 'Sakura' : book.motif === 'mountain' ? 'Alpine' : book.motif === 'ocean' ? 'Ocean' : book.motif === 'cafe' ? 'Cafe' : book.motif === 'vintage' ? 'Cine Film' : 'Botanical'} Motif</span>
                  <Sparkle className="w-3 h-3 animate-pulse" />
                </span>
              )}
            </h2>
          </div>

          <div className="flex items-center space-x-2 w-full sm:w-auto justify-end">
            <button
              onClick={handleExportBookHtml}
              disabled={isExporting}
              className={`flex items-center space-x-1.5 bg-white text-ink-900 border border-cream-300 font-sans text-xs font-semibold px-4 py-3 hover:bg-cream-100 rounded-sm hover:shadow transition-all cursor-pointer ${isExporting ? 'opacity-75 cursor-not-allowed' : ''}`}
            >
              {isExporting ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-terracotta" />
                  <span>⏳ Packaging photos...</span>
                </>
              ) : (
                <span>📥 Save &amp; Export Album</span>
              )}
            </button>

            <button
              onClick={onPlaceOrder}
              className="flex items-center space-x-2 bg-terracotta text-cream-50 font-sans text-xs font-semibold px-6 py-3 hover:bg-amber-800 rounded-sm hover:shadow transition-all ring-offset-2 focus:ring-2 focus:ring-terracotta cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4 text-cream-200" />
              <span>Bind &amp; Print Order</span>
            </button>
          </div>
        </div>

        {/* Main interactive photobook album spreads */}
        <div className="grid lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-8 flex flex-col items-center animate-fadeIn">
            
            {/* Nav Arrows & Book Wrapper container */}
            <div className="w-full relative px-12 flex flex-col items-center justify-center">
              
              {/* Previous Arrow Button */}
              <button
                onClick={prevSpread}
                disabled={currentSpreadIndex === -1}
                className="absolute left-0 top-1/2 -translate-y-1/2 z-30 w-11 h-11 bg-white hover:bg-cream-50 text-ink-900 border border-cream-200 rounded-full flex items-center justify-center shadow-md transition-all active:scale-95 disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
                title="Previous Page"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              {/* THE BOOK WRAPPER */}
              <div 
                className="w-full aspect-[4/3] max-w-4xl p-4 rounded-lg shadow-2xl relative border flex items-center justify-center moleskine-shadow overflow-hidden group"
                style={{ 
                  backgroundColor: book.coverColor || '#EDE5D8',
                  borderColor: book.textColor ? `${book.textColor}25` : '#DFD3C1'
                }}
              >
                {/* Physical spine element mimicking Moleskine book folds */}
                <div className="absolute inset-y-0 left-1/2 -ml-3 w-6 bg-gradient-to-r from-black/5 via-black/15 to-transparent z-20 pointer-events-none rounded"></div>
                
                {/* BOOK PAGES BLOCK */}
                <div 
                  className="w-full h-full shadow-inner rounded-sm relative flex overflow-hidden border"
                  style={{
                    backgroundColor: '#FDFAF5',
                    borderColor: book.textColor ? `${book.textColor}25` : '#DFD3C1',
                    color: '#1C1B19'
                  }}
                >
                  
                  {/* LEFT FOLD/SHADOW */}
                  <div className="absolute inset-y-0 left-0 w-2.5 bg-gradient-to-r from-black/8 to-transparent z-10 pointer-events-none"></div>
                  {/* RIGHT FOLD/SHADOW */}
                  <div className="absolute inset-y-0 right-0 w-2.5 bg-gradient-to-l from-black/8 to-transparent z-10 pointer-events-none"></div>

                  {/* COVER PAGE (currentSpreadIndex === -1) */}
                  {currentSpreadIndex === -1 && (
                    <div 
                      className="absolute inset-0 flex flex-col justify-between select-none animate-fadeIn relative"
                      style={{ backgroundColor: '#FDFAF5' }}
                    >
                      <div style={{
                        position: 'relative',
                        width: '100%',
                        height: '100%',
                        borderRadius: '4px',
                        overflow: 'hidden',
                        backgroundColor: '#1C1B19'
                      }}>
                        {/* Full bleed cover photo */}
                        <img
                          src={book.coverPhotoUrl}
                          alt="cover"
                          style={{
                            position: 'absolute',
                            inset: 0,
                            width: '100%',
                            height: '100%',
                            objectFit: 'cover'
                          }}
                        />
                        {/* Gradient overlay */}
                        <div style={{
                          position: 'absolute',
                          inset: 0,
                          background: 'linear-gradient(to top, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.2) 50%, rgba(0,0,0,0) 100%)'
                        }} />
                        {/* Text on top */}
                        <div style={{
                          position: 'absolute',
                          bottom: 0,
                          left: 0,
                          right: 0,
                          padding: '40px',
                          color: '#fff',
                          textAlign: 'left'
                        }}>
                          <p style={{
                            fontSize: '10px',
                            fontFamily: 'monospace',
                            letterSpacing: '3px',
                            textTransform: 'uppercase',
                            opacity: 0.7,
                            marginBottom: '12px'
                          }}>Memoir</p>
                          <h1 style={{
                            fontFamily: 'Playfair Display, Georgia, serif',
                            fontSize: '38px',
                            fontWeight: 500,
                            lineHeight: 1.15,
                            margin: '0 0 10px',
                            letterSpacing: '-0.5px',
                            color: '#ffffff'
                          }}>{book.title}</h1>
                          <p style={{
                            fontFamily: 'Georgia, serif',
                            fontSize: '16px',
                            fontStyle: 'italic',
                            opacity: 0.85,
                            margin: 0,
                            color: '#ffffff'
                          }}>{book.subtitle}</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* STORY/NARRATIVE INTRO (currentSpreadIndex === 0) */}
                  {currentSpreadIndex === 0 && (
                    <div className="absolute inset-0 flex select-none animate-fadeIn" style={{ backgroundColor: '#FDFAF5' }}>
                      {/* Left Page (Title Leaf) */}
                      <div className="w-1/2 h-full flex flex-col justify-between p-6 sm:p-10 border-r border-stone-200/50 relative">
                        <div className="m-auto text-center max-w-xs space-y-4">
                          <span className="text-3xl block">
                            {book.motif === 'sakura' && "🌸"}
                            {book.motif === 'mountain' && "🏔️"}
                            {book.motif === 'ocean' && "🌊"}
                            {book.motif === 'cafe' && "☕"}
                            {book.motif === 'vintage' && "🎞️"}
                            {book.motif === 'botanical' && "🌿"}
                            {(!book.motif || book.motif === 'none') && "📓"}
                          </span>
                          <h1 className="font-serif text-lg sm:text-2xl font-semibold text-ink-900 tracking-tight leading-snug">
                            {book.title}
                          </h1>
                          <div className="w-10 h-px bg-terracotta mx-auto"></div>
                          <p className="font-serif italic text-[11px] sm:text-sm text-ink-500">
                            {book.subtitle}
                          </p>
                          <div className="pt-2">
                            <span className="font-mono text-[9px] uppercase tracking-widest bg-stone-100 text-stone-500 px-2 py-0.5 rounded">
                              {book.motif ? `${book.motif} edition` : "volume memoir"}
                            </span>
                          </div>
                        </div>
                        <div className="flex justify-between items-center text-[10px] font-mono opacity-50 mt-auto">
                          <span>Volume Title Page</span>
                          <span>Page I</span>
                        </div>
                      </div>

                      {/* Right Page (Foreword/Preface Story) */}
                      <div className="w-1/2 h-full flex flex-col justify-between p-6 sm:p-10 relative overflow-y-auto">
                        <div className="max-w-[280px] sm:max-w-md mx-auto my-auto py-2 relative z-10 w-full text-center">
                          <div className="font-mono text-[10px] tracking-widest uppercase opacity-60 mb-4">
                            FOREWORD
                          </div>
                          
                          {editingNarrative ? (
                            <div className="space-y-4 text-left">
                              <textarea
                                value={tempNarrative}
                                onChange={(e) => setTempNarrative(e.target.value)}
                                className="w-full h-40 font-serif text-xs sm:text-sm p-3 border rounded focus:outline-none leading-relaxed bg-white border-cream-300 text-ink-900"
                              />
                              <div className="flex justify-end space-x-2">
                                <button 
                                  onClick={() => setEditingNarrative(false)}
                                  className="text-xs font-mono px-2.5 py-1 border border-cream-300 rounded hover:bg-cream-100"
                                >
                                  Cancel
                                </button>
                                <button 
                                  onClick={handleSaveNarrative}
                                  className="bg-ink-900 text-cream-50 text-xs font-mono px-2.5 py-1 rounded"
                                >
                                  Save
                                </button>
                              </div>
                            </div>
                          ) : (
                            <div>
                              <p className="font-serif text-[10px] sm:text-xs md:text-sm leading-relaxed text-justify text-ink-900">
                                <span style={{ fontSize: '32px', fontFamily: 'Playfair Display, Georgia, serif', fontWeight: 'bold', color: '#B85E3B', float: 'left', lineHeight: '28px', marginRight: '8px', marginTop: '2px' }}>
                                  {book.openingNarrative ? book.openingNarrative.trim().charAt(0) : ''}
                                </span>
                                {book.openingNarrative ? book.openingNarrative.trim().slice(1) : ''}
                              </p>
                              
                              <button
                                onClick={() => setEditingNarrative(true)}
                                className="mt-6 flex items-center space-x-1 text-[10px] sm:text-xs hover:text-terracotta font-mono uppercase tracking-widest mx-auto text-ink-500 cursor-pointer"
                              >
                                <Edit3 className="w-3 h-3" />
                                <span>Edit story</span>
                              </button>
                            </div>
                          )}
                        </div>

                        <div className="flex justify-between items-center text-[10px] font-mono opacity-50 mt-auto border-t border-stone-100 pt-2">
                          <span>Memoir Preface</span>
                          <span>Page II</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* PHOTO SPREADS (currentSpreadIndex > 0) */}
                  {currentSpreadIndex > 0 && (() => {
                    const spread = book.spreads[currentSpreadIndex - 1];
                    if (!spread) return null;

                    const isSingle = spread.photos.length === 1;

                    return (
                      <div className="absolute inset-0 select-none animate-fadeIn flex" style={{ backgroundColor: '#FDFAF5' }}>
                        
                        {isSingle ? (
                          <>
                            {/* SINGLE PHOTO LAYOUT - LEFT PAGE (The Photo) */}
                            <div className="w-1/2 h-full flex flex-col justify-between p-6 sm:p-10 border-r border-stone-200/50 relative">
                              <div className="flex justify-between items-center text-[10px] font-mono opacity-50">
                                <span className="uppercase tracking-widest">{book.title}</span>
                                <span className="uppercase tracking-widest">Left Page</span>
                              </div>

                              <div className="my-auto flex items-center justify-center w-full max-w-sm mx-auto">
                                <div className="w-full relative group/photo aspect-[4/3] bg-white p-2.5 sm:p-3.5 shadow-md rounded border border-stone-200/30">
                                  <div className="w-full h-full overflow-hidden rounded-sm relative">
                                    <img 
                                      src={spread.photos[0].url} 
                                      alt="spread snapshot"
                                      referrerPolicy="no-referrer"
                                      className="w-full h-full object-cover"
                                    />
                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/photo:opacity-100 transition-opacity flex items-center justify-center space-x-2">
                                      <button
                                        onClick={() => handleTriggerSwap(spread.id, spread.photos[0].id, 0)}
                                        className="bg-cream-50 text-ink-900 border border-cream-300 px-2.5 py-1.5 text-xs font-mono rounded flex items-center space-x-1 shadow cursor-pointer hover:bg-cream-100"
                                      >
                                        <RefreshCw className="w-3.5 h-3.5" />
                                        <span>Swap Photo</span>
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              </div>

                              <div className="flex justify-between items-center text-[10px] font-mono text-ink-500 border-t border-cream-200/50 pt-2 mt-auto">
                                <span>Spread {currentSpreadIndex}</span>
                                <span>Page {currentSpreadIndex * 2 + 1}</span>
                              </div>
                            </div>

                            {/* SINGLE PHOTO LAYOUT - RIGHT PAGE (The Caption) */}
                            <div className="w-1/2 h-full flex flex-col justify-between p-6 sm:p-10 relative">
                              <div className="flex justify-between items-center text-[10px] font-mono opacity-50">
                                <span className="text-terracotta text-xs italic">
                                  {book.motif === 'sakura' && "🌸 Sakura Motif"}
                                  {book.motif === 'mountain' && "🏔️ Alpine Peaks"}
                                  {book.motif === 'ocean' && "🌊 Coast Wind"}
                                  {book.motif === 'cafe' && "☕ Espresso"}
                                  {book.motif === 'vintage' && "🎞️ Cine Proof"}
                                  {book.motif === 'botanical' && "🌿 Ivy Foliage"}
                                </span>
                                <span className="uppercase tracking-widest bg-stone-150 px-1 py-0.5 rounded text-[9px]">Right Page</span>
                              </div>

                              <div className="my-auto flex flex-col items-center justify-center w-full max-w-sm mx-auto">
                                {editingCaptionId === spread.id ? (
                                  <div className="text-center w-full space-y-3.5">
                                    <div style={{ width: '30px', height: '1px', backgroundColor: '#B85E3B', margin: '0 auto' }} />
                                    <div className="flex flex-col gap-2 items-center justify-center">
                                      <input
                                        type="text"
                                        value={tempCaptionText}
                                        onChange={(e) => setTempCaptionText(e.target.value)}
                                        className="w-full font-serif text-sm text-center px-2 py-2 border border-cream-400 bg-cream-50 rounded text-ink-900 focus:outline-none focus:border-ink-900"
                                        autoFocus
                                      />
                                      <div className="flex space-x-2">
                                        <button
                                          onClick={() => setEditingCaptionId(null)}
                                          className="px-3 py-1 border border-cream-300 text-ink-600 rounded text-xs cursor-pointer font-mono hover:bg-cream-100"
                                        >
                                          Cancel
                                        </button>
                                        <button
                                          onClick={() => handleSaveCaption(spread.id)}
                                          className="px-3 py-1 bg-ink-900 text-cream-50 rounded text-xs cursor-pointer font-mono hover:bg-ink-800"
                                        >
                                          Save
                                        </button>
                                      </div>
                                    </div>
                                  </div>
                                ) : (
                                  <div className="group/cap text-center w-full space-y-3.5">
                                    <div style={{ width: '30px', height: '1px', backgroundColor: '#B85E3B', margin: '0 auto' }} />
                                    <div className="flex flex-col items-center justify-center space-y-2">
                                      {spread.caption && spread.caption.trim() !== '' ? (
                                        <div className="flex items-center justify-center space-x-1.5 px-4">
                                          <p style={{
                                            fontFamily: 'Georgia, serif',
                                            fontSize: '14px',
                                            fontStyle: 'italic',
                                            color: '#1C1B19',
                                            lineHeight: 1.7,
                                            margin: 0,
                                            maxWidth: '240px'
                                          }}>
                                            "{spread.caption.replace(/^["'“'”]+|["'“'”]+$/g, "")}"
                                          </p>
                                          <button
                                            onClick={() => handleStartEditCaption(spread.id, spread.caption)}
                                            className="opacity-0 group-hover/cap:opacity-100 text-ink-500 hover:text-terracotta p-1 rounded cursor-pointer transition-opacity shrink-0"
                                            title="Edit caption"
                                          >
                                            <Edit3 className="w-3.5 h-3.5" />
                                          </button>
                                        </div>
                                      ) : (
                                        <button
                                          onClick={() => handleStartEditCaption(spread.id, "")}
                                          className="text-xs italic text-ink-400 hover:text-terracotta font-serif px-3 py-1 border border-dashed border-cream-300 rounded cursor-pointer inline-flex items-center gap-1"
                                        >
                                          <Edit3 className="w-3 h-3" />
                                          <span>Add Caption</span>
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                )}
                              </div>

                              <div className="flex justify-between items-center text-[10px] font-mono text-ink-500 border-t border-cream-200/50 pt-2 mt-auto">
                                <span>Memoir Archive</span>
                                <span>Page {currentSpreadIndex * 2 + 2}</span>
                              </div>
                            </div>
                          </>
                        ) : (
                          <>
                            {/* DOUBLE PHOTO LAYOUT - LEFT PAGE (Photo 1) */}
                            <div className="w-1/2 h-full flex flex-col justify-between p-6 sm:p-10 border-r border-stone-200/50 relative">
                              <div className="flex justify-between items-center text-[10px] font-mono opacity-50">
                                <span className="uppercase tracking-widest">{book.title}</span>
                                <span className="uppercase tracking-widest">Left Page</span>
                              </div>

                              <div className="my-auto flex items-center justify-center w-full max-w-sm mx-auto">
                                <div className="w-full relative group/photo aspect-[4/3] bg-white p-2.5 sm:p-3.5 shadow-md rounded border border-stone-200/30">
                                  <div className="w-full h-full overflow-hidden rounded-sm relative">
                                    <img 
                                      src={spread.photos[0].url} 
                                      alt="spread snapshot left"
                                      referrerPolicy="no-referrer"
                                      className="w-full h-full object-cover"
                                    />
                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/photo:opacity-100 transition-opacity flex items-center justify-center">
                                      <button
                                        onClick={() => handleTriggerSwap(spread.id, spread.photos[0].id, 0)}
                                        className="bg-cream-50 text-ink-900 border border-cream-300 px-2.5 py-1.5 text-xs font-mono rounded flex items-center space-x-1 shadow cursor-pointer hover:bg-cream-100"
                                      >
                                        <RefreshCw className="w-3.5 h-3.5" />
                                        <span>Swap Left</span>
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              </div>

                              <div className="flex justify-between items-center text-[10px] font-mono text-ink-500 border-t border-cream-200/50 pt-2 mt-auto">
                                <span>Spread {currentSpreadIndex}</span>
                                <span>Page {currentSpreadIndex * 2 + 1}</span>
                              </div>
                            </div>

                            {/* DOUBLE PHOTO LAYOUT - RIGHT PAGE (Photo 2 + Caption at the Bottom) */}
                            <div className="w-1/2 h-full flex flex-col justify-between p-6 sm:p-10 relative">
                              <div className="flex justify-between items-center text-[10px] font-mono opacity-50">
                                <span className="text-terracotta text-xs italic">
                                  {book.motif === 'sakura' && "🌸 Sakura Motif"}
                                  {book.motif === 'mountain' && "🏔️ Alpine Peaks"}
                                  {book.motif === 'ocean' && "🌊 Coast Wind"}
                                  {book.motif === 'cafe' && "☕ Espresso"}
                                  {book.motif === 'vintage' && "🎞️ Cine Proof"}
                                  {book.motif === 'botanical' && "🌿 Ivy Foliage"}
                                </span>
                                <span className="uppercase tracking-widest bg-stone-150 px-1 py-0.5 rounded text-[9px]">Right Page</span>
                              </div>

                              <div className="my-auto flex flex-col items-center justify-center w-full max-w-sm mx-auto space-y-4">
                                <div className="w-full relative group/photo aspect-[4/3] bg-white p-2.5 sm:p-3.5 shadow-md rounded border border-stone-200/30">
                                  <div className="w-full h-full overflow-hidden rounded-sm relative">
                                    <img 
                                      src={spread.photos[1]?.url || spread.photos[0].url} 
                                      alt="spread snapshot right"
                                      referrerPolicy="no-referrer"
                                      className="w-full h-full object-cover"
                                    />
                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/photo:opacity-100 transition-opacity flex items-center justify-center">
                                      <button
                                        onClick={() => handleTriggerSwap(spread.id, spread.photos[1]?.id || spread.photos[0].id, 1)}
                                        className="bg-cream-50 text-ink-900 border border-cream-300 px-2.5 py-1.5 text-xs font-mono rounded flex items-center space-x-1 shadow cursor-pointer hover:bg-cream-100"
                                      >
                                        <RefreshCw className="w-3.5 h-3.5" />
                                        <span>Swap Right</span>
                                      </button>
                                    </div>
                                  </div>
                                </div>

                                {/* Double Photo Caption block rendered perfectly below Photo 2 */}
                                <div className="w-full">
                                  {editingCaptionId === spread.id ? (
                                    <div className="text-center w-full space-y-2">
                                      <input
                                        type="text"
                                        value={tempCaptionText}
                                        onChange={(e) => setTempCaptionText(e.target.value)}
                                        className="w-full font-serif text-[11px] sm:text-xs text-center px-1.5 py-1 border border-cream-400 bg-cream-50 rounded text-ink-900 focus:outline-none focus:border-ink-900"
                                        autoFocus
                                      />
                                      <div className="flex space-x-1 justify-center">
                                        <button
                                          onClick={() => setEditingCaptionId(null)}
                                          className="px-2 py-0.5 border border-cream-300 text-ink-600 rounded text-[10px] cursor-pointer font-mono hover:bg-cream-100"
                                        >
                                          Cancel
                                        </button>
                                        <button
                                          onClick={() => handleSaveCaption(spread.id)}
                                          className="px-2 py-0.5 bg-ink-900 text-cream-50 rounded text-[10px] cursor-pointer font-mono hover:bg-ink-800"
                                        >
                                          Save
                                        </button>
                                      </div>
                                    </div>
                                  ) : (
                                    <div className="group/cap text-center w-full">
                                      {spread.caption && spread.caption.trim() !== '' ? (
                                        <div className="flex items-center justify-center space-x-1 px-4">
                                          <p style={{
                                            fontFamily: 'Georgia, serif',
                                            fontSize: '12px',
                                            fontStyle: 'italic',
                                            color: '#1C1B19',
                                            lineHeight: 1.5,
                                            margin: 0,
                                            maxWidth: '220px'
                                          }}>
                                            "{spread.caption.replace(/^["'“'”]+|["'“'”]+$/g, "")}"
                                          </p>
                                          <button
                                            onClick={() => handleStartEditCaption(spread.id, spread.caption)}
                                            className="opacity-0 group-hover/cap:opacity-100 text-ink-500 hover:text-terracotta p-0.5 rounded cursor-pointer transition-opacity shrink-0"
                                            title="Edit caption"
                                          >
                                            <Edit3 className="w-3 h-3" />
                                          </button>
                                        </div>
                                      ) : (
                                        <button
                                          onClick={() => handleStartEditCaption(spread.id, "")}
                                          className="text-[10px] italic text-ink-400 hover:text-terracotta font-serif px-2 py-0.5 border border-dashed border-cream-300 rounded cursor-pointer inline-flex items-center gap-1"
                                        >
                                          <Edit3 className="w-2.5 h-2.5" />
                                          <span>Add Caption</span>
                                        </button>
                                      )}
                                    </div>
                                  )}
                                </div>
                              </div>

                              <div className="flex justify-between items-center text-[10px] font-mono text-ink-500 border-t border-cream-200/50 pt-2 mt-auto">
                                <span>Memoir Archive</span>
                                <span>Page {currentSpreadIndex * 2 + 2}</span>
                              </div>
                            </div>
                          </>
                        )}

                      </div>
                    );
                  })()}

                </div>
              </div>

              {/* Next Arrow Button */}
              <button
                onClick={nextSpread}
                disabled={currentSpreadIndex === book.spreads.length}
                className="absolute right-0 top-1/2 -translate-y-1/2 z-30 w-11 h-11 bg-white hover:bg-cream-50 text-ink-900 border border-cream-200 rounded-full flex items-center justify-center shadow-md transition-all active:scale-95 disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
                title="Next Page"
              >
                <ChevronRight className="w-5 h-5" />
              </button>

            </div>

            {/* Current Page Indicator "2 / 8" and pagination dots */}
            <div className="flex flex-col items-center mt-6 space-y-2">
              <span className="font-mono text-xs text-ink-500 tracking-wider">
                {currentSpreadIndex + 2} / {totalPages}
              </span>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setCurrentSpreadIndex(-1)}
                  className={`w-2.5 h-2.5 rounded-full border transition-all cursor-pointer ${currentSpreadIndex === -1 ? "bg-terracotta border-terracotta scale-110" : "bg-cream-300 border-transparent hover:bg-cream-400"}`}
                  title="Cover"
                />
                <button
                  onClick={() => setCurrentSpreadIndex(0)}
                  className={`w-2.5 h-2.5 rounded-full border transition-all cursor-pointer ${currentSpreadIndex === 0 ? "bg-terracotta border-terracotta scale-110" : "bg-cream-300 border-transparent hover:bg-cream-400"}`}
                  title="Foreword"
                />
                {book.spreads.map((spread, idx) => (
                  <button
                    key={spread.id}
                    onClick={() => setCurrentSpreadIndex(idx + 1)}
                    className={`w-2.5 h-2.5 rounded-full border transition-all cursor-pointer ${currentSpreadIndex === idx + 1 ? "bg-terracotta border-terracotta scale-110" : "bg-cream-300 border-transparent hover:bg-cream-400"}`}
                    title={`Spread ${idx + 1}`}
                  />
                ))}
              </div>
            </div>

          </div>

          {/* SIDEBAR: ACTIVE SPREAD CONTROLS */}
          <div className="lg:col-span-4 bg-cream-100/30 border border-cream-200/70 p-5 rounded-md moleskine-shadow">
            <h3 className="font-serif text-base font-semibold text-ink-900 border-b border-cream-200 pb-2 mb-4 flex items-center gap-1.5">
              <span>Spread Editor</span>
              {book.motif && book.motif !== 'none' && (
                <span>
                  {book.motif === 'sakura' && "🌸"}
                  {book.motif === 'mountain' && "🏔️"}
                  {book.motif === 'ocean' && "🌊"}
                  {book.motif === 'cafe' && "☕"}
                  {book.motif === 'vintage' && "🎞️"}
                  {book.motif === 'botanical' && "🌿"}
                </span>
              )}
            </h3>

            {currentSpreadIndex === -1 && (
              <div className="space-y-4">
                <p className="font-sans text-xs text-ink-500 leading-relaxed">
                  You are viewing the front Cover page. Tap the inputs to rewrite the volume headings.
                </p>
                <div>
                  <label className="font-mono text-[9px] uppercase tracking-widest text-ink-500">Book Title</label>
                  <input
                    type="text"
                    value={book.title}
                    onChange={(e) => onUpdateBook({ ...book, title: e.target.value })}
                    className="w-full mt-1 font-serif text-sm p-2 border border-cream-300 bg-cream-50 focus:outline-none focus:border-ink-900 rounded-sm"
                  />
                </div>
                <div>
                  <label className="font-mono text-[9px] uppercase tracking-widest text-ink-500">Subtitle Or Chapter</label>
                  <input
                    type="text"
                    value={book.subtitle}
                    onChange={(e) => onUpdateBook({ ...book, subtitle: e.target.value })}
                    className="w-full mt-1 font-serif text-sm p-2 border border-cream-300 bg-cream-50 focus:outline-none focus:border-ink-900 rounded-sm"
                  />
                </div>
              </div>
            )}

            {currentSpreadIndex === 0 && (
              <div className="space-y-4">
                <p className="font-sans text-xs text-ink-500 leading-relaxed">
                  This is the opening memory narrative. This literary introduction frames the entire story book automatically.
                </p>
                {!editingNarrative && (
                  <button
                    onClick={() => setEditingNarrative(true)}
                    className="w-full py-2.5 bg-ink-900 text-cream-50 text-xs font-mono uppercase tracking-wider rounded-sm hover:bg-ink-700 font-semibold cursor-pointer"
                  >
                    Edit Opening Text
                  </button>
                )}
              </div>
            )}

            {currentSpreadIndex > 0 && (
              <div className="space-y-4">
                {(() => {
                  const spread = book.spreads[currentSpreadIndex - 1];
                  if (!spread) return null;

                  return (
                    <div>
                      <span className="font-mono text-[10px] uppercase text-ink-500 block mb-1">
                        Editing Page spread {currentSpreadIndex}
                      </span>
                      
                      <div className="space-y-4 py-2">
                        <div>
                          <label className="font-mono text-[9px] uppercase tracking-widest text-ink-500">Spread Layout</label>
                          <button
                            onClick={() => handleToggleLayout(spread.id)}
                            className="w-full mt-1.5 flex items-center justify-between border border-cream-300 bg-cream-50 hover:bg-cream-100 p-2.5 rounded text-xs font-medium text-ink-700 cursor-pointer"
                          >
                            <span className="capitalize">{spread.layout} Layout</span>
                            <LayoutGrid className="w-3.5 h-3.5 text-ink-500" />
                          </button>
                        </div>

                        <div>
                          <label className="font-mono text-[9px] uppercase tracking-widest text-ink-500 block mb-2">Photos in spread ({spread.photos.length})</label>
                          <div className="space-y-3 mt-2">
                            {spread.photos.map((photo, pIdx) => (
                              <div key={photo.id} className="flex flex-col border border-cream-200 bg-cream-50/70 p-3 rounded-md shadow-sm gap-2.5">
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center space-x-2">
                                    <img src={photo.url} alt="sub" className="w-10 h-10 object-cover rounded-md border border-cream-200" />
                                    <div>
                                      <span className="font-sans text-[11px] text-ink-900 font-semibold block truncate max-w-[120px]">
                                        {photo.location || "Preserved snapshot"}
                                      </span>
                                      <span className="text-[9px] font-mono text-ink-400 capitalize block">
                                        {photo.category || "general"} composition
                                      </span>
                                    </div>
                                  </div>
                                  <button
                                    onClick={() => handleTriggerSwap(spread.id, photo.id, pIdx)}
                                    className="text-[10px] font-mono text-terracotta hover:underline cursor-pointer bg-terracotta/5 border border-terracotta/10 px-2 py-0.5 rounded"
                                  >
                                    Swap
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="h-px bg-cream-200 my-4"></div>

                        <button
                          onClick={() => handleDeleteSpread(spread.id)}
                          className="w-full py-2 border border-rose-300 text-rose-700 hover:bg-rose-50 rounded text-xs font-mono uppercase tracking-wider flex items-center justify-center space-x-1.5 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete this Spread</span>
                        </button>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>
        </div>

        {/* SWAPPING POPUP DIALOG */}
        {swappingPhotoState && (
          <div className="fixed inset-0 bg-ink-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <div className="bg-cream-50 border border-cream-200 p-6 rounded-md shadow-2xl max-w-xl w-full max-h-[80vh] overflow-y-auto animate-fadeIn">
              <div className="flex justify-between items-start pb-4 border-b border-cream-200">
                <div>
                  <h4 className="font-serif text-lg font-semibold text-ink-900">
                    Swap Photo Spread Leaf
                  </h4>
                  <p className="font-sans text-xs text-ink-500 mt-1">
                    Choose an alternative memory snapshot from your connected library to assign to this section.
                  </p>
                </div>
                <button 
                  onClick={() => setSwappingPhotoState(null)}
                  className="text-ink-500 hover:text-ink-950 font-mono text-xs border border-cream-200 px-3 py-1 rounded cursor-pointer"
                >
                  Close
                </button>
              </div>

              {unusedPhotoCandidates.length === 0 ? (
                <div className="text-center py-10">
                  <p className="font-sans text-sm text-ink-500">
                    No other unused photos left in your curation pool.
                  </p>
                  <p className="font-sans text-xs text-ink-500 mt-1">
                    Connect more snapshots to unlock higher swapping flexibility.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5 my-6">
                  {unusedPhotoCandidates.map((photo) => (
                    <div
                      key={photo.id}
                      onClick={() => handleExecuteSwap(photo)}
                      className="group relative aspect-[4/3] rounded overflow-hidden border border-cream-200 shadow-sm hover:border-terracotta cursor-pointer"
                    >
                      <img 
                        src={photo.url} 
                        alt="candidate photo" 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover transition-transform group-hover:scale-102"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <span className="bg-cream-50 text-ink-900 px-2.5 py-1 text-[10px] font-mono rounded inline-flex items-center space-x-1 font-semibold">
                          <Check className="w-3 h-3 text-sage" />
                          <span>Select</span>
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* DOWNLOAD SUCCESS DIALOG */}
        {showDownloadSuccess && (
          <div className="fixed inset-0 bg-ink-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fadeIn">
            <div className="bg-cream-50 border border-cream-200 p-8 rounded-lg shadow-2xl max-w-lg w-full text-center relative overflow-hidden">
              <div className="text-5xl mb-3.5 mt-2">📚✨</div>
              
              <h4 className="font-serif text-2xl font-semibold text-ink-900 mb-2">
                Memoir Standalone Album Saved!
              </h4>
              <p className="font-sans text-sm text-ink-700 leading-relaxed mb-6">
                Your high-fidelity printable album HTML file is downloaded and ready on your computer! Because of browser sandbox restrictions with preview screens, you can open and print/save it anytime directly from your hard drive with 100% resolution.
              </p>

              <div className="bg-white border border-cream-200 rounded-md p-4 text-left space-y-3.5 mb-6 text-xs text-ink-600">
                <p className="font-semibold text-terracotta uppercase tracking-wider text-[10px]">✨ Next Easy Steps to print or save as PDF:</p>
                <div className="flex items-start space-x-2.5">
                  <span className="bg-terracotta/10 text-terracotta px-2 py-0.5 rounded-full font-bold text-[10px] scale-90">1</span>
                  <span>Double-click or open the downloaded <strong>.html</strong> file in your native browser.</span>
                </div>
                <div className="flex items-start space-x-2.5">
                  <span className="bg-terracotta/10 text-terracotta px-2 py-0.5 rounded-full font-bold text-[10px] scale-90">2</span>
                  <span>Click the big orange <strong>Save Book as PDF</strong> button at the top of the page.</span>
                </div>
                <div className="flex items-start space-x-2.5">
                  <span className="bg-terracotta/10 text-terracotta px-2 py-0.5 rounded-full font-bold text-[10px] scale-90">3</span>
                  <span>In the printable settings, choose for best outcomes: 
                    <br/>✔️ margins set to <strong>"None" or "Minimum"</strong>
                    <br/>✔️ enable <strong>"Background Graphics/background-colors"</strong> to view gorgeous textured paper motifs!
                  </span>
                </div>
              </div>

              <div className="flex justify-center">
                <button 
                  onClick={() => setShowDownloadSuccess(false)}
                  className="bg-terracotta text-cream-50 font-sans text-xs font-semibold px-8 py-3.5 hover:bg-amber-800 rounded-sm hover:shadow transition-all cursor-pointer w-full sm:w-auto"
                >
                  Got it, close this layout!
                </button>
              </div>
            </div>
          </div>
        )}

        {/* PACKAGING LOADER DIALOG */}
        {isExporting && (
          <div className="fixed inset-0 bg-ink-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fadeIn">
            <div className="bg-cream-50 border border-cream-200 p-8 rounded-lg shadow-2xl max-w-md w-full text-center relative overflow-hidden">
              <div className="flex justify-center mb-4">
                <RefreshCw className="w-12 h-12 text-terracotta animate-spin" />
              </div>
              <h4 className="font-serif text-xl font-semibold text-ink-900 mb-2 animate-pulse">
                Packaging Memory Album...
              </h4>
              <p className="font-sans text-sm text-ink-700 leading-relaxed">
                Caching your snapshots & converting high-fidelity photos to offline-safe Base64 data. This guarantees that your downloaded album file will load instantly, completely offline, and with 100% resolution anywhere on earth!
              </p>
              <div className="mt-6 flex justify-center text-xs font-mono text-terracotta bg-terracotta/5 border border-terracotta/10 px-4 py-2 rounded-full">
                <span>Please keep this window active.</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* EXQUISITE PRINT/PDF COMPILING RENDER (HIDDEN ON SCREEN, REVEALED ON PRINT) */}
      <div className="print-only w-full">
        {/* Cover Page */}
        <div 
          className="w-full flex flex-col justify-between"
          style={{ 
            backgroundColor: book.pageColor || '#1C1B19',
            pageBreakAfter: 'always',
            minHeight: '230mm',
            position: 'relative',
            overflow: 'hidden'
          }}
        >
          {/* Full bleed cover photo */}
          <img
            src={book.coverPhotoUrl}
            alt="cover"
            style={{
              position: 'absolute',
              inset: 0,
              width: '100%',
              height: '100%',
              objectFit: 'cover'
            }}
          />
          <div style={{
            position: 'absolute',
            inset: 0,
            background: 'linear-gradient(to top, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.2) 50%, rgba(0,0,0,0) 100%)'
          }} />
          <div style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            padding: '40px',
            color: '#fff',
            textAlign: 'left',
            zIndex: 10
          }}>
            <p style={{
              fontSize: '10px',
              fontFamily: 'monospace',
              letterSpacing: '3px',
              textTransform: 'uppercase',
              opacity: 0.7,
              marginBottom: '12px'
            }}>Memoir</p>
            <h1 style={{
              fontFamily: 'Playfair Display, Georgia, serif',
              fontSize: '38px',
              fontWeight: 500,
              lineHeight: 1.15,
              margin: '0 0 10px',
              letterSpacing: '-0.5px',
              color: '#ffffff'
            }}>{book.title}</h1>
            <p style={{
              fontFamily: 'Georgia, serif',
              fontSize: '16px',
              fontStyle: 'italic',
              opacity: 0.85,
              margin: 0,
              color: '#ffffff'
            }}>{book.subtitle}</p>
          </div>
        </div>

        {/* Narrative / Preface Page */}
        <div 
          className="w-full flex flex-col justify-between p-16"
          style={{ 
            backgroundColor: '#FDFAF5',
            color: '#1C1B19',
            pageBreakAfter: 'always',
            minHeight: '230mm'
          }}
        >
          <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between', height: '100%', flexGrow: 1 }}>
            <div style={{ fontFamily: 'monospace', fontSize: '10px', letterSpacing: '2px', textTransform: 'uppercase', opacity: 0.6, textAlign: 'center', marginBottom: '30px' }}>
              FOREWORD
            </div>
            <div style={{ maxWidth: '560px', margin: 'auto', textAlign: 'justify' }}>
              <p style={{ fontFamily: 'Georgia, serif', fontSize: '17px', lineHeight: '1.9', color: '#1C1B19', margin: 0 }}>
                <span style={{ fontSize: '48px', fontFamily: 'Playfair Display, Georgia, serif', fontWeight: 'bold', color: '#B85E3B', float: 'left', lineHeight: '40px', marginRight: '12px', marginTop: '4px' }}>
                  {book.openingNarrative ? book.openingNarrative.trim().charAt(0) : ''}
                </span>
                {book.openingNarrative ? book.openingNarrative.trim().slice(1) : ''}
              </p>
            </div>
            <div style={{ fontFamily: 'monospace', fontSize: '10px', opacity: 0.5, borderTop: '1px solid rgba(28,27,25,0.08)', paddingTop: '15px', marginTop: '40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span>Volume Narrative Preface</span>
              <span>Printed Page II</span>
            </div>
          </div>
        </div>

        {/* Spreads Page Compilation */}
        {book.spreads.map((spread, idx) => {
          const isSingle = spread.photos.length === 1;
          const captionText = (spread.caption || "A moment worth keeping.").replace(/^["'“'”]+|["'“'”]+$/g, "");
          
          return (
            <div 
              key={spread.id}
              className="w-full flex flex-col justify-between p-12"
              style={{ 
                backgroundColor: '#FDFAF5',
                color: '#1C1B19',
                pageBreakAfter: 'always',
                minHeight: '230mm'
              }}
            >
              <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between', height: '100%', flexGrow: 1 }}>
                {/* Header Stamp */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontFamily: 'monospace', fontSize: '10px', opacity: 0.6, borderBottom: '1px solid rgba(28,27,25,0.08)', paddingBottom: '15px', marginBottom: '20px' }}>
                  <span style={{ textTransform: 'uppercase' }}>{book.title}</span>
                  <span style={{ color: '#B85E3B', fontStyle: 'italic' }}>
                    {book.motif === 'sakura' ? "🌸 Kyoto Sakura Series 🌸" : 
                      book.motif === 'mountain' ? "🏔️ Alpine Exploration 🏔️" : 
                      book.motif === 'ocean' ? "🌊 Maritime Driftwood 🌊" : 
                      book.motif === 'cafe' ? "☕ Specialty Coffee Beans ☕" : 
                      book.motif === 'vintage' ? "🎞️ Archival Cine Roll 🎞️" : 
                      book.motif === 'botanical' ? "🌿 Botanical Greenhouse 🌿" : ""}
                  </span>
                  <span>Spread {idx + 1}</span>
                </div>

                {/* Photos Grid */}
                <div style={{ margin: 'auto', width: '100%', maxWidth: '640px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flexGrow: 1 }}>
                  {isSingle ? (
                    <div style={{ width: '100%', aspectRatio: '4/3', borderRadius: '6px', overflow: 'hidden', boxShadow: '0 4px 12px rgba(0,0,0,0.08)' }}>
                      <img src={spread.photos[0].url} alt="Spread Photo" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    </div>
                  ) : (
                    <div style={{ width: '100%', display: 'flex', gap: '16px', alignItems: 'center', justifyContent: 'center' }}>
                      {spread.photos.slice(0, 2).map(ph => (
                        <div key={ph.id} style={{ flex: 1, aspectRatio: '4/3', borderRadius: '6px', overflow: 'hidden', boxShadow: '0 4px 12px rgba(0,0,0,0.08)' }}>
                          <img src={ph.url} alt="Spread Photo" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Caption */}
                  {spread.caption && spread.caption.trim() !== '' && (
                    <div style={{ textAlign: 'center', marginTop: '24px', padding: '0 20px', width: '100%' }}>
                      <div style={{ width: '30px', height: '1px', backgroundColor: '#B85E3B', margin: '0 auto 14px' }} />
                      <p style={{ fontFamily: 'Georgia, serif', fontSize: '15px', fontStyle: 'italic', color: '#1C1B19', lineHeight: 1.7, margin: 0, maxWidth: '480px', marginLeft: 'auto', marginRight: 'auto' }}>
                        {captionText}
                      </p>
                    </div>
                  )}
                </div>

                {/* Footer Pagination */}
                <div style={{ fontFamily: 'monospace', fontSize: '10px', opacity: 0.5, borderTop: '1px solid rgba(28,27,25,0.08)', paddingTop: '15px', marginTop: '20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span>Spread {idx + 1} &mdash; page {idx * 2 + 1}</span>
                  <span>Printed Page {idx * 2 + 2}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
