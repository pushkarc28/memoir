import { useState, useEffect } from "react";
import { OrderDetails } from "../types";
import { Shield, CreditCard, Landmark, CheckCircle2, RotateCw } from "lucide-react";

interface RazorpayModalProps {
  order: Omit<OrderDetails, "id" | "createdAt" | "paymentStatus">;
  onSuccess: (paymentId: string) => void;
  onFailed: () => void;
  onClose: () => void;
}

export default function RazorpayModal({ order, onSuccess, onFailed, onClose }: RazorpayModalProps) {
  const [method, setMethod] = useState<'upi' | 'card' | 'netbanking'>('upi');
  const [processing, setProcessing] = useState(false);
  const [processStep, setProcessStep] = useState("");
  const [cardNumber, setCardNumber] = useState("4315 8489 2910 4820");
  const [cardHolder, setCardHolder] = useState(order.shippingAddress.fullName);
  const [upiId, setUpiId] = useState("pushkar@ybl");

  const handleSimulatePayment = (success: boolean) => {
    setProcessing(true);
    setProcessStep("Contacting secure bank ledger...");

    setTimeout(() => {
      setProcessStep("Authorizing credentials via secure token...");
      
      setTimeout(() => {
        setProcessStep("Verifying payment capture signatures...");
        
        setTimeout(() => {
          setProcessing(false);
          if (success) {
            const mockPayId = `pay_${Math.random().toString(36).substring(2, 15)}`;
            onSuccess(mockPayId);
          } else {
            onFailed();
          }
        }, 1200);
      }, 1000);
    }, 1000);
  };

  return (
    <div className="fixed inset-0 bg-zinc-950/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      {/* THE RAZORPAY MODAL FRAME */}
      <div className="bg-white rounded-lg shadow-2xl max-w-sm w-full overflow-hidden border border-zinc-200">
        
        {/* Razorpay Brand Header */}
        <div className="bg-indigo-600 p-4 text-white flex justify-between items-center relative">
          <div>
            <div className="flex items-center space-x-1">
              <span className="font-bold text-lg tracking-tight font-sans">Razorpay</span>
              <span className="bg-cyan-400 text-indigo-950 font-mono font-bold text-[8px] px-1 rounded">SECURE</span>
            </div>
            <p className="text-[10px] text-indigo-200 mt-1">
              Ref: {order.bookTitle.substring(0, 15)}...
            </p>
          </div>
          <div className="text-right">
            <span className="font-mono text-base font-bold">
              ₹{order.price.toLocaleString("en-IN")}
            </span>
            <p className="text-[8px] text-indigo-200">Amount due</p>
          </div>
        </div>

        {processing ? (
          /* TRANSACTION PENDING LAYER */
          <div className="p-10 flex flex-col items-center justify-center text-center space-y-4 animate-fadeIn">
            <RotateCw className="w-10 h-10 text-indigo-600 animate-spin" />
            <div>
              <h5 className="font-sans font-semibold text-sm text-zinc-900">
                Processing payment gateway
              </h5>
              <p className="font-mono text-[10px] text-zinc-500 mt-1 animate-pulse">
                {processStep}
              </p>
            </div>
            <div className="w-full bg-zinc-100 h-1.5 rounded-full overflow-hidden">
              <div className="bg-indigo-600 h-full w-2/3 rounded-full animate-pulse"></div>
            </div>
          </div>
        ) : (
          /* SELECT PAYMENT METHOD */
          <div className="p-4">
            
            {/* Preferred selection tabs */}
            <div className="grid grid-cols-3 gap-2 border-b border-zinc-100 pb-3 mb-4">
              <button
                onClick={() => setMethod('upi')}
                className={`py-2 px-1 text-center font-sans text-[10px] font-semibold border rounded-sm flex flex-col items-center justify-center transition-all cursor-pointer ${
                  method === 'upi' 
                    ? "border-indigo-600 text-indigo-600 bg-indigo-50/20" 
                    : "border-zinc-200 text-zinc-600 hover:bg-zinc-50"
                }`}
              >
                <span className="mb-1 leading-none text-xs font-bold font-mono">UPI</span>
                <span className="scale-75 text-[8px]">QR or App</span>
              </button>

              <button
                onClick={() => setMethod('card')}
                className={`py-2 px-1 text-center font-sans text-[10px] font-semibold border rounded-sm flex flex-col items-center justify-center transition-all cursor-pointer ${
                  method === 'card' 
                    ? "border-indigo-600 text-indigo-600 bg-indigo-50/20" 
                    : "border-zinc-200 text-zinc-600 hover:bg-zinc-50"
                }`}
              >
                <CreditCard className="w-4 h-4 mb-1" />
                <span>Cards</span>
              </button>

              <button
                onClick={() => setMethod('netbanking')}
                className={`py-2 px-1 text-center font-sans text-[10px] font-semibold border rounded-sm flex flex-col items-center justify-center transition-all cursor-pointer ${
                  method === 'netbanking' 
                    ? "border-indigo-600 text-indigo-600 bg-indigo-50/20" 
                    : "border-zinc-200 text-zinc-600 hover:bg-zinc-50"
                }`}
              >
                <Landmark className="w-4 h-4 mb-1" />
                <span>Net Banking</span>
              </button>
            </div>

            {/* Render forms based on selected option */}
            <div className="min-h-[140px] space-y-3 font-sans text-xs">
              {method === 'upi' && (
                <div className="space-y-3 animate-fadeIn">
                  <div>
                    <label className="text-[10px] font-semibold text-zinc-500">Your UPI ID (VPA)</label>
                    <input
                      type="text"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      className="w-full mt-1 px-3 py-2 border border-zinc-200 rounded focus:outline-none focus:border-indigo-600 font-mono text-zinc-800"
                    />
                  </div>
                  <div className="bg-zinc-50 p-2.5 rounded border border-zinc-100 flex items-center space-x-2">
                    <div className="w-10 h-10 bg-zinc-300 rounded shrink-0 flex items-center justify-center font-mono font-bold text-[8px] border">QR CODE</div>
                    <p className="text-[9px] text-zinc-500 leading-normal">
                      Scan the QR inside any UPI client (GPay, PhonePe, BHIM) to approve payment instantly.
                    </p>
                  </div>
                </div>
              )}

              {method === 'card' && (
                <div className="space-y-3 animate-fadeIn">
                  <div>
                    <label className="text-[10px] font-semibold text-zinc-500">Card Number</label>
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      className="w-full mt-1 px-3 py-2 border border-zinc-200 rounded focus:outline-none focus:border-indigo-600 font-mono"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] font-semibold text-zinc-500">Expiry (MM/YY)</label>
                      <input
                        type="text"
                        placeholder="11/29"
                        className="w-full mt-1 px-3 py-2 border border-zinc-200 rounded focus:outline-none focus:border-indigo-600 font-mono text-center"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-semibold text-zinc-500">CVV</label>
                      <input
                        type="password"
                        placeholder="•••"
                        className="w-full mt-1 px-3 py-2 border border-zinc-200 rounded focus:outline-none focus:border-indigo-600 font-mono text-center"
                      />
                    </div>
                  </div>
                </div>
              )}

              {method === 'netbanking' && (
                <div className="grid grid-cols-2 gap-2 py-2 animate-fadeIn text-center">
                  <button className="p-2 border rounded hover:border-indigo-500 font-semibold text-[10px]">SBI</button>
                  <button className="p-2 border rounded hover:border-indigo-500 font-semibold text-[10px]">HDFC</button>
                  <button className="p-2 border rounded hover:border-indigo-500 font-semibold text-[10px]">ICICI</button>
                  <button className="p-2 border rounded hover:border-indigo-500 font-semibold text-[10px]">Axis Bank</button>
                </div>
              )}
            </div>

            {/* Simulator Controls */}
            <div className="mt-6 border-t border-zinc-100 pt-4 grid grid-cols-2 gap-2">
              <button
                onClick={() => handleSimulatePayment(false)}
                className="w-full bg-zinc-100 hover:bg-zinc-200 text-rose-700 py-2.5 rounded text-xs font-semibold font-mono border border-rose-100 cursor-pointer text-center"
              >
                Simulate Fail
              </button>
              <button
                onClick={() => handleSimulatePayment(true)}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2.5 rounded text-xs font-semibold cursor-pointer text-center"
              >
                Simulate Success
              </button>
            </div>

            {/* Cancel trigger */}
            <div className="text-center mt-3">
              <button 
                onClick={onClose} 
                className="text-[10px] font-mono text-zinc-400 hover:text-zinc-600"
              >
                Cancel transaction
              </button>
            </div>
            
            {/* Protection Footer */}
            <div className="mt-4 pt-3 border-t border-zinc-50 text-center flex justify-center items-center space-x-1.5 text-zinc-400 text-[8px] uppercase tracking-wide">
              <Shield className="w-3.5 h-3.5 text-emerald-500" />
              <span>PCI-DSS SSL Secured Transaction</span>
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
