import React, { useState, useEffect } from "react";
import { MemoirBook, BookSpread, Photo } from "../types";
import { 
  BookOpen, 
  Sparkles, 
  Trash2, 
  Camera, 
  RotateCcw, 
  Save, 
  Layout, 
  AlignLeft, 
  Image as ImageIcon, 
  Palette, 
  Info, 
  Copy, 
  Check, 
  Plus, 
  Edit, 
  ArrowUp, 
  ArrowDown, 
  X, 
  Coffee, 
  RefreshCw, 
  Eye, 
  Sliders, 
  ArrowLeftRight,
  Sparkle
} from "lucide-react";

export default function AdminDashboard() {
  const [savedBooks, setSavedBooks] = useState<MemoirBook[]>([]);
  const [currentBook, setCurrentBook] = useState<MemoirBook | null>(null);
  const [originalBook, setOriginalBook] = useState<MemoirBook | null>(null);
  
  const [activePanel, setActivePanel] = useState<'overview' | 'cover' | 'narrative' | 'spreads' | 'photos' | 'design' | 'backgrounds' | 'metadata'>('overview');
  
  // Selection and editing states
  const [selectedSpreadId, setSelectedSpreadId] = useState<string | null>(null);
  const [editingPhotoId, setEditingPhotoId] = useState<string | null>(null);
  const [photoEditForm, setPhotoEditForm] = useState<Omit<Photo, "id" | "timestamp">>({
    url: "",
    title: "",
    location: "",
    category: "travel",
    aspectRatio: "landscape"
  });

  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [showToast, setShowToast] = useState<string | null>(null);
  
  // Form/UI local states for spreads addition/swapping
  const [addingPhotoSpreadId, setAddingPhotoSpreadId] = useState<string | null>(null);

  // Trigger toast timer
  useEffect(() => {
    if (showToast) {
      const timer = setTimeout(() => setShowToast(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [showToast]);

  const triggerToast = (msg: string) => {
    setShowToast(msg);
  };

  // 1. Load active drafts from Backend Express API
  const fetchBooks = async (loadFirst = false) => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/books");
      if (res.ok) {
        const data: MemoirBook[] = await res.json();
        setSavedBooks(data);
        
        if (data.length > 0) {
          if (loadFirst || !currentBook) {
            setCurrentBook(JSON.parse(JSON.stringify(data[0])));
            setOriginalBook(JSON.parse(JSON.stringify(data[0])));
          } else {
            // Synchronize loaded metadata if our active book exists
            const refreshed = data.find(b => b.id === currentBook.id);
            if (refreshed) {
              setCurrentBook(JSON.parse(JSON.stringify(refreshed)));
              setOriginalBook(JSON.parse(JSON.stringify(refreshed)));
            }
          }
        } else {
          // No books found on server, seed a gorgeous initial Kyoto book draft
          seedSampleBook();
        }
      }
    } catch (err) {
      console.error("[Admin API] Failed to fetch saved books:", err);
      triggerToast("Error reading backend database.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchBooks(true);
  }, []);

  const seedSampleBook = () => {
    const defaultPhotos: Photo[] = [
      {
        id: 'kyoto-1',
        url: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=800&auto=format&fit=crop',
        title: 'Kinkaku-ji Golden Pavilion',
        timestamp: new Date().toISOString(),
        location: 'Kinkaku-ji, Kyoto',
        category: 'travel',
        aspectRatio: 'landscape'
      },
      {
        id: 'kyoto-2',
        url: 'https://images.unsplash.com/photo-1542044896530-05d85be9b11a?q=80&w=800&auto=format&fit=crop',
        title: 'Arashiyama Bamboo Grove',
        timestamp: new Date().toISOString(),
        location: 'Bamboo Grove, Kyoto',
        category: 'nature',
        aspectRatio: 'portrait'
      },
      {
        id: 'kyoto-3',
        url: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?q=80&w=800&auto=format&fit=crop',
        title: 'Gion Streets at Dusk',
        timestamp: new Date().toISOString(),
        location: 'Gion District, Kyoto',
        category: 'travel',
        aspectRatio: 'landscape'
      },
      {
        id: 'kyoto-4',
        url: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=800&auto=format&fit=crop',
        title: 'Weekenders Espresso',
        timestamp: new Date().toISOString(),
        location: 'Weekenders Coffee',
        category: 'cafe',
        aspectRatio: 'square'
      }
    ];

    const seeded: MemoirBook = {
      id: 'kyoto-wanderlust-001',
      title: 'Kyoto Wanderlust',
      subtitle: 'Autumn days exploring temples, alleys, and tea houses.',
      style: 'moleskine',
      coverPhotoUrl: defaultPhotos[0].url,
      openingNarrative: 'There is a particular quality to autumn light in Kyoto — the way it filters through maples, gilding the stone lanterns and still-water reflections at Kinkaku-ji. This book is a quiet record of those eleven days: temples half-hidden in mist, side streets that smelled of toasted sesame, and the low hum of a city that carries centuries in its posture.',
      spreads: [
        {
          id: 's1',
          pageNumber: 3,
          layout: 'single',
          photos: [defaultPhotos[0]],
          caption: 'The gilded pavilion stood motionless on the water, its reflection trembling only when a carp broke.'
        },
        {
          id: 's2',
          pageNumber: 4,
          layout: 'double',
          photos: [defaultPhotos[1], defaultPhotos[3]],
          caption: 'Bamboo corridors and vermilion gates — the geometry of devotion.'
        }
      ],
      photoCount: 4,
      createdAt: new Date().toISOString(),
      pageColor: '#FDFAF5',
      coverColor: '#2C2C2A',
      textColor: '#2C2C2A',
      motif: 'sakura'
    };

    setSavedBooks([seeded]);
    setCurrentBook(JSON.parse(JSON.stringify(seeded)));
    setOriginalBook(JSON.parse(JSON.stringify(seeded)));
  };

  const handleSelectBook = (bookId: string) => {
    const selected = savedBooks.find(b => b.id === bookId);
    if (selected) {
      setCurrentBook(JSON.parse(JSON.stringify(selected)));
      setOriginalBook(JSON.parse(JSON.stringify(selected)));
      setSelectedSpreadId(null);
      setEditingPhotoId(null);
      triggerToast(`Loaded: ${selected.title}`);
    }
  };

  // 2. Save active book edits to the server
  const handleSaveAll = async () => {
    if (!currentBook) return;
    setIsSaving(true);
    try {
      const res = await fetch("/api/books", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(currentBook)
      });
      if (res.ok) {
        triggerToast("All changes saved successfully ✓");
        await fetchBooks(false);
      } else {
        triggerToast("Failed to save draft to database.");
      }
    } catch (err) {
      console.error("Save error:", err);
      triggerToast("Network error occurred during save.");
    } finally {
      setIsSaving(false);
    }
  };

  // 3. Discard local changes and reset
  const handleDiscardChanges = () => {
    if (originalBook) {
      setCurrentBook(JSON.parse(JSON.stringify(originalBook)));
      setSelectedSpreadId(null);
      setEditingPhotoId(null);
      triggerToast("Changes discarded");
    }
  };

  // Helper properties modifier
  const updateBookProp = (key: keyof MemoirBook, val: any) => {
    if (!currentBook) return;
    setCurrentBook({
      ...currentBook,
      [key]: val
    });
  };

  // Live presets for colors
  const applyColorPreset = (page: string, cover: string, text: string, accent: string) => {
    if (!currentBook) return;
    setCurrentBook({
      ...currentBook,
      pageColor: page,
      coverColor: cover,
      textColor: text,
      motif: currentBook.motif // retain motif
    });
    triggerToast("Preset tone applied");
  };

  // Opening Narrative Rewrites Mocking
  const rewriteTone = (tone: 'poetic' | 'journalistic' | 'intimate') => {
    if (!currentBook) return;
    const narratives = {
      poetic: 'There is a particular quality to autumn light in Kyoto — the way it filters through maples, gilding the stone lanterns and still-water reflections at Kinkaku-ji. This book is a quiet record of those eleven days: temples half-hidden in mist, side streets that smelled of toasted sesame, and the low hum of a city that carries centuries in its posture.',
      journalistic: 'Kyoto in November: eleven days across the Kansai region\'s cultural capital. This book documents visits to major temple complexes, traditional tea houses, and the Fushimi Inari trail. Photographed across early mornings and late afternoons when light conditions were optimal.',
      intimate: 'I keep coming back to the smell of that coffee in Gion — roasted dark, served in a ceramic cup that warmed both hands. Kyoto does that. It finds the small things and makes them the things you remember. This book is full of those moments. Maybe you\'ll find yours in here too.'
    };
    updateBookProp("openingNarrative", narratives[tone]);
    triggerToast(`Narrative rewritten (${tone})`);
  };

  // Extract all unique photos currently used or present in mock lists
  const getPhotoPool = (): Photo[] => {
    if (!currentBook) return [];
    // Accumulate all photos from active spreads
    const poolMap = new Map<string, Photo>();
    currentBook.spreads.forEach(s => {
      s.photos.forEach(p => {
        poolMap.set(p.id, p);
      });
    });
    return Array.from(poolMap.values());
  };

  // SPREADS CONTROLS
  const handleAddSpread = () => {
    if (!currentBook) return;
    const pool = getPhotoPool();
    const fallbackPhoto = pool[0] || {
      id: `photo-${Date.now()}`,
      url: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=800',
      title: 'New Snapshot',
      location: 'Charming Spot',
      category: 'travel',
      aspectRatio: 'landscape',
      timestamp: new Date().toISOString()
    };
    
    const newSpread: BookSpread = {
      id: `spread-${Date.now()}`,
      pageNumber: currentBook.spreads.length + 3,
      layout: 'single',
      photos: [JSON.parse(JSON.stringify(fallbackPhoto))],
      caption: 'A fresh story chapter bound in silent ink.'
    };

    const nextSpreads = [...currentBook.spreads, newSpread];
    setCurrentBook({
      ...currentBook,
      spreads: nextSpreads,
      photoCount: nextSpreads.reduce((sum, s) => sum + s.photos.length, 0)
    });
    setSelectedSpreadId(newSpread.id);
    triggerToast("Spread added");
  };

  const handleDeleteSpread = (spreadId: string) => {
    if (!currentBook) return;
    const nextSpreads = currentBook.spreads
      .filter(s => s.id !== spreadId)
      .map((s, idx) => ({
        ...s,
        pageNumber: idx + 3
      }));

    setCurrentBook({
      ...currentBook,
      spreads: nextSpreads,
      photoCount: nextSpreads.reduce((sum, s) => sum + s.photos.length, 0)
    });
    if (selectedSpreadId === spreadId) {
      setSelectedSpreadId(null);
    }
    triggerToast("Spread deleted");
  };

  const handleMoveSpread = (idx: number, direction: 'up' | 'down') => {
    if (!currentBook) return;
    const spreads = [...currentBook.spreads];
    const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= spreads.length) return;

    // Swap index
    const temp = spreads[idx];
    spreads[idx] = spreads[targetIdx];
    spreads[targetIdx] = temp;

    const renumbered = spreads.map((s, i) => ({
      ...s,
      pageNumber: i + 3
    }));

    updateBookProp("spreads", renumbered);
    triggerToast("Spread reordered");
  };

  // Specific spread item edits
  const handleUpdateSpreadLayout = (spreadId: string, layout: 'single' | 'double' | 'split-vertical' | 'narrative-only') => {
    if (!currentBook) return;
    const nextSpreads = currentBook.spreads.map(s => {
      if (s.id === spreadId) {
        let photos = [...s.photos];
        if (layout === 'narrative-only') {
          photos = [];
        } else if (layout === 'single' && photos.length > 1) {
          photos = [photos[0]];
        } else if (layout !== 'single' && photos.length === 1) {
          // duplicate photo as placeholder or find another unplaced
          const pool = getPhotoPool().filter(ph => ph.id !== photos[0].id);
          if (pool.length > 0) {
            photos.push(JSON.parse(JSON.stringify(pool[0])));
          } else {
            photos.push(JSON.parse(JSON.stringify(photos[0])));
          }
        } else if (photos.length === 0 && (layout as string) !== 'narrative-only') {
          const pool = getPhotoPool();
          if (pool.length > 0) {
            photos = [JSON.parse(JSON.stringify(pool[0]))];
          }
        }
        return { ...s, layout, photos };
      }
      return s;
    });
    updateBookProp("spreads", nextSpreads);
  };

  const handleUpdateSpreadCaption = (spreadId: string, caption: string) => {
    if (!currentBook) return;
    const nextSpreads = currentBook.spreads.map(s => {
      if (s.id === spreadId) return { ...s, caption };
      return s;
    });
    updateBookProp("spreads", nextSpreads);
  };

  const swapSpreadPhoto = (spreadId: string, photoIdx: number) => {
    if (!currentBook) return;
    const activePhotos = getPhotoPool();
    const currentSpread = currentBook.spreads.find(s => s.id === spreadId);
    if (!currentSpread) return;

    const activePhotoIds = new Set(currentSpread.photos.map(p => p.id));
    const available = activePhotos.filter(p => !activePhotoIds.has(p.id));

    if (available.length === 0) {
      triggerToast("No other photos in storage pool to swap to.");
      return;
    }

    // Pick random available
    const next = available[Math.floor(Math.random() * available.length)];
    const nextSpreads = currentBook.spreads.map(s => {
      if (s.id === spreadId) {
        const nextPhotos = [...s.photos];
        nextPhotos[photoIdx] = JSON.parse(JSON.stringify(next));
        return { ...s, photos: nextPhotos };
      }
      return s;
    });
    updateBookProp("spreads", nextSpreads);
    triggerToast("Photo swapped from pool");
  };

  const removeSpreadPhoto = (spreadId: string, photoIdx: number) => {
    if (!currentBook) return;
    const currentSpread = currentBook.spreads.find(s => s.id === spreadId);
    if (!currentSpread) return;

    const nextSpreads = currentBook.spreads.map(s => {
      if (s.id === spreadId) {
        const nextPhotos = s.photos.filter((_, i) => i !== photoIdx);
        return {
          ...s,
          photos: nextPhotos,
          layout: nextPhotos.length === 0 ? 'narrative-only' as const : 'single' as const
        };
      }
      return s;
    });
    setCurrentBook({
      ...currentBook,
      spreads: nextSpreads,
      photoCount: nextSpreads.reduce((sum, s) => sum + s.photos.length, 0)
    });
    triggerToast("Photo unplaced from spread");
  };

  const handleAddPhotoToSpread = (spreadId: string, ph: Photo) => {
    if (!currentBook) return;
    const nextSpreads = currentBook.spreads.map(s => {
      if (s.id === spreadId) {
        if (s.photos.some(p => p.id === ph.id)) return s;
        const nextPhotos = [...s.photos, JSON.parse(JSON.stringify(ph))];
        return {
          ...s,
          photos: nextPhotos,
          layout: nextPhotos.length > 1 ? 'double' as const : s.layout
        };
      }
      return s;
    });
    setCurrentBook({
      ...currentBook,
      spreads: nextSpreads,
      photoCount: nextSpreads.reduce((sum, s) => sum + s.photos.length, 0)
    });
    triggerToast("Photo set on spread");
  };

  // PHOTO POOL OPERATIONS
  const handleSelectEditPhoto = (ph: Photo) => {
    setEditingPhotoId(ph.id);
    setPhotoEditForm({
      url: ph.url,
      title: ph.title || "",
      location: ph.location || "",
      category: ph.category,
      aspectRatio: ph.aspectRatio
    });
  };

  const handleSavePhotoForm = () => {
    if (!currentBook || !editingPhotoId) return;
    
    // Propagate changes to every occurrence in the spreads
    const nextSpreads = currentBook.spreads.map(s => {
      const nextPhotos = s.photos.map(p => {
        if (p.id === editingPhotoId) {
          return {
            ...p,
            url: photoEditForm.url,
            title: photoEditForm.title,
            location: photoEditForm.location,
            category: photoEditForm.category,
            aspectRatio: photoEditForm.aspectRatio
          };
        }
        return p;
      });
      return { ...s, photos: nextPhotos };
    });

    setCurrentBook({
      ...currentBook,
      spreads: nextSpreads,
      coverPhotoUrl: currentBook.coverPhotoUrl === editingPhotoId ? photoEditForm.url : currentBook.coverPhotoUrl
    });
    setEditingPhotoId(null);
    triggerToast("Photo characteristics saved locally");
  };

  const handleDeletePhotoFromPool = (photoId: string) => {
    if (!currentBook) return;
    if (!confirm("Are you sure you want to remove this photo and unbind it from all physical pages?")) return;

    // Filter it out of every single spread
    const nextSpreads = currentBook.spreads.map(s => {
      const nextPhotos = s.photos.filter(p => p.id !== photoId);
      return {
        ...s,
        photos: nextPhotos,
        layout: nextPhotos.length === 0 
          ? 'narrative-only' as const 
          : (nextPhotos.length === 1 ? 'single' as const : s.layout)
      };
    });

    setCurrentBook({
      ...currentBook,
      spreads: nextSpreads,
      photoCount: nextSpreads.reduce((sum, s) => sum + s.photos.length, 0)
    });
    setEditingPhotoId(null);
    triggerToast("Photo removed from collection");
  };

  const handleAddNewPhotoToPool = () => {
    if (!currentBook) return;
    const url = prompt("Paste your custom Photo high-resolution URL:");
    if (!url) return;

    const newId = `custom-photo-${Date.now()}`;
    const newPh: Photo = {
      id: newId,
      url: url,
      title: "New Snap",
      timestamp: new Date().toISOString(),
      location: "Foliar Memory Spot",
      category: "custom",
      aspectRatio: "landscape"
    };

    // To add it to the pool, we put it into a new single spread so it enters the document flow!
    const newSpread: BookSpread = {
      id: `spread-ph-${Date.now()}`,
      pageNumber: currentBook.spreads.length + 3,
      layout: 'single',
      photos: [newPh],
      caption: 'Capturing details newly introduced.'
    };
    
    const nextSpreads = [...currentBook.spreads, newSpread];
    setCurrentBook({
      ...currentBook,
      spreads: nextSpreads,
      photoCount: nextSpreads.reduce((sum, s) => sum + s.photos.length, 0)
    });
    triggerToast("Custom photo added via new story leaf!");
  };

  const copyJsonToClipboard = () => {
    if (!currentBook) return;
    const raw = JSON.stringify(currentBook, null, 2);
    navigator.clipboard.writeText(raw);
    triggerToast("JSON copied to clipboard!");
  };

  if (!currentBook) {
    return (
      <div className="min-h-screen bg-neutral-900 text-neutral-300 flex flex-col items-center justify-center p-6">
        <RefreshCw className="w-10 h-10 text-stone-500 animate-spin mb-3" />
        <p className="font-serif italic text-sm">Seeding Memoir systems...</p>
      </div>
    );
  }

  const pool = getPhotoPool();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[250px_1fr] grid-rows-[56px_1fr] h-screen bg-slate-50 text-slate-900 border-t border-slate-200 shadow-inner">
      
      {/* 1. TOPBAR */}
      <div className="col-span-1 lg:col-span-2 flex items-center justify-between px-6 bg-white border-b border-slate-200 h-[56px] select-none shadow-xs">
        <div className="flex items-center space-x-3">
          <BookOpen className="w-5 h-5 text-stone-800" />
          <span className="font-serif text-base font-bold tracking-tight text-stone-900">Memoir — admin</span>
          <span className="bg-stone-100 text-stone-700 font-mono text-[10px] px-2.5 py-0.5 rounded border border-stone-200">
            {currentBook.id}
          </span>
        </div>

        {/* Saved Draft Selector Dropdown */}
        <div className="flex items-center space-x-4">
          <div className="hidden sm:flex items-center space-x-2">
            <span className="font-mono text-[9px] text-zinc-400 uppercase">Load Album:</span>
            <select
              value={currentBook.id}
              onChange={(e) => handleSelectBook(e.target.value)}
              className="text-xs font-serif bg-slate-50 border border-slate-300 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-stone-800 focus:border-stone-850"
            >
              {savedBooks.map(b => (
                <option key={b.id} value={b.id}>{b.title} ({b.spreads.length} spreads)</option>
              ))}
            </select>
          </div>

          <div className="flex items-center space-x-2">
            <button 
              onClick={handleDiscardChanges}
              className="flex items-center gap-1.5 bg-slate-50 text-slate-700 border border-slate-300 font-sans text-xs px-3 py-1.5 hover:bg-slate-100 rounded cursor-pointer transition-all active:scale-95"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Discard</span>
            </button>
            <button 
              onClick={handleSaveAll}
              disabled={isSaving}
              className="flex items-center gap-1.5 bg-stone-900 text-cream-50 border border-stone-900 font-sans text-xs font-semibold px-4 py-1.5 hover:bg-stone-800 rounded shadow cursor-pointer transition-all active:scale-95 disabled:opacity-50"
            >
              {isSaving ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
              <span>Save changes</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. SIDEBAR */}
      <nav className="bg-white border-r border-slate-200 overflow-y-auto py-5 px-3 space-y-6 flex flex-col justify-between select-none">
        <div className="space-y-6">
          <div>
            <div className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest px-2.5 mb-2">Book structure</div>
            <div className="space-y-1">
              <button 
                onClick={() => setActivePanel('overview')}
                className={`w-full flex items-center space-x-2.5 py-2 px-3 rounded text-xs text-left transition-all ${activePanel === 'overview' ? 'bg-slate-100 font-medium text-stone-900' : 'text-slate-600 hover:bg-slate-50'}`}
              >
                <Sliders className="w-4 h-4 text-slate-500" />
                <span>Overview &amp; Preview</span>
              </button>
              <button 
                onClick={() => setActivePanel('cover')}
                className={`w-full flex items-center space-x-2.5 py-2 px-3 rounded text-xs text-left transition-all ${activePanel === 'cover' ? 'bg-slate-100 font-medium text-stone-900' : 'text-slate-600 hover:bg-slate-50'}`}
              >
                <ImageIcon className="w-4 h-4 text-slate-500" />
                <span>Cover &amp; Title</span>
              </button>
              <button 
                onClick={() => setActivePanel('narrative')}
                className={`w-full flex items-center space-x-2.5 py-2 px-3 rounded text-xs text-left transition-all ${activePanel === 'narrative' ? 'bg-slate-100 font-medium text-stone-900' : 'text-slate-600 hover:bg-slate-50'}`}
              >
                <AlignLeft className="w-4 h-4 text-slate-500" />
                <span>Opening Narrative</span>
              </button>
            </div>
          </div>

          <div>
            <div className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest px-2.5 mb-2">Content</div>
            <div className="space-y-1">
              <button 
                onClick={() => setActivePanel('spreads')}
                className={`w-full flex items-center justify-between py-2 px-3 rounded text-xs text-left transition-all ${activePanel === 'spreads' ? 'bg-slate-100 font-medium text-stone-900' : 'text-slate-600 hover:bg-slate-50'}`}
              >
                <div className="flex items-center space-x-2.5">
                  <Layout className="w-4 h-4 text-slate-500" />
                  <span>Spreads editor</span>
                </div>
                <span className="bg-stone-150 text-stone-700 text-[10px] font-semibold px-2 py-0.5 rounded-full">
                  {currentBook.spreads.length}
                </span>
              </button>
              <button 
                onClick={() => setActivePanel('photos')}
                className={`w-full flex items-center justify-between py-2 px-3 rounded text-xs text-left transition-all ${activePanel === 'photos' ? 'bg-slate-100 font-medium text-stone-900' : 'text-slate-600 hover:bg-slate-50'}`}
              >
                <div className="flex items-center space-x-2.5">
                  <Camera className="w-4 h-4 text-slate-500" />
                  <span>Photo pool archive</span>
                </div>
                <span className="bg-stone-150 text-stone-700 text-[10px] font-semibold px-2 py-0.5 rounded-full font-mono">
                  {pool.length}
                </span>
              </button>
            </div>
          </div>

          <div>
            <div className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest px-2.5 mb-2">Acoustic motifs</div>
            <div className="space-y-1">
              <button 
                onClick={() => setActivePanel('design')}
                className={`w-full flex items-center space-x-2.5 py-2 px-3 rounded text-xs text-left transition-all ${activePanel === 'design' ? 'bg-slate-100 font-medium text-stone-900' : 'text-slate-600 hover:bg-slate-50'}`}
              >
                <Palette className="w-4 h-4 text-slate-500" />
                <span>Colors &amp; Fonts</span>
              </button>
              <button 
                onClick={() => setActivePanel('backgrounds')}
                className={`w-full flex items-center space-x-2.5 py-2 px-3 rounded text-xs text-left transition-all ${activePanel === 'backgrounds' ? 'bg-slate-100 font-medium text-stone-900' : 'text-slate-600 hover:bg-slate-50'}`}
              >
                <Sparkles className="w-4 h-4 text-slate-500" />
                <span>Page Background</span>
              </button>
            </div>
          </div>

          <div>
            <div className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest px-2.5 mb-2">Settings</div>
            <div className="space-y-1">
              <button 
                onClick={() => setActivePanel('metadata')}
                className={`w-full flex items-center space-x-2.5 py-2 px-3 rounded text-xs text-left transition-all ${activePanel === 'metadata' ? 'bg-slate-100 font-medium text-stone-900' : 'text-slate-600 hover:bg-slate-50'}`}
              >
                <Info className="w-4 h-4 text-slate-500" />
                <span>Metadata / JSON Export</span>
              </button>
            </div>
          </div>
        </div>

        {/* Small Back to App link */}
        <div className="pt-4 border-t border-slate-100">
          <a 
            href="/" 
            className="flex items-center space-x-2 text-stone-550 hover:text-stone-900 text-xs py-1.5 px-3 rounded transition-all font-serif italic"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>← Exit Admin Panel</span>
          </a>
        </div>
      </nav>

      {/* 3. MAIN CONTENT FRAME */}
      <main className="overflow-y-auto p-8 bg-slate-50/50">
        
        {/* PANEL: OVERVIEW */}
        {activePanel === 'overview' && (
          <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-serif font-semibold tracking-tight text-stone-900">Overview</h2>
              <button 
                onClick={() => setActivePanel('spreads')}
                className="flex items-center space-x-1 text-xs text-stone-900 hover:underline"
              >
                <span>Edit spreads</span>
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Stats list */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white border border-slate-200 rounded p-4 shadow-3xs">
                <div className="text-zinc-400 text-[10px] font-mono uppercase tracking-wider mb-1">Spreads</div>
                <div className="text-2xl font-semibold text-stone-900 font-sans">{currentBook.spreads.length}</div>
              </div>
              <div className="bg-white border border-slate-200 rounded p-4 shadow-3xs">
                <div className="text-zinc-400 text-[10px] font-mono uppercase tracking-wider mb-1">Photos</div>
                <div className="text-2xl font-semibold text-stone-900 font-sans">{pool.length}</div>
              </div>
              <div className="bg-white border border-slate-200 rounded p-4 shadow-3xs">
                <div className="text-zinc-400 text-[10px] font-mono uppercase tracking-wider mb-1">Style Format</div>
                <div className="text-sm font-semibold text-stone-800 uppercase mt-2.5 tracking-wider">{currentBook.style}</div>
              </div>
              <div className="bg-white border border-slate-200 rounded p-4 shadow-3xs">
                <div className="text-zinc-400 text-[10px] font-mono uppercase tracking-wider mb-1">Motif Motif</div>
                <div className="text-sm font-semibold text-stone-800 uppercase mt-2.5 tracking-wider">{currentBook.motif || "Clean"}</div>
              </div>
            </div>

            {/* Simulated Live cover preview */}
            <div className="bg-white border border-slate-200 rounded p-6 shadow-2xs space-y-4">
              <div className="text-[10px] font-mono text-zinc-50h font-semibold uppercase tracking-wider flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-stone-700" />
                <span>Live Book Cover Preview</span>
              </div>
              <div className="relative aspect-[3/2] md:aspect-[4/2] w-full rounded overflow-hidden shadow-md bg-stone-300">
                <div 
                  className="absolute inset-0 bg-cover bg-center transition-all duration-300" 
                  style={{ backgroundImage: `url(${currentBook.coverPhotoUrl || pool[0]?.url})` }}
                />
                <div className="absolute inset-0 bg-black/45 backdrop-brightness-75 transition-all" />
                
                <div className="absolute bottom-6 left-6 right-6 text-white space-y-2 z-10">
                  <h1 className="font-serif text-3xl md:text-4xl font-bold tracking-tight text-white drop-shadow-sm">
                    {currentBook.title || "Untitled Album"}
                  </h1>
                  <p className="font-serif italic text-sm text-cream-100 opacity-90 drop-shadow-xs truncate max-w-xl">
                    {currentBook.subtitle || "A quiet curation story."}
                  </p>
                </div>
              </div>
            </div>

            {/* Opening Narrative card */}
            <div className="bg-white border border-slate-200 rounded p-6 shadow-2xs space-y-3">
              <div className="text-[10px] font-mono text-zinc-400 uppercase tracking-widest leading-none">Opening Preface (Page 2)</div>
              <p className="font-serif text-slate-700 text-sm leading-relaxed whitespace-pre-line italic">
                "{currentBook.openingNarrative}"
              </p>
            </div>
          </div>
        )}

        {/* PANEL: COVER & TITLE */}
        {activePanel === 'cover' && (
          <div className="max-w-xl mx-auto space-y-6 animate-fadeIn">
            <h2 className="text-xl font-serif font-semibold tracking-tight text-stone-900">Cover & Title</h2>

            <div className="bg-white border border-slate-200 rounded p-6 shadow-2xs space-y-4">
              <h3 className="font-serif text-sm font-semibold text-stone-850 border-b pb-2">Book cover titles</h3>
              
              <div className="space-y-4">
                <div className="flex flex-col gap-1.5">
                  <label className="font-mono text-[9px] text-zinc-500 uppercase tracking-wider">Book Title</label>
                  <input 
                    type="text" 
                    value={currentBook.title}
                    onChange={(e) => updateBookProp("title", e.target.value)}
                    className="w-full text-sm p-2.5 border border-slate-300 rounded focus:ring-1 focus:ring-stone-800 outline-none"
                  />
                </div>
                
                <div className="flex flex-col gap-1.5">
                  <label className="font-mono text-[9px] text-zinc-500 uppercase tracking-wider">Book Subtitle</label>
                  <input 
                    type="text" 
                    value={currentBook.subtitle}
                    onChange={(e) => updateBookProp("subtitle", e.target.value)}
                    className="w-full text-xs p-2.5 border border-slate-300 rounded focus:ring-1 focus:ring-stone-800 outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded p-6 shadow-2xs space-y-4">
              <h3 className="font-serif text-sm font-semibold text-stone-850 border-b pb-2">Cover photo layout</h3>
              
              <div className="flex flex-col md:flex-row gap-4 items-start">
                <div className="w-40 h-28 border border-slate-200 rounded overflow-hidden shrink-0 shadow-xs bg-stone-100">
                  <img 
                    src={currentBook.coverPhotoUrl} 
                    className="w-full h-full object-cover" 
                    alt="Cover preview" 
                  />
                </div>
                <div className="flex-1 w-full space-y-3">
                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[9px] text-zinc-500 uppercase tracking-wider">Cover Image URL</label>
                    <input 
                      type="text" 
                      value={currentBook.coverPhotoUrl}
                      onChange={(e) => updateBookProp("coverPhotoUrl", e.target.value)}
                      className="w-full text-xs p-2.5 border border-slate-300 rounded focus:ring-1 focus:ring-stone-800 outline-none"
                    />
                  </div>
                  
                  {/* Preset photo click links */}
                  <div className="space-y-1">
                    <div className="text-[8px] font-mono text-zinc-400 uppercase tracking-widest">Quick swap presets</div>
                    <div className="flex flex-wrap gap-2 pt-1">
                      {pool.slice(0, 4).map((p, idx) => (
                        <button
                          key={p.id}
                          onClick={() => updateBookProp("coverPhotoUrl", p.url)}
                          className="bg-slate-100 text-slate-800 border border-slate-300 hover:bg-slate-200 text-[10px] px-2 py-1 rounded cursor-pointer"
                        >
                          Preset #{idx+1} ({p.title || 'Inari'})
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded p-6 shadow-2xs space-y-3">
              <h3 className="font-serif text-sm font-semibold text-stone-850 border-b pb-2">Outer style preset</h3>
              <div className="flex gap-2">
                {['moleskine', 'classic', 'journal'].map((st) => (
                  <button
                    key={st}
                    onClick={() => {
                      updateBookProp("style", st);
                      triggerToast(`Cover layout configured to ${st}`);
                    }}
                    className={`flex-1 py-1.5 px-3 text-xs border rounded capitalize font-medium transition-all cursor-pointer ${currentBook.style === st ? 'bg-stone-900 border-stone-900 text-white shadow-xs' : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'}`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* PANEL: OPENING NARRATIVE */}
        {activePanel === 'narrative' && (
          <div className="max-w-xl mx-auto space-y-6 animate-fadeIn">
            <h2 className="text-xl font-serif font-semibold tracking-tight text-stone-900">Opening Narrative Preface</h2>

            <div className="bg-white border border-slate-200 rounded p-6 shadow-2xs space-y-4">
              <div className="flex items-center justify-between border-b pb-2">
                <span className="font-serif text-sm font-semibold text-stone-850">Preface custom story text</span>
                <span className="font-sans text-[10px] text-zinc-400">
                  {currentBook.openingNarrative?.split(" ").filter(Boolean).length || 0} words
                </span>
              </div>

              <textarea
                value={currentBook.openingNarrative}
                onChange={(e) => updateBookProp("openingNarrative", e.target.value)}
                className="w-full h-44 text-xs font-serif leading-relaxed p-3 border border-slate-350 rounded focus:ring-1 focus:ring-stone-900 focus:outline-none"
              />

              <div className="space-y-2">
                <div className="font-mono text-[9px] text-zinc-400 uppercase tracking-widest flex items-center space-x-1">
                  <Sparkles className="w-3.5 h-3.5 text-stone-700" />
                  <span>✦ AI Literary Rewrite Assistants</span>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => rewriteTone('poetic')}
                    className="flex-1 bg-slate-50 hover:bg-slate-100 border text-slate-700 text-xs px-2.5 py-1.5 rounded transition-all cursor-pointer font-serif italic"
                  >
                    ✦ Poetic Margins
                  </button>
                  <button 
                    onClick={() => rewriteTone('journalistic')}
                    className="flex-1 bg-slate-50 hover:bg-slate-100 border text-slate-700 text-xs px-2.5 py-1.5 rounded transition-all cursor-pointer"
                  >
                    ✦ Journalistic Log
                  </button>
                  <button 
                    onClick={() => rewriteTone('intimate')}
                    className="flex-1 bg-slate-50 hover:bg-slate-100 border text-slate-700 text-xs px-2.5 py-1.5 rounded transition-all cursor-pointer font-serif italic"
                  >
                    ✦ Cozy Companion
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* PANEL: SPREADS */}
        {activePanel === 'spreads' && (
          <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-serif font-semibold tracking-tight text-stone-900 flex items-center gap-2">
                <span>Spreads Collection</span>
                <span className="bg-stone-200 text-stone-800 text-[10px] px-2.5 py-0.5 rounded-full font-mono">
                  {currentBook.spreads.length} Units
                </span>
              </h2>

              <button
                onClick={handleAddSpread}
                className="flex items-center space-x-1.5 bg-stone-900 border border-stone-900 text-cream-50 font-sans text-xs font-semibold px-3.5 py-2 hover:bg-stone-800 rounded shadow-xs cursor-pointer transition-all active:scale-95"
              >
                <Plus className="w-4 h-4 text-cream-400" />
                <span>Add sheet spread</span>
              </button>
            </div>

            <div className="grid lg:grid-cols-[1fr_320px] gap-6 items-start">
              
              {/* SPREADS LIST COLUMN */}
              <div className="space-y-4">
                {currentBook.spreads.length === 0 ? (
                  <div className="text-center bg-white border border-dashed p-10 rounded">
                    <Layout className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <p className="font-serif italic text-slate-500 text-xs">No active page sheets. Click "Add sheet spread" to initialize one.</p>
                  </div>
                ) : (
                  currentBook.spreads.map((sp, idx) => {
                    const isSelected = selectedSpreadId === sp.id;
                    return (
                      <div 
                        key={sp.id} 
                        onClick={() => setSelectedSpreadId(sp.id)}
                        className={`bg-white border p-4 rounded flex items-center gap-4 cursor-pointer hover:border-slate-400 transition-all ${isSelected ? 'border-stone-800 shadow-sm ring-1 ring-stone-805' : 'border-slate-200'}`}
                      >
                        {/* Drag indicator/up-down arrows */}
                        <div className="flex flex-col items-center gap-1 shrink-0" onClick={e => e.stopPropagation()}>
                          <button 
                            disabled={idx === 0}
                            onClick={() => handleMoveSpread(idx, 'up')}
                            className="p-1 rounded bg-slate-50 text-slate-500 hover:bg-slate-150 disabled:opacity-30 cursor-pointer"
                          >
                            <ArrowUp className="w-3 h-3" />
                          </button>
                          <span className="font-mono text-[9px] text-zinc-400">P.{sp.pageNumber}</span>
                          <button 
                            disabled={idx === currentBook.spreads.length - 1}
                            onClick={() => handleMoveSpread(idx, 'down')}
                            className="p-1 rounded bg-slate-50 text-slate-500 hover:bg-slate-150 disabled:opacity-30 cursor-pointer"
                          >
                            <ArrowDown className="w-3 h-3" />
                          </button>
                        </div>

                        {/* Thumbnail represent */}
                        <div className="w-20 h-14 bg-slate-100 border border-slate-200 rounded overflow-hidden flex-shrink-0 flex items-center justify-center">
                          {sp.photos[0] ? (
                            <img src={sp.photos[0].url} className="w-full h-full object-cover" alt="" />
                          ) : (
                            <AlignLeft className="w-4 h-4 text-slate-400" />
                          )}
                        </div>

                        {/* Middle textual detail */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2">
                            <span className="font-sans text-[10px] bg-slate-100 text-slate-700 capitalize px-2 py-0.5 rounded leading-none">
                              {sp.layout}
                            </span>
                          </div>
                          <p className="font-serif text-xs text-slate-800 mt-1.5 truncate italic">
                            "{sp.caption || 'No caption'}"
                          </p>
                        </div>

                        {/* Action buttons */}
                        <div className="flex space-x-1 shrink-0" onClick={e => e.stopPropagation()}>
                          <button 
                            onClick={() => setSelectedSpreadId(isSelected ? null : sp.id)}
                            className="p-1.5 border border-slate-200 text-slate-600 hover:bg-slate-100 hover:border-slate-300 rounded cursor-pointer"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button 
                            onClick={() => handleDeleteSpread(sp.id)}
                            className="p-1.5 border border-slate-200 text-rose-600 hover:bg-rose-50 hover:border-rose-200 rounded cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* SPREADS EDITOR SPECIFIC CHIPS PANEL */}
              <div className="space-y-4">
                {selectedSpreadId ? (
                  (() => {
                    const activeSp = currentBook.spreads.find(s => s.id === selectedSpreadId);
                    if (!activeSp) return null;
                    return (
                      <div className="bg-white border border-slate-200 rounded p-5 shadow-2xs space-y-4 animate-scaleUp">
                        <div className="flex justify-between items-center border-b pb-2">
                          <h3 className="font-serif text-xs font-bold text-stone-900">Editing Leaf P.{activeSp.pageNumber}</h3>
                          <button onClick={() => setSelectedSpreadId(null)} className="text-zinc-400 hover:text-stone-800 cursor-pointer">
                            <X className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Caption input */}
                        <div className="flex flex-col gap-1.5">
                          <label className="font-mono text-[9px] text-zinc-500 uppercase tracking-wider">Spread Narrative Caption</label>
                          <input 
                            type="text"
                            value={activeSp.caption}
                            onChange={(e) => handleUpdateSpreadCaption(activeSp.id, e.target.value)}
                            className="text-xs p-2.5 border border-slate-300 rounded outline-none font-serif italic"
                            placeholder="An autumn leaf, drifting..."
                          />
                        </div>

                        {/* Layout chooser pills */}
                        <div className="space-y-1.5">
                          <div className="font-mono text-[9px] text-zinc-500 uppercase tracking-wider">Page Frame Layout</div>
                          <div className="grid grid-cols-2 gap-1.5">
                            {['single', 'double', 'split-vertical', 'narrative-only'].map((l) => (
                              <button
                                key={l}
                                onClick={() => handleUpdateSpreadLayout(activeSp.id, l as any)}
                                className={`py-1 border rounded font-mono text-[9px] uppercase cursor-pointer ${activeSp.layout === l ? 'bg-stone-900 border-stone-900 text-white' : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-250'}`}
                              >
                                {l.replace("-", " ")}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Images placed */}
                        <div className="space-y-2">
                          <div className="flex justify-between items-center text-zinc-500 font-mono text-[9px] uppercase tracking-wider">
                            <span>Photos placed ({activeSp.photos.length})</span>
                            <button
                              onClick={() => setAddingPhotoSpreadId(addingPhotoSpreadId === activeSp.id ? null : activeSp.id)}
                              className="text-[9.5px] font-mono text-stone-800 hover:underline flex items-center gap-0.5 cursor-pointer leading-none"
                            >
                              <Plus className="w-3 h-3" />
                              <span>{addingPhotoSpreadId === activeSp.id ? "Minimize" : "Place photo"}</span>
                            </button>
                          </div>

                          {activeSp.photos.length === 0 ? (
                            <div className="text-center py-4 border border-dashed border-slate-205 rounded text-[11px] italic text-zinc-400 font-serif">
                              No photos bound. Use placing panel.
                            </div>
                          ) : (
                            <div className="space-y-2">
                              {activeSp.photos.map((ph, phIdx) => (
                                <div key={ph.id} className="flex items-center justify-between bg-slate-50 p-2 border border-slate-200 rounded">
                                  <div className="flex items-center space-x-2 overflow-hidden">
                                    <img src={ph.url} className="w-8 h-8 object-cover rounded shadow-4xs border" alt="" />
                                    <span className="font-serif text-[10.5px] truncate max-w-[110px] font-semibold text-slate-800">{ph.title || "Untitled"}</span>
                                  </div>

                                  {/* Actions swap and delete */}
                                  <div className="flex items-center space-x-1 shrink-0">
                                    <button 
                                      onClick={() => swapSpreadPhoto(activeSp.id, phIdx)}
                                      className="p-1 text-slate-400 hover:text-stone-800 rounded hover:bg-slate-100" 
                                      title="Swap image with random pool"
                                    >
                                      <RefreshCw className="w-3.5 h-3.5" />
                                    </button>
                                    <button 
                                      onClick={() => removeSpreadPhoto(activeSp.id, phIdx)}
                                      className="p-1 text-slate-400 hover:text-rose-700 rounded hover:bg-rose-50"
                                      title="Remove from sheet"
                                    >
                                      <X className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}

                          {/* Quick Add photo selection tray */}
                          {addingPhotoSpreadId === activeSp.id && (
                            <div className="p-3 bg-slate-50 border border-slate-200 rounded space-y-2 animate-fadeIn max-h-[140px] overflow-y-auto">
                              <div className="text-[8px] font-mono uppercase tracking-widest text-zinc-400 block font-bold">Select target to place:</div>
                              <div className="grid grid-cols-4 gap-1.5">
                                {pool.map(pItem => (
                                  <div 
                                    key={pItem.id}
                                    onClick={() => handleAddPhotoToSpread(activeSp.id, pItem)}
                                    className="relative aspect-square border border-slate-300 rounded overflow-hidden cursor-pointer hover:scale-102 transition-all shadow-4xs"
                                  >
                                    <img src={pItem.url} className="w-full h-full object-cover" alt="" />
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })()
                ) : (
                  <div className="bg-slate-100 border border-dashed border-slate-300 p-6 rounded text-center">
                    <Sliders className="w-6 h-6 text-slate-400 mx-auto mb-2" />
                    <p className="font-serif text-xs text-slate-500 italic">Select a sheet spread page in the list to enable layout and narrative editor.</p>
                  </div>
                )}
              </div>

            </div>
          </div>
        )}

        {/* PANEL: PHOTO POOL ARCHIVE */}
        {activePanel === 'photos' && (
          <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-serif font-semibold tracking-tight text-stone-900">Photo Pool Storage Archive</h2>
              <button
                onClick={handleAddNewPhotoToPool}
                className="flex items-center space-x-1.5 bg-stone-900 border border-stone-900 text-cream-50 font-sans text-xs px-3.5 py-2 hover:bg-stone-800 rounded shadow-xs cursor-pointer transition-all active:scale-95"
              >
                <Plus className="w-4 h-4 text-cream-450" />
                <span>Add custom URL photo</span>
              </button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {pool.map((ph) => {
                const isSelectedForEdit = editingPhotoId === ph.id;
                return (
                  <div 
                    key={ph.id}
                    onClick={() => handleSelectEditPhoto(ph)}
                    className={`aspect-square relative rounded overflow-hidden border cursor-pointer hover:border-slate-400 transition-all shadow-4xs ${isSelectedForEdit ? 'ring-2 ring-stone-900 scale-98 border-white' : 'border-slate-205'}`}
                  >
                    <img src={ph.url} className="w-full h-full object-cover" alt={ph.title || 'snapshot'} />
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-1.5 text-left pointer-events-none">
                      <span className="text-[9px] font-sans text-white font-semibold truncate block">
                        {ph.title || ph.location || "Preserved memory"}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Editing Selected Photo Card */}
            {editingPhotoId && (
              <div className="bg-white border border-slate-200 rounded p-6 shadow-xs max-w-xl mx-auto space-y-4 animate-scaleUp">
                <div className="flex justify-between items-center border-b pb-2">
                  <h3 className="font-serif text-sm font-semibold text-stone-900">Modifying Photo Metadata</h3>
                  <button onClick={() => setEditingPhotoId(null)} className="text-zinc-500 hover:text-stone-900 cursor-pointer">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="flex flex-col md:flex-row gap-4 items-start">
                  <img src={photoEditForm.url} className="w-24 h-24 object-cover rounded shadow-xs border shrink-0" alt="" />
                  
                  <div className="flex-1 w-full space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div className="flex flex-col gap-1">
                        <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-wider">Title/Label</label>
                        <input 
                          type="text" 
                          value={photoEditForm.title}
                          onChange={e => setPhotoEditForm({ ...photoEditForm, title: e.target.value })}
                          className="text-xs p-2 border border-slate-300 rounded outline-none"
                        />
                      </div>
                      <div className="flex flex-col gap-1">
                        <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-wider">Location Stamp</label>
                        <input 
                          type="text" 
                          value={photoEditForm.location}
                          onChange={e => setPhotoEditForm({ ...photoEditForm, location: e.target.value })}
                          className="text-xs p-2 border border-slate-300 rounded outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="flex flex-col gap-1">
                        <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-wider">Category</label>
                        <select 
                          value={photoEditForm.category}
                          onChange={e => setPhotoEditForm({ ...photoEditForm, category: e.target.value as any })}
                          className="text-xs p-2 border border-slate-305 bg-slate-50 rounded outline-none"
                        >
                          <option value="travel">Travel</option>
                          <option value="cafe">Cafe/Dining</option>
                          <option value="nature">Nature</option>
                          <option value="family">Family/Friends</option>
                          <option value="custom">Custom</option>
                        </select>
                      </div>
                      <div className="flex flex-col gap-1">
                        <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-wider">Aspect Ratio</label>
                        <select 
                          value={photoEditForm.aspectRatio}
                          onChange={e => setPhotoEditForm({ ...photoEditForm, aspectRatio: e.target.value as any })}
                          className="text-xs p-2 border border-slate-305 bg-slate-50 rounded outline-none"
                        >
                          <option value="landscape">Landscape</option>
                          <option value="portrait">Portrait</option>
                          <option value="square">Square</option>
                        </select>
                      </div>
                    </div>

                    <div className="flex flex-col gap-1">
                      <label className="font-mono text-[8px] text-zinc-500 uppercase tracking-wider">High-fidelity photo URL</label>
                      <input 
                        type="text" 
                        value={photoEditForm.url}
                        onChange={e => setPhotoEditForm({ ...photoEditForm, url: e.target.value })}
                        className="text-xs p-2 border border-slate-300 rounded outline-none w-full"
                      />
                    </div>

                    <div className="flex gap-2 pt-2">
                      <button 
                        onClick={handleSavePhotoForm}
                        className="flex-1 bg-stone-900 text-cream-50 font-sans text-xs font-semibold py-2 hover:bg-stone-800 rounded shadow-xs cursor-pointer active:scale-95 transition-all text-center"
                      >
                        Save Photo Properties
                      </button>
                      <button 
                        onClick={() => handleDeletePhotoFromPool(editingPhotoId)}
                        className="bg-rose-50 text-rose-700 hover:bg-rose-100 hover:text-rose-800 border border-rose-200 text-xs px-4 py-2 rounded cursor-pointer transition-all"
                      >
                        Delete Photo
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* PANEL: COLORS & FONTS */}
        {activePanel === 'design' && (
          <div className="max-w-xl mx-auto space-y-6 animate-fadeIn">
            <h2 className="text-xl font-serif font-semibold tracking-tight text-stone-900">Colors &amp; Fonts Style</h2>

            <div className="bg-white border border-slate-200 rounded p-6 shadow-2xs space-y-4">
              <h3 className="font-serif text-sm font-semibold text-stone-850 border-b pb-2">Page &amp; Cover Cloth Colors</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col gap-1">
                  <label className="font-mono text-[9px] text-zinc-500 uppercase tracking-wider">Foliar Page Stock Color</label>
                  <div className="flex items-center space-x-2">
                    <input 
                      type="color" 
                      value={currentBook.pageColor || '#FDFAF5'}
                      onChange={e => updateBookProp("pageColor", e.target.value)}
                      className="w-10 h-10 border rounded cursor-pointer shrink-0"
                    />
                    <span className="font-mono text-xs">{currentBook.pageColor || '#FDFAF5'}</span>
                  </div>
                </div>

                <div className="flex flex-col gap-1">
                  <label className="font-mono text-[9px] text-zinc-500 uppercase tracking-wider">Cloth Cloth cover color</label>
                  <div className="flex items-center space-x-2">
                    <input 
                      type="color" 
                      value={currentBook.coverColor || '#2C2C2A'}
                      onChange={e => updateBookProp("coverColor", e.target.value)}
                      className="w-10 h-10 border rounded cursor-pointer shrink-0"
                    />
                    <span className="font-mono text-xs">{currentBook.coverColor || '#2C2C2A'}</span>
                  </div>
                </div>
              </div>

              {/* Presets color swatches */}
              <div className="space-y-1.5 pt-2">
                <div className="text-[10px] font-mono text-zinc-400 uppercase tracking-widest font-semibold">Designer Quick Presets</div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => applyColorPreset('#FDFAF5', '#2C2C2A', '#2C2C2A', '#7F77DD')}
                    className="w-6 h-6 rounded-full border border-slate-350 hover:scale-110 active:scale-95 cursor-pointer bg-[#FDFAF5]"
                    title="Parchment &amp; Charcoal"
                  />
                  <button 
                    onClick={() => applyColorPreset('#1A1A2E', '#E8E3D5', '#E8E3D5', '#AFA9EC')}
                    className="w-6 h-6 rounded-full border border-slate-350 hover:scale-110 active:scale-95 cursor-pointer bg-[#1A1A2E]"
                    title="Midnight Sapphire"
                  />
                  <button 
                    onClick={() => applyColorPreset('#F0EAE0', '#3B2F2F', '#3B2F2F', '#D85A30')}
                    className="w-6 h-6 rounded-full border border-slate-350 hover:scale-110 active:scale-95 cursor-pointer bg-[#F0EAE0]"
                    title="Terracotta Clay"
                  />
                  <button 
                    onClick={() => applyColorPreset('#E8F0E8', '#1B3020', '#1B3020', '#1D9E75')}
                    className="w-6 h-6 rounded-full border border-slate-350 hover:scale-110 active:scale-95 cursor-pointer bg-[#E8F0E8]"
                    title="Japanese Moss Forest"
                  />
                  <button 
                    onClick={() => applyColorPreset('#FFF8F0', '#2C1A08', '#2C1A08', '#BA7517')}
                    className="w-6 h-6 rounded-full border border-slate-350 hover:scale-110 active:scale-95 cursor-pointer bg-[#FFF8F0]"
                    title="Autumn Amber"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded p-6 shadow-2xs space-y-4">
              <h3 className="font-serif text-sm font-semibold text-stone-850 border-b pb-2">Typography Settings</h3>
              
              <div className="flex flex-col gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="font-mono text-[9px] text-zinc-500 uppercase tracking-wider">Title display typography</label>
                  <div className="flex flex-wrap gap-2">
                    {['serif', 'sans', 'mono'].map((fn) => (
                      <button
                        key={fn}
                        onClick={() => updateBookProp("fontTitle", fn)}
                        className={`py-1.5 px-3 text-xs border rounded capitalize cursor-pointer font-medium ${currentBook.fontTitle === fn ? 'bg-stone-900 border-stone-900 text-white shadow-3xs' : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'}`}
                      >
                        {fn === 'serif' ? 'Georgia Serif' : fn === 'sans' ? 'Inter Sans-Serif' : 'JetBrains Mono'}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="font-mono text-[9px] text-zinc-500 uppercase tracking-wider">Story body script</label>
                  <div className="flex flex-wrap gap-2">
                    {['serif', 'sans', 'mono'].map((fn) => (
                      <button
                        key={fn}
                        onClick={() => updateBookProp("fontBody", fn)}
                        className={`py-1.5 px-3 text-xs border rounded capitalize cursor-pointer font-medium ${currentBook.fontBody === fn ? 'bg-stone-900 border-stone-900 text-white shadow-3xs' : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'}`}
                      >
                        {fn === 'serif' ? 'Kinfolk Serif' : fn === 'sans' ? 'Inter Sans-Serif' : 'Courier Script'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* PANEL: BACKGROUND TEXTURE */}
        {activePanel === 'backgrounds' && (
          <div className="max-w-xl mx-auto space-y-6 animate-fadeIn">
            <h2 className="text-xl font-serif font-semibold tracking-tight text-stone-900">Background Texture</h2>

            <div className="bg-white border border-slate-200 rounded p-6 shadow-2xs space-y-4">
              <h3 className="font-serif text-sm font-semibold text-stone-850 border-b pb-2">Page Motif / Graphic overlays</h3>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {[
                  { id: 'none', label: 'Clean paper' },
                  { id: 'sakura', label: 'Kyoto Sakura 🌸' },
                  { id: 'cafe', label: 'Tokyo Cafe Study ☕' },
                  { id: 'vintage', label: 'Cine Film 🎞️' },
                  { id: 'mountain', label: 'Topography 🏔️' },
                  { id: 'botanical', label: 'Botanical Ivy 🌿' }
                ].map((th) => (
                  <button
                    key={th.id}
                    onClick={() => {
                      updateBookProp("motif", th.id);
                      triggerToast(`Graphic Motif: ${th.label}`);
                    }}
                    className={`p-3 border text-center rounded text-xs transition-all cursor-pointer ${currentBook.motif === th.id ? 'bg-stone-900 text-white border-stone-900 shadow-3xs' : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-stone-700'}`}
                  >
                    <span className="block font-medium">{th.label.split(" ")[0]}</span>
                    <span className="block text-[9px] text-zinc-400 mt-1">{th.label.split(" ")[1] || ''}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded p-4 shadow-3xs text-center space-y-2">
              <div className="font-mono text-[9px] text-zinc-550 uppercase tracking-widest leading-none">Simulated Foliar preview frame</div>
              <div 
                className="h-32 rounded border border-slate-200 flex items-center justify-center font-serif text-xs italic text-stone-600 shadow-inner"
                style={{ backgroundColor: currentBook.pageColor || '#FDFAF5' }}
              >
                {currentBook.motif === 'sakura' ? '💮 Soft Kyoto sakura stamps active' : 
                 currentBook.motif === 'cafe' ? '☕ Ring-stains paper motif borders' : 
                 currentBook.motif === 'vintage' ? '🎞️ Retro filmstrip edge marking borders' : 
                 currentBook.motif === 'mountain' ? '🏔️ Topographical altitude stamp boundaries' : 
                 '📓 Archival Clean Moleskine layout'}
              </div>
            </div>
          </div>
        )}

        {/* PANEL: METADATA & RAW DATABASE EXPORT */}
        {activePanel === 'metadata' && (
          <div className="max-w-xl mx-auto space-y-6 animate-fadeIn">
            <h2 className="text-xl font-serif font-semibold tracking-tight text-stone-900">Database Info / Raw JSON</h2>

            <div className="bg-white border border-slate-200 rounded p-6 shadow-2xs space-y-4">
              <h3 className="font-serif text-sm font-semibold text-stone-850 border-b pb-2">Technical metadata</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col gap-1">
                  <label className="font-mono text-[9px] text-zinc-400 uppercase tracking-wider">Book ID Identifier</label>
                  <input 
                    type="text" 
                    value={currentBook.id}
                    onChange={e => updateBookProp("id", e.target.value)}
                    className="text-xs p-2 bg-slate-50 border border-slate-300 rounded outline-none font-mono text-zinc-700" 
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="font-mono text-[9px] text-zinc-400 uppercase tracking-wider">Created timestamp</label>
                  <input 
                    type="text" 
                    value={currentBook.createdAt} 
                    className="text-xs p-2 bg-slate-50 border border-slate-200 rounded outline-none font-mono text-zinc-400" 
                    readOnly 
                  />
                </div>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded p-6 shadow-2xs space-y-3">
              <div className="flex justify-between items-center border-b pb-2">
                <h3 className="font-serif text-sm font-semibold text-stone-850 flex items-center space-x-1.5">
                  <span>Raw Curation Export Payload</span>
                </h3>
                <button
                  onClick={copyJsonToClipboard}
                  className="flex items-center space-x-1 text-[11px] font-sans text-stone-800 hover:underline cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5 text-stone-700" />
                  <span>Copy JSON</span>
                </button>
              </div>

              <textarea
                value={JSON.stringify(currentBook, null, 2)}
                className="w-full h-64 font-mono text-[10px] leading-relaxed p-3 bg-stone-900 text-emerald-400 rounded focus:outline-none"
                readOnly
              />
            </div>
          </div>
        )}

      </main>

      {/* SECURE POPUP TOAST NOTIFIER */}
      {showToast && (
        <div className="fixed bottom-6 right-6 bg-stone-900 text-cream-50 font-serif italic text-xs py-3 px-5 rounded-md shadow-2xl z-50 animate-scaleUp flex items-center space-x-2">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{showToast}</span>
        </div>
      )}

    </div>
  );
}
