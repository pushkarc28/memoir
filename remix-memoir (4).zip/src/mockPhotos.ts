import { Photo } from "./types";
export interface PhotoAlbum {
  id: string;
  name: string;
  description: string;
  coverUrl: string;
  photos: Photo[];
}
export const mockAlbums: PhotoAlbum[] = [];
