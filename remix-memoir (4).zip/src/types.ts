export interface Photo {
  id: string;
  url: string;
  title?: string;
  timestamp: string; // ISO string
  location?: string; // e.g. "Paris, France" or "Local Café"
  category: 'travel' | 'cafe' | 'nature' | 'family' | 'custom';
  aspectRatio: 'landscape' | 'portrait' | 'square';
  analysis?: {
    tags: string[];
    colors: string[];
    insight: string;
  };
}

export interface BookSpread {
  id: string;
  pageNumber: number;
  layout: 'single' | 'double' | 'split-vertical' | 'narrative-only';
  photos: Photo[];
  caption: string;
}

export interface MemoirBook {
  id: string;
  title: string;
  subtitle: string;
  style: 'moleskine' | 'classic' | 'journal';
  coverPhotoUrl: string;
  openingNarrative: string;
  spreads: BookSpread[];
  photoCount: number;
  createdAt: string;
  pageColor?: string;
  coverColor?: string;
  textColor?: string;
  fontTitle?: string;
  fontBody?: string;
  motif?: string;
  emojiTheme?: string;
}

export interface OrderDetails {
  id: string;
  bookId: string;
  bookTitle: string;
  format: 'softcover' | 'hardcover' | 'leather';
  size: '6x6' | '8x8' | '10x10';
  price: number;
  shippingAddress: {
    fullName: string;
    email: string;
    phone: string;
    addressLine1: string;
    addressLine2?: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  paymentId?: string;
  paymentStatus: 'pending' | 'completed' | 'failed';
  createdAt: string;
}
