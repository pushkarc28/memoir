import { useState, useEffect } from "react";
import { Photo, MemoirBook, OrderDetails } from "./types";
import { mockAlbums } from "./mockPhotos";
import Header from "./components/Header";
import PhotosPicker from "./components/PhotosPicker";
import NarrativeBook from "./components/NarrativeBook";
import OrderForm from "./components/OrderForm";
import RazorpayModal from "./components/RazorpayModal";
import OrderConfirmation from "./components/OrderConfirmation";
import CurationControlPanel from "./components/CurationControlPanel";
import AdminDashboard from "./components/AdminDashboard";
import { 
  BookOpen, 
  Sparkles, 
  Trash2, 
  Camera, 
  ArrowRight, 
  Shield, 
  Heart, 
  Compass, 
  Eye,
  AlertCircle
} from "lucide-react";

export default function App() {
  const [isAdmin, setIsAdmin] = useState(() => {
    return window.location.pathname === '/admin' || window.location.hash === '#/admin' || window.location.hash === '#admin';
  });

  useEffect(() => {
    const handleUrlChange = () => {
      setIsAdmin(window.location.pathname === '/admin' || window.location.hash === '#/admin' || window.location.hash === '#admin');
    };
    window.addEventListener("popstate", handleUrlChange);
    window.addEventListener("hashchange", handleUrlChange);
    return () => {
      window.removeEventListener("popstate", handleUrlChange);
      window.removeEventListener("hashchange", handleUrlChange);
    };
  }, []);

  // Personalized default context prefilling
  const [userEmail, setUserEmail] = useState<string | null>("pushkarytube@gmail.com");
  const [currentStep, setCurrentStep] = useState<'home' | 'picker' | 'loading' | 'preview' | 'order' | 'confirmation'>('home');
  const [literaryTone, setLiteraryTone] = useState<string>("poetic");
  
  const [loadingStepText, setLoadingStepText] = useState("Your story is being assembled...");
  const [loadingSubText, setLoadingSubText] = useState("Our AI is reviewing photo clarity thresholds...");
  
  const [photosPool, setPhotosPool] = useState<Photo[]>([]);
  const [albumName, setAlbumName] = useState("");
  const [book, setBook] = useState<MemoirBook | null>(null);
  const [visionDebug, setVisionDebug] = useState<any[]>([]);
  
  const [pendingOrderInput, setPendingOrderInput] = useState<Omit<OrderDetails, "id" | "createdAt" | "paymentStatus"> | null>(null);
  const [curationError, setCurationError] = useState<string | null>(null);
  const [finalOrder, setFinalOrder] = useState<OrderDetails | null>(null);
  const [showRazorpay, setShowRazorpay] = useState(false);

  // Google OAuth States
  const [googleToken, setGoogleToken] = useState<string | null>(() => localStorage.getItem("memoir_google_token"));
  const [googleProfile, setGoogleProfile] = useState<any | null>(() => {
    const saved = localStorage.getItem("memoir_google_profile");
    return saved ? JSON.parse(saved) : null;
  });

  // Listen for message from the callback popup window
  useEffect(() => {
    const handleOAuthMessage = (event: MessageEvent) => {
      const origin = event.origin;
      // Accept matching origin or localhost
      if (!origin.endsWith('.run.app') && !origin.includes('localhost') && !origin.includes('127.0.0.1')) {
        return;
      }
      
      if (event.data?.type === 'GOOGLE_PHOTOS_AUTH_SUCCESS') {
        const { accessToken, userProfile } = event.data;
        if (accessToken) {
          setGoogleToken(accessToken);
          localStorage.setItem("memoir_google_token", accessToken);
          
          if (userProfile) {
            setGoogleProfile(userProfile);
            localStorage.setItem("memoir_google_profile", JSON.stringify(userProfile));
            if (userProfile.email) {
              setUserEmail(userProfile.email);
            }
          }
          // Dynamic step routing to picker once successfully linked
          setCurrentStep('picker');
        }
      }
    };

    window.addEventListener('message', handleOAuthMessage);
    return () => window.removeEventListener('message', handleOAuthMessage);
  }, []);

  // Authenticate triggers
  const handleSignIn = async () => {
    try {
      const res = await fetch("/api/auth/google/url");
      if (!res.ok) {
        throw new Error("Unable to obtain authorization URL");
      }
      const data = await res.json();
      if (!data.url) {
        throw new Error("Client OAuth is not configured on the server");
      }
      
      // Open the provider authorization URL directly in a popup window
      const width = 600;
      const height = 700;
      const left = window.screen.width / 2 - width / 2;
      const top = window.screen.height / 2 - height / 2;
      
      const popup = window.open(
        data.url,
        "Google Photos Authorization",
        `width=${width},height=${height},left=${left},top=${top},status=no,resizable=yes`
      );

      if (!popup) {
        alert("The authentication window was blocked by your browser. Please permit popups for this site and try again.");
      }
    } catch (err: any) {
      console.error(err);
      alert(`OAuth connection failure: ${err.message || err}`);
    }
  };

  const handleSignOut = () => {
    setUserEmail(null);
    setGoogleToken(null);
    setGoogleProfile(null);
    localStorage.removeItem("memoir_google_token");
    localStorage.removeItem("memoir_google_profile");
  };

  const handleGoHome = () => {
    setCurrentStep('home');
  };

  // Trigger high-fidelity narrative generation via Express + Gemini Pro/Flash
  const handlePhotosSelectedForCuration = async (selectedAlbumName: string, selectedPhotos: Photo[]) => {
    setAlbumName(selectedAlbumName);
    setPhotosPool(selectedPhotos);
    setCurrentStep('loading');
    setVisionDebug([]);
    
    // Cycle custom physical-looking loaders
    const loaderPhrases = [
      { t: "Examining each photograph...", s: "Gemini vision is reading scenes, moods, light, and subjects" },
      { t: "Discovering narrative threads...", s: "Clustering images by visual harmony and story arc" },
      { t: "Ordering your story...", s: "Arranging spreads for the strongest opening, middle, and close" },
      { t: "Writing your captions...", s: "Composing poetic lines from what Gemini actually sees in each image" }
    ];

    let step = 0;
    const interval = setInterval(() => {
      if (step < loaderPhrases.length) {
        setLoadingStepText(loaderPhrases[step].t);
        setLoadingSubText(loaderPhrases[step].s);
        step++;
      }
    }, 1500);

    try {
      // Step 1: Run vision analysis on all photos
      let visionPhotos = selectedPhotos;
      const visionResponse = await fetch("/api/analyze-photos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ photos: selectedPhotos })
      });
      if (visionResponse.ok) {
        visionPhotos = await visionResponse.json();
        setVisionDebug(visionPhotos.map((p: any) => ({
          id: p.id,
          url: p.url,
          hasVision: !!p.vision,
          scene: p.vision?.scene || "none",
          mood: p.vision?.mood || "none",
          subjects: p.vision?.subjects?.join(", ") || "none",
          caption: p.vision?.suggestedCaption || "NO CAPTION GENERATED",
          storyPotential: p.vision?.storyPotential || 0
        })));
      } else {
        const errData = await visionResponse.json().catch(() => ({}));
        throw new Error(errData.error || `Photo analysis failed with status ${visionResponse.status}`);
      }

      // Step 2: Cluster photos into best album order
      let orderedPhotos = visionPhotos;
      const clusterResponse = await fetch("/api/cluster-photos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ photos: visionPhotos })
      });
      if (clusterResponse.ok) {
        const clusters = await clusterResponse.json();
        if (clusters.length > 0) {
          // Use the highest-cohesion album's ordered photo sequence
          orderedPhotos = clusters[0].photos;
        }
      } else {
        const errData = await clusterResponse.json().catch(() => ({}));
        throw new Error(errData.error || `Photo clustering failed with status ${clusterResponse.status}`);
      }

      // Step 3: Curate the book using vision-enriched, ordered photos
      const response = await fetch("/api/curate-book", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          albumTitle: selectedAlbumName,
          photos: orderedPhotos,
          literaryTone: literaryTone
        })
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `Book curation failed with status ${response.status}`);
      }

      const data = await response.json();
      clearInterval(interval);

      // Use the cover photo suggested by clustering if available
      const coverUrl = orderedPhotos[0]?.url || selectedPhotos[0]?.url || "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=600";

      const photoVisionMap = new Map(visionPhotos.map((p: any) => [p.id, p]));
      const rawSpreads = data.spreads || [];
      const spreadsWithVision = rawSpreads.map((spread: any) => ({
        ...spread,
        photos: (spread.photos || []).map((p: any) => ({
          ...(photoVisionMap.get(p.id) || p)
        }))
      }));

      const nextBook: MemoirBook = {
        id: `book-${Date.now()}`,
        title: data.title || "A Season of Light",
        subtitle: data.subtitle || "A quiet preservation of moments",
        style: 'moleskine',
        coverPhotoUrl: coverUrl,
        openingNarrative: data.openingNarrative,
        spreads: spreadsWithVision,
        photoCount: data.photoCount || orderedPhotos.length,
        createdAt: new Date().toISOString()
      };

      setBook(nextBook);
      setCurrentStep('preview');

    } catch (err: any) {
      console.error("Curation pipeline failed:", err);
      clearInterval(interval);
      setCurationError(err.message || String(err));
      setCurrentStep('picker');
    }
  };

  // Trigger Razorpay Modal
  const handleInitiatePayment = (orderInput: Omit<OrderDetails, "id" | "createdAt" | "paymentStatus">) => {
    setPendingOrderInput(orderInput);
    setShowRazorpay(true);
  };

  const handlePaymentSuccess = (paymentId: string) => {
    if (!pendingOrderInput) return;
    
    const fullyCapturedOrder: OrderDetails = {
      ...pendingOrderInput,
      id: `ord_${Math.random().toString(36).substring(2, 11)}`,
      paymentId,
      paymentStatus: 'completed',
      createdAt: new Date().toISOString()
    };

    setFinalOrder(fullyCapturedOrder);
    setShowRazorpay(false);
    setCurrentStep('confirmation');
  };

  const handlePaymentFailed = () => {
    alert("Payment verification failed. Please try another simulator card inside Razorpay checkout.");
    setShowRazorpay(false);
  };

  if (isAdmin) {
    return <AdminDashboard />;
  }

  return (
    <div className="min-h-screen bg-cream-50 flex flex-col selection:bg-terracotta selection:text-cream-50">
      
      {/* Dynamic Header */}
      <Header 
        userEmail={userEmail} 
        googleProfile={googleProfile}
        onSignIn={handleSignIn} 
        onSignOut={handleSignOut}
        onGoHome={handleGoHome}
      />

      {/* Pages Layout Body */}
      <main className="flex-1 px-6 max-w-6xl w-full mx-auto pb-16 flex flex-col justify-center">
        
        {/* STEP 1: HOME PANEL */}
        {currentStep === 'home' && (
          <div className="space-y-12">
            <div className="py-12 md:py-20 flex flex-col lg:flex-row items-center gap-12 animate-fadeIn">
              
              {/* Editorial copy */}
              <div className="lg:w-1/2 space-y-6">
                <div className="flex items-center space-x-2">
                  <span className="bg-sage/10 text-sage font-mono text-[9px] font-bold tracking-widest uppercase py-1 px-2.5 rounded">
                    THE LITERARY PHOTO BOOK
                  </span>
                  <span className="w-1.5 h-1.5 rounded-full bg-terracotta"></span>
                  <span className="text-zinc-500 font-mono text-[9px] tracking-wider uppercase">
                    MEMENTO PRESS
                  </span>
                </div>

                <h2 className="font-serif text-4xl md:text-6xl font-medium tracking-tight text-ink-900 leading-[1.1]">
                  Your photographs are stories, <br />
                  <span className="italic font-serif font-serif italic text-terracotta">not data.</span>
                </h2>

                <p className="font-serif text-sm md:text-base text-ink-700 leading-relaxed max-w-lg">
                  Connect your Google Photos and let Memoir's narrative AI act as your personal editor. We filter out duplicate streams, layout chronologies, and compose custom narrative intros and captions &mdash; binding them in a beautifully finished printed volume of Japanese cream paper under clothbound cover panels.
                </p>

                <div className="pt-4 flex flex-col sm:flex-row sm:items-center gap-4">
                  <button
                    onClick={() => setCurrentStep('picker')}
                    className="flex items-center justify-center space-x-3 bg-ink-900 hover:bg-ink-700 text-cream-50 px-8 py-4 font-sans text-xs font-semibold uppercase tracking-wider rounded-sm transition-all hover:shadow-md cursor-pointer active:scale-95 group shrink-0"
                  >
                    <span>Create your Book</span>
                    <ArrowRight className="w-4 h-4 text-cream-400 group-hover:translate-x-1 transition-transform" />
                  </button>

                  {!googleToken ? (
                    <button
                      onClick={handleSignIn}
                      className="flex items-center justify-center space-x-2.5 border border-cream-300 bg-cream-50 text-ink-900 hover:bg-cream-100 hover:border-cream-400 px-6 py-4 font-sans text-xs font-semibold uppercase tracking-wider rounded-sm transition-all shadow-sm cursor-pointer active:scale-95 shrink-0"
                    >
                      <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path
                          fill="#ea4335"
                          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        />
                        <path
                          fill="#34a853"
                          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        />
                        <path
                          fill="#fbbc05"
                          d="m5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22c-.08-.21-.14-.42-.14-.63z"
                        />
                        <path
                          fill="#4285f4"
                          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                        />
                      </svg>
                      <span>Connect Google Photos</span>
                    </button>
                  ) : (
                    <div className="flex items-center space-x-3 bg-sage/5 border border-sage/20 px-4 py-3 rounded-sm shrink-0">
                      <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sage opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-sage"></span>
                      </span>
                      <span className="font-sans text-xs text-ink-800 leading-none">
                        Connected to Google Photos as <strong className="font-semibold text-ink-900">{googleProfile?.name || googleProfile?.email}</strong>
                      </span>
                    </div>
                  )}
                  
                  <p className="font-mono text-[9px] tracking-wide text-zinc-500 uppercase leading-normal">
                    * Privately curates selected albums. Razorpay sandbox active.
                  </p>
                </div>

                {/* Minimal Trust Seals */}
                <div className="pt-8 grid grid-cols-3 gap-4 border-t border-cream-200">
                  <div>
                    <h4 className="font-serif text-xs font-semibold text-ink-900">Japanese Paper</h4>
                    <p className="font-sans text-[10px] text-zinc-500 mt-1">Acid-free 300-year archive parchment</p>
                  </div>
                  <div>
                    <h4 className="font-serif text-xs font-semibold text-ink-900">Smart Curate</h4>
                    <p className="font-sans text-[10px] text-zinc-500 mt-1">Gemini selects key moments, discards noise</p>
                  </div>
                  <div>
                    <h4 className="font-serif text-xs font-semibold text-ink-900">Secure Bound</h4>
                    <p className="font-sans text-[10px] text-zinc-500 mt-1">Hand-stitched in our local custom bookbindery</p>
                  </div>
                </div>

              </div>

              {/* Premium Physical Mockup Display */}
              <div className="lg:w-1/2 w-full">
                <div className="aspect-[4/3] w-full bg-cream-100 border border-cream-200/50 rounded-lg p-6 relative flex flex-col justify-between shadow-xl moleskine-shadow select-none group pointer-events-none">
                  
                  {/* Book page spine */}
                  <div className="absolute inset-y-0 left-1/3 -ml-2.5 w-5 bg-gradient-to-r from-black/5 via-black/10 to-transparent z-10 rounded"></div>
                  
                  <div className="w-full h-full bg-cream-50 border border-cream-300 rounded flex shadow-sm relative overflow-hidden">
                    
                    {/* Left layout page */}
                    <div className="w-1/3 bg-cream-100 p-4 border-r border-cream-200 flex flex-col justify-between h-full">
                      <span className="font-mono text-[8px] text-zinc-500 uppercase">VOL I. TRAVELS</span>
                      <div className="py-2">
                        <h4 className="font-serif text-sm font-semibold text-ink-900 leading-tight">Northwest Roads</h4>
                        <p className="font-serif text-[10px] text-zinc-400 italic mt-0.5">Oregon, 2024</p>
                      </div>
                      <span className="font-mono text-[8px] text-zinc-400">MEMOIR</span>
                    </div>

                    {/* Right layout description spread */}
                    <div className="w-2/3 bg-cream-50 p-6 flex flex-col justify-between h-full relative">
                      <p className="font-serif text-xs text-ink-900 leading-relaxed italic mt-4">
                        "This was the year you spent 40 days on the coastal highway, waking up to the ocean spray, and deciding that some moments were worth binding in ink."
                      </p>
                      
                      <div className="h-28 aspect-video bg-neutral-100 border rounded-sm overflow-hidden mt-2 relative">
                        <img 
                          src="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=600" 
                          alt="Oregon travel" 
                          className="w-full h-full object-cover" 
                        />
                      </div>

                      <div className="flex justify-between items-center text-[7px] font-mono text-zinc-400 mt-4 border-t pt-2">
                        <span>SPREAD 1</span>
                        <span>PAGE 3</span>
                      </div>
                    </div>

                  </div>

                  {/* Aesthetic label badge */}
                  <div className="absolute -bottom-3 right-6 bg-terracotta text-cream-50 font-mono text-[9px] uppercase tracking-widest px-3 py-1 shadow-md">
                    Active Demo Live
                  </div>
                </div>
              </div>

            </div>

            {/* Developer control center */}
            <CurationControlPanel
              currentBook={book}
              onLoadBook={(loadedBook) => {
                setBook(loadedBook);
                const photosFromSpreads = loadedBook.spreads.flatMap(s => s.photos);
                setPhotosPool(photosFromSpreads);
                setCurrentStep('preview');
              }}
              onUpdateBook={setBook}
              literaryTone={literaryTone}
              onChangeTone={setLiteraryTone}
              fullPhotosPool={photosPool}
            />
          </div>
        )}

        {/* STEP 2: CONNECTOR PICKER */}
        {currentStep === 'picker' && (
          <div className="animate-fadeIn space-y-4">
            {curationError && (
              <div className="max-w-4xl mx-auto bg-red-50 border border-red-200 text-red-800 p-4 rounded-md flex items-start space-x-3 shadow-sm">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <h4 className="font-serif font-semibold text-sm">Curation Pipeline Failure</h4>
                  <p className="font-sans text-xs text-red-700 mt-1">{curationError}</p>
                  <button 
                    onClick={() => setCurationError(null)}
                    className="mt-2 text-xs font-semibold text-red-900 hover:underline"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            )}
            <PhotosPicker 
              onPhotosSelected={handlePhotosSelectedForCuration} 
              googleToken={googleToken}
              googleProfile={googleProfile}
              onDisconnectGoogle={handleSignOut}
            />
          </div>
        )}

        {/* STEP 3: CURATOR LOADING SCREENS */}
        {currentStep === 'loading' && (
          <div className="max-w-md mx-auto py-20 text-center space-y-6 animate-scaleUp">
            <div className="relative w-16 h-16 mx-auto">
              <div className="absolute inset-0 rounded-full border-4 border-cream-200"></div>
              <div className="absolute inset-0 rounded-full border-4 border-terracotta border-t-transparent animate-spin"></div>
            </div>
            
            <div className="space-y-2">
              <h3 className="font-serif text-2xl font-medium text-ink-900 leading-tight">
                {loadingStepText}
              </h3>
              <p className="font-sans text-xs text-ink-500">
                {loadingSubText}
              </p>
            </div>

            <div className="p-4 bg-cream-100 border border-cream-200 rounded max-w-sm mx-auto">
              <span className="font-mono text-[8px] uppercase tracking-widest text-terracotta block font-bold mb-1">
                LITERARY METADATA ANALYTIC
              </span>
              <p className="font-serif italic text-[11px] text-zinc-600 leading-relaxed">
                "Our preservation engine is stitching dates, locations, and photo density ratios into a bespoke narrative preface..."
              </p>
            </div>

            {visionDebug.length > 0 && (
              <div className="mx-auto" style={{
                marginTop: "2rem",
                maxHeight: "400px",
                overflowY: "auto",
                background: "#111",
                borderRadius: "12px",
                padding: "1rem",
                textAlign: "left",
                width: "100%",
                maxWidth: "600px"
              }}>
                <p style={{ color: "#888", fontSize: "12px", marginBottom: "12px" }}>
                  VISION ANALYSIS — {visionDebug.length} photos
                </p>
                {visionDebug.map((p) => (
                  <div key={p.id} style={{
                    display: "flex", gap: "12px", marginBottom: "12px",
                    borderBottom: "1px solid #222", paddingBottom: "12px"
                  }}>
                    <img src={p.url} style={{
                      width: "60px", height: "60px",
                      objectFit: "cover", borderRadius: "6px", flexShrink: 0
                    }} referrerPolicy="no-referrer" />
                    <div>
                      <p style={{ color: p.hasVision ? "#4ade80" : "#f87171", 
                        fontSize: "11px", margin: "0 0 4px" }}>
                        {p.hasVision ? "✓ vision ok" : "✗ no vision data"}
                      </p>
                      <p style={{ color: "#ccc", fontSize: "12px", margin: "0 0 2px" }}>
                        {p.scene} · {p.mood} · ⭐{p.storyPotential}
                      </p>
                      <p style={{ color: "#aaa", fontSize: "11px", margin: "0 0 2px" }}>
                        {p.subjects}
                      </p>
                      <p style={{ color: "#fff", fontSize: "12px", 
                        fontStyle: "italic", margin: 0 }}>
                        "{p.caption}"
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* STEP 4: MEMOIR SPREADS PREVIEW STUDIO */}
        {currentStep === 'preview' && book && (
          <div className="space-y-6 animate-fadeIn">
            <NarrativeBook
              book={book}
              fullPhotosPool={photosPool}
              onUpdateBook={setBook}
              onPlaceOrder={() => setCurrentStep('order')}
            />
            
            <CurationControlPanel
              currentBook={book}
              onLoadBook={(loadedBook) => {
                setBook(loadedBook);
                const photosFromSpreads = loadedBook.spreads.flatMap(s => s.photos);
                setPhotosPool(photosFromSpreads);
              }}
              onUpdateBook={setBook}
              literaryTone={literaryTone}
              onChangeTone={setLiteraryTone}
              fullPhotosPool={photosPool}
            />
          </div>
        )}

        {/* STEP 5: MATERIALS & ORDER SHEET */}
        {currentStep === 'order' && book && (
          <div className="animate-fadeIn">
            <OrderForm
              book={book}
              userEmail={userEmail}
              onBack={() => setCurrentStep('preview')}
              onSubmitOrder={handleInitiatePayment}
            />
          </div>
        )}

        {/* STEP 6: CELEBRATION DISPATCH CONFIRMATION */}
        {currentStep === 'confirmation' && finalOrder && (
          <div className="animate-fadeIn">
            <OrderConfirmation 
              order={finalOrder} 
              onRestart={() => setCurrentStep('home')}
            />
          </div>
        )}

      </main>

      {/* SECURE TRANS-GATEWAY RAZORPAY MODAL */}
      {showRazorpay && pendingOrderInput && (
        <RazorpayModal
          order={pendingOrderInput}
          onSuccess={handlePaymentSuccess}
          onFailed={handlePaymentFailed}
          onClose={() => setShowRazorpay(false)}
        />
      )}

      {/* Handcrafted Footer */}
      <footer className="border-t border-cream-200 py-6 mt-auto">
        <div className="max-w-6xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-serif italic text-xs text-ink-500">
            For those who care about physical permanence in a digital world.
          </p>
          <div className="flex items-center space-x-4 font-mono text-[9px] tracking-widest text-zinc-400 uppercase">
            <span>MEMOIR PRESS ATELIER</span>
            <span className="w-1.5 h-1.5 rounded-full bg-cream-300"></span>
            <span>PCI SECURE</span>
            <span className="w-1.5 h-1.5 rounded-full bg-cream-300"></span>
            <span>ESTD. 2026</span>
            <span className="w-1.5 h-1.5 rounded-full bg-cream-300"></span>
            <a href="#admin" onClick={() => setIsAdmin(true)} className="hover:text-stone-800 underline lowercase font-serif italic tracking-normal normal-case">admin portal</a>
          </div>
        </div>
      </footer>

    </div>
  );
}
