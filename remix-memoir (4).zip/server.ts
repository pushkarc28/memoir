import express from "express";
import path from "path";
import dotenv from "dotenv";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import Groq from "groq-sdk";
import { mockAlbums } from "./src/mockPhotos";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Google OAuth Constants
const CLIENT_ID = process.env.OAUTH_CLIENT_ID || process.env.GOOGLE_CLIENT_ID || process.env.CLIENT_ID;
const CLIENT_SECRET = process.env.OAUTH_CLIENT_SECRET || process.env.GOOGLE_CLIENT_SECRET || process.env.CLIENT_SECRET;

console.log("Current Environment variables related to OAuth:");
console.log("- process.env.OAUTH_CLIENT_ID exists:", !!process.env.OAUTH_CLIENT_ID);
console.log("- process.env.GOOGLE_CLIENT_ID exists:", !!process.env.GOOGLE_CLIENT_ID);
console.log("- process.env.CLIENT_ID exists:", !!process.env.CLIENT_ID);
console.log("- CLIENT_SECRET exists:", !!(process.env.OAUTH_CLIENT_SECRET || process.env.GOOGLE_CLIENT_SECRET || process.env.CLIENT_SECRET));

// Helper to determine redirect URI
const getRedirectUri = () => {
  const appUrl = process.env.APP_URL || "http://localhost:3000";
  const normalized = appUrl.endsWith("/") ? appUrl.slice(0, -1) : appUrl;
  return `${normalized}/auth/callback`;
};

// Map Google Photos mediaItem format to Memoir Photo schema
function mapGooglePhoto(item: any): any {
  const width = parseInt(item.mediaMetadata?.width || "4000");
  const height = parseInt(item.mediaMetadata?.height || "3000");
  let aspectRatio: "landscape" | "portrait" | "square" = "landscape";
  if (width < height) {
    aspectRatio = "portrait";
  } else if (width === height) {
    aspectRatio = "square";
  }

  // Infer category based on filename or metadata descriptions
  const filename = (item.filename || "").toLowerCase();
  const desc = (item.description || "").toLowerCase();
  let category = "custom";
  
  if (
    filename.includes("coffee") || filename.includes("cafe") || filename.includes("food") || 
    filename.includes("restaurant") || filename.includes("eat") || desc.includes("coffee") || desc.includes("cafe")
  ) {
    category = "cafe";
  } else if (
    filename.includes("nature") || filename.includes("lake") || filename.includes("mountain") || 
    filename.includes("beach") || filename.includes("park") || filename.includes("hike") || 
    filename.includes("sky") || desc.includes("nature") || desc.includes("lake") || desc.includes("park")
  ) {
    category = "nature";
  } else if (
    filename.includes("travel") || filename.includes("trip") || filename.includes("city") || 
    filename.includes("street") || filename.includes("hotel") || filename.includes("vacation") || 
    filename.includes("road") || desc.includes("trip") || desc.includes("travel")
  ) {
    category = "travel";
  } else if (
    filename.includes("family") || filename.includes("friend") || filename.includes("wedding") || 
    filename.includes("party") || filename.includes("love") || desc.includes("family")
  ) {
    category = "family";
  }

  // Inferred editorial location names or fallback to camera details
  let location = "A quiet memory";
  if (item.mediaMetadata?.photo?.cameraModel) {
    location = `Captured on ${item.mediaMetadata.photo.cameraModel}`;
  } else if (category === "nature") {
    location = "Quiet Wilderness";
  } else if (category === "cafe") {
    location = "Charming Patisserie";
  } else if (category === "travel") {
    location = "A street well-traveled";
  }

  return {
    id: item.id,
    url: `${item.baseUrl}=w800`, // Google Photos API requires sizing parameter (e.g. =w800) to render images correctly
    title: item.filename || item.description || "Moments in time",
    timestamp: item.mediaMetadata?.creationTime || new Date().toISOString(),
    location: location,
    category: category,
    aspectRatio: aspectRatio
  };
}

// 1. Return Google OAuth Authorization URL
app.get("/api/auth/google/url", (req, res) => {
  if (!CLIENT_ID) {
    console.warn("process.env.OAUTH_CLIENT_ID is missing; routing stream login to mock Google Photos sandbox.");
    return res.json({ url: "/auth/mock-google-login" });
  }

  const redirectUri = getRedirectUri();
  const params = new URLSearchParams({
    client_id: CLIENT_ID,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: "openid email profile https://www.googleapis.com/auth/photoslibrary.readonly",
    access_type: "offline",
    prompt: "consent"
  });

  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
  res.json({ url: authUrl });
});

// 1.5 Mock Google Login screen for preview sandbox testability
app.get("/auth/mock-google-login", (req, res) => {
  res.send(`
    <html>
      <head>
        <title>Sign in with Google - Memoir Studio</title>
        <style>
          body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #faf8f5;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            color: #1a1a1a;
          }
          .box {
            background: white;
            border-radius: 6px;
            box-shadow: 0 4px 24px rgba(40,30,20,0.06);
            width: 440px;
            padding: 40px;
            box-sizing: border-box;
            border: 1px solid #e6e1da;
          }
          .logo {
            display: flex;
            justify-content: center;
            margin-bottom: 24px;
          }
          .header {
            text-align: center;
            margin-bottom: 32px;
          }
          h1 {
            font-size: 24px;
            font-weight: 500;
            margin: 0 0 8px 0;
            color: #1a1a1a;
            font-family: Georgia, serif;
          }
          p {
            font-size: 14px;
            margin: 0;
            color: #706a60;
          }
          .scope-box {
            background-color: #fcfbfa;
            border: 1px solid #efeae2;
            border-radius: 4px;
            padding: 18px;
            margin-bottom: 24px;
            font-size: 13px;
            color: #4a453e;
            line-height: 1.5;
          }
          .scope-title {
            font-weight: 600;
            margin-bottom: 10px;
            color: #1a1a1a;
            display: flex;
            align-items: center;
            gap: 8px;
          }
          .btn-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 32px;
          }
          .btn-text {
            color: #8c2d19;
            background: none;
            border: none;
            font-weight: 500;
            font-size: 13px;
            cursor: pointer;
            padding: 8px 12px;
            border-radius: 4px;
          }
          .btn-text:hover {
            background-color: #faf5f0;
          }
          .btn-primary {
            background-color: #1a1a1a;
            color: #f7f4ef;
            border: none;
            padding: 10px 24px;
            font-size: 13px;
            font-weight: 600;
            border-radius: 3px;
            cursor: pointer;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            transition: all 0.2s;
          }
          .btn-primary:hover {
            background-color: #333333;
          }
        </style>
      </head>
      <body>
        <div class="box">
          <div class="logo">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="m5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22c-.08-.21-.14-.42-.14-.63z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#EA4335"/>
            </svg>
          </div>
          <div class="header">
            <h1>Link Google Photos</h1>
            <p>to continue to your Memoir bookmaker</p>
          </div>
          <div class="scope-box">
            <div class="scope-title">
              <span>🔒 Sandbox Preview Active</span>
            </div>
            <div>Google OAuth environment variables are pending setup. We have auto-launched an interactive sandbox. Click authorize below to unlock simulated cloud books with premium travel photography!</div>
          </div>
          <div class="btn-container">
            <button class="btn-text" onclick="window.close()">Cancel</button>
            <button class="btn-primary" onclick="proceed()">Authorize Sandbox</button>
          </div>
        </div>
        <script>
          function proceed() {
            if (window.opener) {
              window.opener.postMessage({
                type: 'GOOGLE_PHOTOS_AUTH_SUCCESS',
                accessToken: 'mock-google-token-sandbox-active-' + Date.now(),
                userProfile: {
                  name: 'Pushkar Kumar (Sandbox)',
                  email: 'pushkarytube@gmail.com',
                  picture: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=150'
                }
              }, '*');
              window.close();
            } else {
              window.location.href = '/';
            }
          }
        </script>
      </body>
    </html>
  `);
});

// 2. Google OAuth Callback Route
app.get(["/auth/callback", "/auth/callback/"], async (req, res) => {
  const { code } = req.query;

  if (!code) {
    return res.status(400).send("Authorization code is missing from callback");
  }

  try {
    const redirectUri = getRedirectUri();
    
    // Exchange Authorization Code for Access & Refresh Tokens
    const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: new URLSearchParams({
        code: code as string,
        client_id: CLIENT_ID!,
        client_secret: CLIENT_SECRET!,
        redirect_uri: redirectUri,
        grant_type: "authorization_code"
      }).toString()
    });

    if (!tokenResponse.ok) {
      const errText = await tokenResponse.text();
      throw new Error(`Failed to exchange code: ${errText}`);
    }

    const tokens = await tokenResponse.json();
    const accessToken = tokens.access_token;

    // Fetch user details from userinfo endpoint to personalize experience
    const profileResponse = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
      headers: {
        Authorization: `Bearer ${accessToken}`
      }
    });

    let userProfile = null;
    if (profileResponse.ok) {
      userProfile = await profileResponse.json();
    }

    // Return HTML page with a postMessage script that relays auth credentials back to the main app iframe
    res.send(`
      <html>
        <head>
          <title>Authenticating with Google...</title>
          <style>
            body { font-family: -apple-system, sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; background: #faf8f5; color: #1e1e1e; margin: 0; }
            .card { text-align: center; padding: 2rem; background: #fff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); border: 1px solid #e5e0da; }
            h3 { margin: 0 0 0.5rem 0; font-weight: 600; }
            p { margin: 0; color: #666; font-size: 0.9rem; }
          </style>
        </head>
        <body>
          <div class="card">
            <h3>Google Photos Linked</h3>
            <p>Connection successful! We are syncing your albums. This window will close automatically.</p>
          </div>
          <script>
            if (window.opener) {
              window.opener.postMessage({
                type: 'GOOGLE_PHOTOS_AUTH_SUCCESS',
                accessToken: '${accessToken}',
                userProfile: ${JSON.stringify(userProfile)}
              }, '*');
              setTimeout(() => { window.close(); }, 1200);
            } else {
              window.location.href = '/';
            }
          </script>
        </body>
      </html>
    `);

  } catch (error: any) {
    console.error("Error during Google OAuth callback:", error);
    res.status(500).send(`Authentication error: ${error.message}`);
  }
});

// 3. Google Photos API proxy - Fetch User's Google Photos Albums
app.get("/api/google-photos/albums", async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ error: "Missing google authorization header." });
  }

  const token = authHeader.split(" ")[1];

  if (token.startsWith("mock-google-token")) {
    return res.json([]);
  }

  try {
    const response = await fetch("https://photoslibrary.googleapis.com/v1/albums?pageSize=50", {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });

    if (!response.ok) {
      const errText = await response.text();
      return res.status(response.status).json({ error: `Google Photos response error: ${errText}` });
    }

    const data = await response.json();
    return res.json(data.albums || []);
  } catch (error: any) {
    console.error("Proxy error fetching Google Photos albums:", error);
    return res.status(500).json({ error: error.message });
  }
});

// 4. Google Photos API proxy - Fetch photos inside a specific Album
app.get("/api/google-photos/album-photos", async (req, res) => {
  const authHeader = req.headers.authorization;
  const albumId = req.query.albumId as string;

  if (!authHeader) {
    return res.status(401).json({ error: "Missing authorization token" });
  }
  if (!albumId) {
    return res.status(400).json({ error: "albumId request parameter is required" });
  }

  const token = authHeader.split(" ")[1];

  if (token.startsWith("mock-google-token")) {
    return res.status(404).json({ error: "No mock album found." });
  }

  try {
    const response = await fetch("https://photoslibrary.googleapis.com/v1/mediaItems:search", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        albumId: albumId,
        pageSize: 100
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      return res.status(response.status).json({ error: `Google Photos search error: ${errText}` });
    }

    const data = await response.json();
    const googlePhotos = (data.mediaItems || []).map(mapGooglePhoto);
    return res.json(googlePhotos);
  } catch (error: any) {
    console.error("Proxy error fetching photos from Google Photos album:", error);
    return res.status(500).json({ error: error.message });
  }
});

// 5. Google Photos API proxy - Automatically extract the 100 most recent items from the general photo library (Perfect for users without predefined albums)
app.get("/api/google-photos/all-photos", async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ error: "Missing authorization token" });
  }

  const token = authHeader.split(" ")[1];

  if (token.startsWith("mock-google-token")) {
    return res.json([]);
  }

  try {
    const response = await fetch("https://photoslibrary.googleapis.com/v1/mediaItems?pageSize=100", {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });

    if (!response.ok) {
      const errText = await response.text();
      return res.status(response.status).json({ error: `Google Photos list error: ${errText}` });
    }

    const data = await response.json();
    const googlePhotos = (data.mediaItems || []).map(mapGooglePhoto);
    return res.json(googlePhotos);
  } catch (error: any) {
    console.error("Proxy error extracting general Google Photos:", error);
    return res.status(500).json({ error: error.message });
  }
})// Simple local helper to extract size-shrunk thumbnails to reduce bandwidth and maximize recognition speed
function shrinkImageUrl(url: string): string {
  if (!url) return "";
  if (url.includes("unsplash.com")) {
    const cleanUrl = url.split("?")[0];
    return `${cleanUrl}?q=60&w=220&fit=crop`;
  }
  if (url.includes("googleusercontent.com") || url.includes("googleapis.com")) {
    const cleanUrl = url.split("=")[0];
    return `${cleanUrl}=w220`;
  }
  return url;
}

// Low-latency image downloader that supports 4-second abort timeouts and handles errors gracefully
async function fetchImageBase64(url: string): Promise<{ data: string; mimeType: string } | null> {
  if (!url) return null;

  // Gracefully filter out browser-only blob URLs representing local assets
  if (url.startsWith("blob:")) {
    console.log("Bypassing server-side network download for browser-only blob URL.");
    return null;
  }

  // Parse inline data URLs directly to capture locally uploaded photos without doing network fetches
  if (url.startsWith("data:")) {
    try {
      console.log("Directly parsing client-side data URL for multimodal analysis.");
      const matches = url.match(/^data:([^;]+);base64,(.+)$/);
      if (matches && matches.length === 3) {
        return {
          mimeType: matches[1],
          data: matches[2]
        };
      }
    } catch (err) {
      console.warn("Parsing of inline data URL failed:", err);
    }
    return null;
  }

  try {
    const smallUrl = shrinkImageUrl(url);
    const controller = new AbortController();
    const timerId = setTimeout(() => controller.abort(), 4000);
    
    console.log("Downloading small thumbnail for Gemini analysis:", smallUrl);
    const response = await fetch(smallUrl, { signal: controller.signal });
    clearTimeout(timerId);
    
    if (!response.ok) {
      return null;
    }
    
    const buffer = await response.arrayBuffer();
    const contentType = response.headers.get("content-type") || "image/jpeg";
    const base64Data = Buffer.from(buffer).toString("base64");
    
    return {
      data: base64Data,
      mimeType: contentType
    };
  } catch (err) {
    console.warn(`Could not load candidate visual at ${url}:`, err);
    return null;
  }
}

// 6. Vision Analysis API Endpoint
app.post("/api/analyze-photos", async (req, res) => {
  const { photos } = req.body;
  if (!photos?.length) return res.status(400).json({ error: "No photos provided" });

  const getFallbackVision = (p: any) => {
    const category = p.category || "cafe";
    const scene = category === "cafe" ? "cafe" : category === "nature" ? "nature" : category === "travel" ? "street" : "interior";
    const subjects = category === "cafe" ? ["espresso cup", "wooden table", "warm mug"] :
                     category === "nature" ? ["green trees", "winding path", "shadows on ground"] :
                     category === "travel" ? ["narrow alleyway", "glowing lantern", "old brick walls"] :
                     ["vintage chair", "bookshelf", "morning light"];
    const dominantColors = category === "cafe" ? ["#4A3728", "#DCD0C0"] :
                           category === "nature" ? ["#3B4E43", "#A5A48F"] :
                           ["#2B3E50", "#CCAA88"];
    const suggestedCaption = `A visual perspective of a ${scene} featuring ${subjects.join(" and ")}.`;
    return {
      id: p.id,
      scene,
      mood: "peaceful",
      subjects,
      lightQuality: "golden_hour",
      dominantColors,
      composition: "landscape",
      peoplePresent: false,
      storyPotential: 7,
      suggestedCaption
    };
  };

  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey || apiKey === "MY_GROQ_API_KEY" || apiKey.trim() === "") {
    console.warn("GROQ_API_KEY is not set. Generating mock/fallback vision details for curation.");
    const fallbackAnalyzed = photos.map((p: any) => {
      const category = p.category || "cafe";
      return {
        ...p,
        category,
        vision: getFallbackVision(p)
      };
    });
    return res.json(fallbackAnalyzed);
  }

  const groq = new Groq({ apiKey });
  const analyzed: any[] = [];

  for (const photo of photos) {
    try {
      const response = await groq.chat.completions.create({
        model: "meta-llama/llama-4-scout-17b-16e-instruct",
        messages: [{
          role: "user",
          content: [
            {
              type: "text",
              text: `You are a computer vision model. Look at this 
image and return raw visual facts and a precise description.

Return this exact JSON object:
{
  "id": "${photo.id}",
  "scene": "one of: temple|cafe|street|nature|interior|portrait|food|architecture|beach|mountain|market|other",
  "mood": "one of: contemplative|joyful|melancholic|energetic|intimate|serene|dramatic|nostalgic|peaceful",
  "subjects": ["2-4 specific things visible, e.g. red torii gate, stone lantern, espresso cup on marble bar"],
  "lightQuality": "one of: golden_hour|blue_hour|overcast|harsh_midday|artificial|candlelit|misty|bright_daylight",
  "dominantColors": ["2-3 colors e.g. deep amber, slate grey, forest green"],
  "composition": "one of: portrait|landscape|square",
  "peoplePresent": true or false,
  "storyPotential": number from 1-10,
  "suggestedCaption": "A detailed raw visual description of the photo detailing layout, exact subjects, and colors."
}

Return ONLY the JSON. No markdown. No explanation.`
            },
            {
              type: "image_url",
              image_url: { url: photo.url }
            }
          ]
        }],
        response_format: { type: "json_object" },
        temperature: 0.1,
        max_completion_tokens: 500
      });

      const text = response.choices[0].message.content?.trim() || "{}";
      const vision = JSON.parse(text);
      vision.id = photo.id;

      analyzed.push({
        ...photo,
        category: mapSceneToCategory(vision.scene),
        vision
      });

      console.log(`Vision OK: ${photo.id} → ${vision.scene}, ${vision.mood}`);
      console.log(`Subjects: ${vision.subjects?.join(", ")}`);

    } catch (err: any) {
      console.error(`Vision failed for ${photo.id}, using fallback details:`, err);
      // Fail gracefully for individual photos so the curation doesn't halt
      const category = photo.category || "cafe";
      analyzed.push({
        ...photo,
        category,
        vision: getFallbackVision(photo)
      });
    }

    // Small delay between photos to avoid rate limits
    await new Promise(resolve => setTimeout(resolve, 500));
  }

  res.json(analyzed);
});

function mapSceneToCategory(scene: string): "travel" | "cafe" | "nature" | "family" | "custom" {
  const map: Record<string, "travel" | "cafe" | "nature" | "family" | "custom"> = {
    temple: "travel",
    architecture: "travel",
    street: "travel",
    market: "travel",
    beach: "travel",
    mountain: "nature",
    cafe: "cafe",
    food: "cafe",
    interior: "cafe",
    nature: "nature",
    portrait: "family"
  };
  return map[scene] || "custom";
}

// 7. Smart Clustering Endpoint
app.post("/api/cluster-photos", async (req, res) => {
  const { photos } = req.body;
  if (!photos?.length) return res.status(400).json({ error: "No photos provided" });

  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey || apiKey === "MY_GROQ_API_KEY" || apiKey.trim() === "") {
    console.warn("GROQ_API_KEY is not set. Falling back to default photo order.");
    return res.json([{
      photos,
      albumTitle: "My Memoir"
    }]);
  }

  const groq = new Groq({ apiKey });

  const summaries = photos.map((p: any) => ({
    id: p.id,
    scene: p.vision?.scene || "other",
    mood: p.vision?.mood || "neutral",
    subjects: p.vision?.subjects || [],
    light: p.vision?.lightQuality || "unknown",
    storyPotential: p.vision?.storyPotential || 5,
    peoplePresent: p.vision?.peoplePresent || false
  }));

  try {
    const response = await groq.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      messages: [{
        role: "user",
        content: `You are a photo book editor ordering photos for 
a memoir. Order these ${photos.length} photos into the best 
narrative sequence.

Rules:
- Start with strongest establishing shot (high storyPotential, 
  clear scene, good light)
- Build through middle with variety of scenes and moods
- End with most memorable or emotionally resonant image
- Consider visual flow between adjacent photos

Photos:
${JSON.stringify(summaries, null, 2)}

Return ONLY a JSON array of photo ids in order:
["id1", "id2", "id3"]
No explanation, no markdown.`
      }],
      temperature: 0.3,
      max_completion_tokens: 500
    });

    const text = response.choices[0].message.content?.trim() || "[]";
    const clean = text.replace(/```json|```/g, "").trim();
    
    let ordered = photos;
    try {
      let arrayText = clean;
      const match = clean.match(/\[[\s\S]*\]/);
      if (match) {
        arrayText = match[0];
      }
      const orderedIds = JSON.parse(arrayText);
      if (Array.isArray(orderedIds)) {
        const mapped = orderedIds
          .map(id => photos.find((p: any) => p.id === id))
          .filter(Boolean);
        if (mapped.length > 0) {
          ordered = mapped;
        }
      }
    } catch (parseErr) {
      console.warn("JSON parsing failed for cluster-photos. Falling back to original photos order.", parseErr);
    }

    res.json([{
      photos: ordered,
      albumTitle: "My Memoir"
    }]);

  } catch (err: any) {
    console.error("Cluster error:", err);
    // Graceful fallback to original order on any runtime error
    res.json([{
      photos: photos,
      albumTitle: "My Memoir"
    }]);
  }
});

// Simple local fallback curator that generates gorgeous poetic narratives and spreads
// Now enriched with premium visual insights, tags, and matching color palettes matching the motif
function localCurationFallback(albumTitle: string, userPhotos: any[]) {
  const photoCount = userPhotos.length;
  
  // Try to extract dates and locations
  const locations = Array.from(new Set(userPhotos.map(p => p.location).filter(Boolean))) as string[];
  const categories = Array.from(new Set(userPhotos.map(p => p.category).filter(Boolean))) as string[];
  
  const placeText = locations.length > 0 
    ? `across ${locations.join(", ")}` 
    : "across quiet corners and journeys";

  const storyTitle = albumTitle || (locations[0] ? `The Road to ${locations[0]}` : "A Leaf in the Wind");
  const storySubtitle = locations.length > 1 
    ? `A chapter of travels in ${locations.slice(0, 3).join(", ")}` 
    : "A quiet preservation of moments and light";

  const openingNarrative = `This is a quiet curation of ${photoCount} moments captured in time. These pages do not seek to catalog everything, but rather to preserve the small, glowing fragments of a season spent ${locations[0] ? 'exploring ' + locations[0] : 'noticing the beauty in the everyday'}. It is the record of mornings that started with a hot cup of coffee, walks where the shadows stretched long and clear on stone pathways, and the laughter of friends that lingered long after the sun went down. You came home with a library of stories, but these are the few that matter—the ones that, when bound together in ink and cream, remind us of what it felt like to be fully present.`;

  // Sort photos chronologically
  const sortedPhotos = [...userPhotos].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  
  const spreads: any[] = [];
  
  // Map category to a standard premium color palette, poetic insight, and tags
  const getMockAnalysis = (p: any, idx: number) => {
    const isCafe = p.category === "cafe";
    const isNature = p.category === "nature";
    const isTravel = p.category === "travel";
    
    let tags = ["memories", "season", "narrative"];
    let colors = ["#dfd3c1", "#c1a57b", "#3c2f2f"];
    let insight = "An observational composition capturing a quiet, reflective moment.";

    const v = p.vision;
    if (v) {
      tags = v.subjects || tags;
      colors = v.dominantColors || colors;
      const subjectsList = v.subjects && v.subjects.length > 0 ? v.subjects.join(", ") : "elements of light";
      insight = `An intimate study of the ${v.scene || "scene"}, focusing on ${subjectsList} with a ${v.mood || "peaceful"} perspective.`;
    } else {
      if (isCafe) {
        tags = ["cozy", "espresso", "morninglight", "slowliving"];
        colors = ["#4A3728", "#DCD0C0", "#C5A880"];
        insight = `A study of morning routine: warm tones reflecting the slow pace of a local cafe.`;
      } else if (isNature) {
        tags = ["wilderness", "freshair", "wildlife", "landscape"];
        colors = ["#3B4E43", "#A5A48F", "#EDECDF"];
        insight = `Organic shades of green and brown, evoking the stillness of a woodland walk.`;
      } else if (isTravel) {
        tags = ["wanderlust", "street", "architecture", "journey"];
        colors = ["#2B3E50", "#CCAA88", "#E6E1DA"];
        insight = `A journey framed by urban angles and long shadows stretching across the path.`;
      } else {
        tags = ["archive", "minimalist", "portrait", "geometry"];
        colors = ["#1C1B19", "#A69B89", "#ECE8DE"];
        insight = `A study of form and lighting in a quiet, curated segment of the day.`;
      }
    }

    return { tags, colors, insight };
  };

  let pageNum = 3; // Cover is page 1, Narrative is page 2
  
  // Create a separate spread for every single photo (one photo per page)
  for (let i = 0; i < sortedPhotos.length; i++) {
    // Enrich photo elements with candidate mock visual analysis
    const p1 = { ...sortedPhotos[i] };
    p1.analysis = getMockAnalysis(p1, i);
    const spreadPhotos = [p1];
    
    spreads.push({
      id: `spread-${pageNum}`,
      pageNumber: pageNum,
      layout: 'single',
      photos: spreadPhotos,
      caption: (() => {
        const p1 = spreadPhotos[0] as any;
        const v1 = p1?.vision;
        if (v1?.subjects?.length) {
          const subj = v1.subjects.slice(0, 2).join(" and ");
          return `${subj} — some things just go together.`;
        }
        return "A moment worth keeping.";
      })()
    });
    pageNum += 1;
  }

  return {
    title: storyTitle,
    subtitle: storySubtitle,
    openingNarrative,
    spreads,
    photoCount: sortedPhotos.length
  };
}

// REST route for curation
app.post("/api/curate-book", async (req, res) => {
  const { albumTitle, photos, literaryTone } = req.body;
  try {
    if (!photos || !Array.isArray(photos) || photos.length === 0) {
      return res.status(400).json({ error: "No photos provided for curation." });
    }

    const baselineSortedPhotos = [...photos].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

    const apiKey = process.env.GROQ_API_KEY;
    if (!apiKey || apiKey === "MY_GROQ_API_KEY" || apiKey.trim() === "") {
      console.warn("GROQ_API_KEY is not set. Falling back to local offline curation.");
      const fallbackBook = localCurationFallback(albumTitle, baselineSortedPhotos);
      return res.json({
        ...fallbackBook,
        literaryTone: literaryTone || "reflective"
      });
    }

    console.log("Using Groq (llama-3.3-70b-versatile) to curate book story structure with tone:", literaryTone || "reflective");
    const groq = new Groq({ apiKey });
    
    const photoDescriptions = baselineSortedPhotos.map((p: any) => {
      const v = p.vision;
      if (v) {
        return `Photo ID "${p.id}":
  Scene: ${v.scene}
  Mood: ${v.mood}  
  Contains: ${(v.subjects || []).join(", ")}
  Light: ${v.lightQuality}
  Colors: ${(v.dominantColors || []).join(", ")}
  People present: ${v.peoplePresent}
  Story potential: ${v.storyPotential}/10
  Visual Description: ${v.suggestedCaption || "A quiet scene"}`;
      }
      return `Photo ID "${p.id}": no vision data available`;
    }).join("\n\n");

    const toneGuide: Record<string, string> = {
      poetic: "rich and sensory, reference specific visual details you see in the data",
      journalistic: "precise and observational, factual but warm",
      intimate: "personal and direct, written like a private letter",
      minimalist: "short and sharp, one strong image per sentence"
    };

    const tone = toneGuide[literaryTone || "poetic"] || toneGuide.poetic;

    const response = await groq.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      messages: [{
        role: "user",
        content: `You are a memoir editor at a premium publishing house 
like Moleskine or Kinfolk. Write a photo book based on these 
analyzed photos.

TONE: ${tone}

IMPORTANT MANDATE — READ THESE CAREFULLY:
1. You MUST generate exactly one object inside the "photoAnalysis" array for EVERY SINGLE PHOTO ID provided in the PHOTOS list below. Do not leave any photo out!

CAPTION RULES:
Every caption must follow this exact formula:
1. Look at the subjects detected in the photo vision data
2. Build the caption AROUND those specific subjects
3. The caption should feel like a clever observation or 
   reframe of exactly what is in the photo
4. It should sound beautiful but grounded — like something 
   you would write on the back of a printed photo

CAPTION FORMULA:
"[what the scene/moment is doing or offering] + [the human truth or 
twist behind it]"

EXAMPLES of the exact style I want:
- Photo contains: two people, coffee cups, sunset light
  Caption: "Beautiful sunsets are better with someone to blame the second cup on."

- Photo contains: temple, stone steps, morning mist
  Caption: "Some places make you climb before they show you what you came for."

- Photo contains: food spread, table, hands reaching
  Caption: "Every good trip has a meal nobody planned but everyone remembers."

- Photo contains: narrow street, lanterns, evening light
  Caption: "The best streets are the ones that weren't on the map."

- Photo contains: person sitting alone, window, city view
  Caption: "Cities look different when you finally stop rushing through them."

- Photo contains: beach, waves, footprints in sand
  Caption: "The ocean has no opinion about your plans. It just keeps going."

- Photo contains: market stalls, colorful spices, crowd
  Caption: "Some places speak louder in smell and color than in any language."

- Photo contains: two people laughing, blurry background
  Caption: "Whatever was said here, it was worth the entire trip."

RULES:
- Always use the actual subjects from the vision data to inspire the caption
- Never use these words: whispers, echoes, ethereal, timeless, linger, fleeting, gentle, golden memories, soft light, dancing light, quiet moments
- Keep it under 20 words
- It should sound like something a witty thoughtful person wrote — not an AI and not a greeting card
- One sentence only
- No quotes around the caption in the output

OPENING NARRATIVE RULES:
- 120-150 words
- Write in second person (you)
- Reference specific subjects, colors, and scenes from the 
  photo data — not generic travel writing
- Match the tone: ${tone}

PHOTOS:
${photoDescriptions}

Return ONLY this exact JSON, no markdown, no explanation:
{
  "title": "specific poetic title based on these actual photos",
  "subtitle": "one sentence subtitle referencing something specific",
  "openingNarrative": "120-150 words in second person referencing specific things from the photo data",
  "photoAnalysis": [
    {
      "photoId": "string",
      "tags": ["3-4 poetic tags summarizing recognized components/elements"],
      "colors": ["3 elegant hex codes representing dominant colors"],
      "insight": "A simple, poetic caption describing literal visual facts of the image. Keep it under 20 words."
    }
  ]
}`
      }],
      temperature: 0.7,
      max_completion_tokens: 3000
    });

    const text = response.choices[0].message.content?.trim() || "";
    if (!text) {
      throw new Error("Empty response from Groq");
    }

    console.log("Curation Groq prompt completed successfully. Parsing curation JSON...");
    const clean = text.replace(/```json|```/g, "").trim();
    const parsedData = JSON.parse(clean);
    
    // Convert parsed photoAnalysis list into a Map of details for speedy merging
    const analysisMap = new Map<string, any>();
    if (Array.isArray(parsedData.photoAnalysis)) {
      parsedData.photoAnalysis.forEach((an: any) => {
        if (an.photoId) {
          analysisMap.set(an.photoId, {
            tags: Array.isArray(an.tags) ? an.tags : [],
            colors: Array.isArray(an.colors) ? an.colors : [],
            insight: typeof an.insight === 'string' ? an.insight : ""
          });
        }
      });
    }

    // Programmatic Robust Safeguard: Ensure no photo in the original input list is left behind!
    const originalPhotosMap = new Map(baselineSortedPhotos.map(p => [p.id, p]));
    const usedPhotoIds = new Set<string>();
    
    let spreadsList: any[] = [];
    
    // Helper to merge the AI-generated visual analytics back into the photo object
    const enrichPhoto = (pId: string): any => {
      const original = originalPhotosMap.get(pId);
      if (!original) return null;
      
      const details = analysisMap.get(pId);
      if (details && details.insight && details.insight.trim() !== "") {
        return {
          ...original,
          analysis: details
        };
      }
      
      // If no insight was generated by the text model, create a completely dynamic artistic caption
      // using the vision data (no hardcoded/premade text!)
      const v = original.vision;
      let dynamicInsight = "A quiet, contemplative scene.";
      if (v) {
        const subjectsList = v.subjects && v.subjects.length > 0 ? v.subjects.join(", ") : "details of light";
        const sceneName = v.scene || "scene";
        const moodWord = v.mood || "quiet";
        const colorTone = v.dominantColors && v.dominantColors.length > 0 ? v.dominantColors[0] : "warm tones";
        
        dynamicInsight = `A quiet view of ${sceneName} with ${subjectsList} in a ${moodWord} light, focusing on ${colorTone}.`;
      }
      
      const mockTags = v?.subjects || ["authentic", original.category || "moments", "narrative"];
      const mockColors = v?.dominantColors || ["#dfd3c1", "#c1a57b", "#1c1b19"];
      
      return {
        ...original,
        analysis: {
          tags: mockTags,
          colors: mockColors,
          insight: dynamicInsight
        }
      };
    };

    // Construct exactly 1 single layout spread per photo in chronological order
    baselineSortedPhotos.forEach((photo) => {
      const enriched = enrichPhoto(photo.id);
      if (enriched) {
        spreadsList.push({
          layout: 'single',
          photos: [enriched],
          caption: enriched.analysis?.insight || "A beautifully preserved perspective."
        });
      }
    });
    
    // Sort all final spreads chronologically by the timestamp of their first photo to maintain linear narrative flow
    spreadsList.sort((a, b) => {
      const timeA = new Date(a.photos[0].timestamp).getTime();
      const timeB = new Date(b.photos[0].timestamp).getTime();
      return timeA - timeB;
    });
    
    // Finalize with sequentially assigned pageNumbers starting at 3
    const finalizedSpreads = spreadsList.map((spread: any, idx: number) => {
      const pageNumber = idx + 3;
      return {
        id: `spread-${pageNumber}`,
        pageNumber: pageNumber,
        layout: 'single',
        photos: spread.photos,
        caption: spread.caption
      };
    });

    return res.json({
      title: parsedData.title || albumTitle || "A Season of Moments",
      subtitle: parsedData.subtitle || "A curation in soft light",
      openingNarrative: parsedData.openingNarrative || "Your moments gathered together in light.",
      spreads: finalizedSpreads,
      photoCount: baselineSortedPhotos.length,
      literaryTone: literaryTone || "reflective"
    });

  } catch (error: any) {
    console.error("API error during curation. Falling back to local curation:", error);
    try {
      const fallbackBook = localCurationFallback(albumTitle, photos);
      return res.json({
        ...fallbackBook,
        literaryTone: literaryTone || "reflective"
      });
    } catch (fallbackError: any) {
      return res.status(500).json({ error: `Curation process failed completely: ${fallbackError.message || fallbackError}` });
    }
  }
});

// JSON File Database Storage for curated Slidebooks
const BOOKS_FILE = path.join(process.cwd(), "books_store.json");

// Dynamic seed helper to make sure there's always an initial sample book to review
function initDatabase() {
  if (!fs.existsSync(BOOKS_FILE)) {
    try {
      fs.writeFileSync(BOOKS_FILE, JSON.stringify([], null, 2), "utf-8");
      console.log("[Memoir DB] Initial empty books_store.json established successfully.");
    } catch (err) {
      console.error("[Memoir DB] Error initializing file store:", err);
    }
  }
}
initDatabase();

// Help retrieve all books saved on server
function getSavedBooks(): any[] {
  try {
    if (fs.existsSync(BOOKS_FILE)) {
      const data = fs.readFileSync(BOOKS_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch (err) {
    console.error("[Memoir DB] Error reading books file:", err);
  }
  return [];
}

// Helper to write books back
function saveBooks(books: any[]) {
  try {
    fs.writeFileSync(BOOKS_FILE, JSON.stringify(books, null, 2), "utf-8");
    console.log(`[Memoir DB] Synchronized ${books.length} books to books_store.json.`);
  } catch (err) {
    console.error("[Memoir DB] Error synchronizing books database:", err);
  }
}

// 6. Rest Endpoint: Fetch all curated books/album drafts
app.get("/api/books", (req, res) => {
  const books = getSavedBooks();
  return res.json(books);
});

// 7. Rest Endpoint: Retrieve a specific book by ID
app.get("/api/books/:id", (req, res) => {
  const books = getSavedBooks();
  const found = books.find(b => b.id === req.params.id);
  if (!found) {
    return res.status(404).json({ error: "Book not found" });
  }
  return res.json(found);
});

// 8. Rest Endpoint: Save or overwrite a book/album state
app.post("/api/books", (req, res) => {
  const newBook = req.body;
  if (!newBook || !newBook.id) {
    return res.status(400).json({ error: "Invalid book payload. id is mandatory." });
  }

  const books = getSavedBooks();
  const index = books.findIndex(b => b.id === newBook.id);
  
  if (index !== -1) {
    books[index] = { ...books[index], ...newBook, updatedAt: new Date().toISOString() };
  } else {
    newBook.createdAt = newBook.createdAt || new Date().toISOString();
    books.push(newBook);
  }

  saveBooks(books);
  return res.status(200).json({ status: "success", savedBook: newBook });
});

// 9. Rest Endpoint: Delete book from database
app.delete("/api/books/:id", (req, res) => {
  const id = req.params.id;
  const books = getSavedBooks();
  const filtered = books.filter(b => b.id !== id);
  
  if (books.length === filtered.length) {
    return res.status(404).json({ error: "Book not found to delete" });
  }
  
  saveBooks(filtered);
  return res.json({ status: "success", deletedId: id });
});

// App server & Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Using Vite Dev Server Middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Production static mode running...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Memoir Server] Running securely on http://localhost:${PORT}`);
  });
}

startServer();
